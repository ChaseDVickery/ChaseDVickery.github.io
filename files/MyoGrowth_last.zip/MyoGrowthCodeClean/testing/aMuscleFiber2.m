classdef aMuscleFiber2 < matlab.mixin.SetGetExactNames
    %{
    aMuscleFiber Class
    
    Purpose: 
        Agent based on skeletal muscle cells. Their purpose is to work as a
        container and limiting factor for contained nuclei (aNucleus) and myofibrils (aMyofibril) 
    
    Description:
        Muscle fibers will be created when at least 2 myoblasts (aMyoblast)
        merge together and contribute their nuclei to the muscle fiber.
        Muscle fibers will have a set of properties such as length, radius,
        etc that will help determine the confines and distribution of
        myofibrils and nuclei. Muscle fibers may grow until a certain size
        is reached at which point it may split into 2 separate muscle
        fibers.
    
    TODO:
        -change instances of numNuclei to instead be based on a list of
        nuclei this fiber contains    
        -Remove rebound functionality of myofibrils
        
    %}
    
    properties
        xPos;                           %x position in 3D
        yPos;                           %y position in 3D
        zPos;                           %z position in 3D
        radius;                         %radius of cell for contact detection
        length;
        nuclei;
        numNuclei; %TEMPORARY, WILL LATER USE LENGTH OF nuclei list
        myMyofibrils;
        myNuclei;
        boundaryPoints;                 %points in space that could be the fiber's boundary
        boundaryIndicies;               %boundary(vertcat(boundaryPoints(:,:,1),boundaryPoints(:,:,2)))
        boundaryVolume;
        csa;                            %cross sectional area of fiber
        natGrowRate;
        natDecayRate;
        isSteady;
    end
    
    properties (Constant)
        
    end
    
    methods
        %Constructor for aMuscleFiber
        %{
        aMuscleFiber2 constructor
        -------------------------------------------------------------------
        Description:
            Constructor for aMuscleFiber2
        Inputs:
            x - x coordinate of position in world
            y - y coordinate of position in world
            z - z coordinate of position in world
            r - initial radius of cylindrical fiber
            l - initial length of fiber
            gr - a growth rate constant to be passed to contained
            myofibrils
            dr - a decay rate constant to be passed to contained myofibrils
            nMyofibs - determines the initial number of contained
            myofibrils
            nucInfo - an array of information to be passed to contained
            nuclei 
        Outputs:
            obj - an instance of aMuscleFiber2
        %}
%         fibrilInfo = [starting radius, starting length, nat grow rate,...
%                 nat decay rate, # fibrils, max gr, max dr];
%         fibListInfo = [interfibril distance, edge distance, projection quality]
        function obj = aMuscleFiber2(x, y, z, fibrilInfo, fibListInfo, nucInfo, nmechs, fmechs)
            obj.natGrowRate = 0;
            obj.natDecayRate = 0;
            obj.boundaryPoints = [];
            obj.boundaryVolume = 0;
            obj.csa = 0;
            obj.isSteady = false;
            obj.myMyofibrils = aMyofibrilList2(0,fmechs);
            obj.myMyofibrils.interfibrilDist = fibListInfo(1);
            obj.myMyofibrils.edgeDist = fibListInfo(2);
            obj.myMyofibrils.projectionQuality = fibListInfo(3);
            obj.myMyofibrils.maxSplits = fibListInfo(4);
            obj.myNuclei = aNucleusList(0,nmechs);
            if nargin == 0
                obj.xPos = 0;
                obj.yPos = 0;
                obj.zPos = 0;
                obj.radius = 1;
                obj.length = 1;
                obj.numNuclei = 2;
            elseif nargin == 3
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = 1;
                obj.length = 1;
                obj.numNuclei = 2;
            elseif nargin == 4
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = 1;
                obj.numNuclei = 2;
            elseif nargin == 5
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
                obj.numNuclei = 2;
            elseif nargin == 7
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = fibrilInfo(1);
                obj.length = fibrilInfo(2);
                obj.numNuclei = 2;
                obj.natGrowRate = fibrilInfo(3);
                obj.natDecayRate = fibrilInfo(4);
                obj.myNuclei.clear();
                obj.addNucleus(x, y+fibrilInfo(1)/2, z, nucInfo(1), nucInfo(2));
                obj.addNucleus(x, y-fibrilInfo(1)/2, z, nucInfo(1), nucInfo(2));
            elseif nargin == 8
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = fibrilInfo(1);
                obj.length = fibrilInfo(2);
                obj.numNuclei = 2;
                obj.natGrowRate = fibrilInfo(3);
                obj.natDecayRate = fibrilInfo(4);
                obj.myNuclei.clear();
                obj.addNucleus(x, y+fibrilInfo(1)/2, z, nucInfo(1), nucInfo(2));
                obj.addNucleus(x, y-fibrilInfo(1)/2, z, nucInfo(1), nucInfo(2));  
            else
                error('aMuscleFiber : aMuscleFiber: Wrong number of input arguments');
            end
            for i = 1:fibrilInfo(5)
                fibrilR = fibrilInfo(1);
                randTheta = 2*pi()*rand();
                randDisp = (fibrilR)*rand();
                fibrilX = randDisp*cos(randTheta) + x;
                fibrilY = randDisp*sin(randTheta) + y;
                obj.addFibril(fibrilX, fibrilY, z, fibrilR, fibrilInfo(2),...
                    fibrilInfo(3), fibrilInfo(4), fibrilInfo(6), fibrilInfo(7),...
                    fibrilInfo(8), fibrilInfo(9), fibListInfo(4));
            end
            obj.getCentroid();
        end
        
        %{
        addFibril
        -------------------------------------------------------------------
        Description:
            Adds a myofibril to its list of contained myofibrils
        Inputs:
            x-l - values defining a cylinder in space
            gr - growth constant for the myofibrils
            dr - decay rate constant for the myofibrils
        Outputs:
            NA
        %}
        function addFibril(obj, x, y, z, r, l, gr, dr, maxgr, maxdr, maxr, maxl, maxsplits)
            obj.myMyofibrils.addFibril(x, y, z, r, l, gr, dr, maxgr, maxdr, maxr, maxl, maxsplits);
        end
        
        %{
        addNucleus
        -------------------------------------------------------------------
        Description:
            Adds a nucleus to its list of contained nuclei
        Inputs:
            x,y,z,r - defines a sphere in space
            spd - speed of nucleus within fiber
        Outputs:
            NA
        %}
        function addNucleus(obj, x, y, z, spd, r)
            obj.myNuclei.addNucleus(x, y, z, spd, r);
        end
        
        %{
        update
        -------------------------------------------------------------------
        Description:
            Updates the muscle fiber
                -pushes myofibrils back in (TO BE REMOVED)
                -updates contained myofibrils
                -updates contained nuclei
                -makes sure nuclei aren't in myofibrils
        Inputs:
            obj - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function update(obj, xl, yl, maxNuclei, maxFibrils)
            %Tells myofibrils to update:
            %   First spread
            %   Then grow if they would not grow to be outside the fiber
            %obj.checkPushGrow();
%             avgMyo2NucDist = obj.averageMyofibrilFromNucleusDistance();
            obj.myMyofibrils.update(obj,obj.myNuclei,maxNuclei, maxFibrils);
            obj.resetCentroid();
%             obj.resetCentroid();
            obj.getLength();
            obj.getBoundary(xl, yl);
            obj.getZ();
            if (~isempty(obj.boundaryPoints))
                po = obj.myNuclei.checkFibrilBounds(obj.myMyofibrils);
                while(po)
%                     po = false;
                    po = obj.myNuclei.checkFibrilBounds(obj.myMyofibrils);
                end
                obj.myNuclei.update(obj.boundaryPoints, obj.myMyofibrils);
            end            
            obj.checkIsSteady();
        end
        
        function checkIsSteady(obj)
            obj.isSteady = obj.myMyofibrils.checkIsSteady();
        end
        
        %Tells the contained myofibrils to grow. Will later give necessary
        %info on nuclei positions and number
        function myofibrilGrow(obj)
            
        end
        
        %Tells the fiber to grow based on the number of nuclei it contains.
        function grow(obj, pushed)
            
        end
        
        function die(obj)
            disp('muscle fiber death');
            obj.myMyofibrils.clear();
            obj.myNuclei.clear();
            delete(obj);
        end
        
        function getCentroid(obj)
            [x,y,z] = obj.myMyofibrils.averagePosition;
            if(any(isnan([x,y,z])))
                disp('bad centroid');
            end
            obj.xPos = x; obj.yPos = y; obj.zPos = z;
        end
        
        function getZ(obj)
            [x,y,z] = obj.myMyofibrils.averagePosition;
            obj.zPos = z;
        end
        
        function getLength(obj)
            obj.length = obj.myMyofibrils.averageLength();
        end
        
        %resets the nuclei and myofibrils based on myofibril's centroid
        function resetCentroid(obj)
            [x,y,z] = obj.myMyofibrils.averagePosition;
            dx = obj.xPos - x;
            dy = obj.yPos - y;
            for i = 1:obj.myMyofibrils.length()
                obj.myMyofibrils.getFibril(i).xPos = ...
                    obj.myMyofibrils.getFibril(i).xPos + dx;
                obj.myMyofibrils.getFibril(i).yPos = ...
                    obj.myMyofibrils.getFibril(i).yPos + dy;
            end
%             for i = 1:obj.myNuclei.length()
%                 obj.myNuclei.getNucleus(i).xPos = ...
%                     obj.myNuclei.getNucleus(i).xPos + dx;
%                 obj.myNuclei.getNucleus(i).yPos = ...
%                     obj.myNuclei.getNucleus(i).yPos + dy;
%             end
%             obj.getCentroid();
        end
        
        %{
        checkPushGrow
        -------------------------------------------------------------------
        Description:
            Checks all contained myofibrils and rebounds them back towards
            the center of the fiber. TO BE REMOVED EVENTUALLY
        Inputs:
            obj - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function checkPushGrow(obj)
            if(~isempty(obj.myMyofibrils))
                for i = 1:(length(obj.myMyofibrils))
                    fib1x = obj.myMyofibrils.getFibril(i).xPos;
                    fib1y = obj.myMyofibrils.getFibril(i).yPos;
                    fib1z = obj.myMyofibrils.getFibril(i).zPos;
                    fib1r = obj.myMyofibrils.getFibril(i).radius;
                    fib1l = obj.myMyofibrils.getFibril(i).length;
                    if (sqrt((fib1x-obj.xPos)^2 + (fib1y-obj.yPos)^2)+fib1r > (obj.radius))
                        %obj.myMyofibrils.getFibril(i).touchingEdge = true;
                        obj.myMyofibrils.getFibril(i).rebound(obj);
                    else
                        %obj.myMyofibrils.getFibril(i).touchingEdge = false;
                    end
                end
                obj.myMyofibrils.checkFibrilSpread(obj);
            end
        end
        
        %{
        fibPush
        -------------------------------------------------------------------
        Description:
            Called by list of fibers, this pushes the fiber and another
            given fiber an equal distance away from each other to a point
            where they are no longer in contact
        Inputs:
            obj - this aMuscleFiber2 instance
            otherfib - another aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function fibPush(obj, otherfib, xl, yl)
%             obj.getCentroid();
            obj.getLength();
%             otherfib.getCentroid();
            otherfib.getLength();
            x = obj.xPos - otherfib.xPos;
            y = obj.yPos - otherfib.yPos;
            if(x^2==0 && y^2==0)
                x = rand()/1000;
                y = rand()/1000;
                disp('muscle fibers on same position. Changing.');
            end
            
            sep1 = obj.myMyofibrils.edgeDist;
            sep2 = otherfib.myMyofibrils.edgeDist;
            newx = sqrt((x^2 * (sep1/2)^2) / (x^2 + y^2));
            newy = sqrt((y^2 * (sep2/2)^2) / (x^2 + y^2));
            if(any(isnan(newx)))
                disp('bad newx fibPush');
            end
            if(any(isnan(newy)))
                disp('bad newy fibPush');
            end
            if (x >= 0)
                dx = (((newx))/2);
            else
                dx = (((-newx))/2);
            end
            if (y >= 0)
                dy = (((newy))/2);
            else
                dy = (((-newy))/2);
            end
            if(any(isnan(dx)))
                disp('bad dx');
            end
            if(any(isnan(dy)))
                disp('bad dy');
            end
            %my myofibrils move
            for i = 1:obj.myMyofibrils.length()
                obj.myMyofibrils.getFibril(i).xPos = obj.myMyofibrils.getFibril(i).xPos + dx;
                obj.myMyofibrils.getFibril(i).yPos = obj.myMyofibrils.getFibril(i).yPos + dy;
            end
            %my nuclei move
            for i = 1:obj.myNuclei.length()
                obj.myNuclei.getNucleus(i).xPos = obj.myNuclei.getNucleus(i).xPos + dx;
                obj.myNuclei.getNucleus(i).yPos = obj.myNuclei.getNucleus(i).yPos + dy;
            end
            obj.getCentroid();
            obj.getLength();
%             obj.xPos = obj.xPos + dx;
%             obj.yPos = obj.yPos + dy;  
            %other fiber does the same
            for i = 1:otherfib.myMyofibrils.length()
                otherfib.myMyofibrils.getFibril(i).xPos = otherfib.myMyofibrils.getFibril(i).xPos - dx;
                otherfib.myMyofibrils.getFibril(i).yPos = otherfib.myMyofibrils.getFibril(i).yPos - dy;
            end
            for i = 1:otherfib.myNuclei.length()
                otherfib.myNuclei.getNucleus(i).xPos = otherfib.myNuclei.getNucleus(i).xPos - dx;
                otherfib.myNuclei.getNucleus(i).yPos = otherfib.myNuclei.getNucleus(i).yPos - dy;
            end
            otherfib.getCentroid();
            otherfib.getLength();
%             otherfib.xPos = otherfib.xPos - dx;
%             otherfib.yPos = otherfib.yPos - dy; 
            obj.getBoundary(xl, yl);
            otherfib.getBoundary(xl, yl);
            
        end
        
        function [topBounds, botBounds] = getBoundary(obj, xl, yl)
%             tic;
            [topBounds, midBounds, botBounds] = obj.myMyofibrils.getBoundary();
%             if(any(any(isnan(topBounds))) || isempty(topBounds))
%                 disp('bad topbounds');
%             end
%             if(any(any(isnan(midBounds))) || isempty(midBounds))
%                 disp('bad midbounds');
%             end
%             if(any(any(isnan(botBounds))) || isempty(botBounds))
%                 disp('bad botbounds');
%             end
            obj.boundaryPoints = [];
            obj.boundaryPoints(:,:,1) = topBounds;
            obj.boundaryPoints(:,:,2) = midBounds;
            obj.boundaryPoints(:,:,3) = botBounds;
            try
                [~,obj.csa] = boundary(topBounds(:,1:2));
                %this gets the area to squared micrometers
                obj.csa = obj.csa*(1000^2);
            catch
                topBounds
                midBounds
                botBounds
                error('aMuscleFiber2 error here');
            end
            if (~isempty(topBounds) && ~isempty(midBounds) && ~isempty(botBounds))              
                muscleBounds = vertcat(topBounds, midBounds, botBounds);
                [obj.boundaryIndicies, obj.boundaryVolume] = boundary(muscleBounds);
                obj.getCentroid();
            end
%             toc;
        end
        
        function checkMyofibrilSplit(obj, splitChance, splitRadius)
            didSplit = obj.myMyofibrils.checkMyofibrilSplit(splitChance, splitRadius);
            if(didSplit)
                obj.resetCentroid();
                obj.getCentroid();
                obj.myNuclei.checkFibrilBounds(obj.myMyofibrils);
            end
        end
        
        function [allOut] = checkMyofibrilsInWorld(obj, xl, yl)
            if(~isempty(obj.myMyofibrils))
                allOut = obj.myMyofibrils.checkMyofibrilsInWorld(xl,yl);
            end
        end
        
        function [avgDist] = averageMyofibrilFromNucleusDistance(obj)
            avgDist = 0;
            if (~isempty(obj.myNuclei) && ~isempty(obj.myMyofibrils))
                for i = 1:obj.myMyofibrils.length()
                    total = 0;
                    for j = 1:obj.myNuclei.length()
                        %not taking z into account because for now all
                        %fibrils in a fiber have the same length
                        ix = obj.myMyofibrils.getFibril(i).xPos; jx = obj.myNuclei.getNucleus(j).xPos;
                        iy = obj.myMyofibrils.getFibril(i).yPos; jy = obj.myNuclei.getNucleus(j).yPos;
                        total = total + sqrt((ix-jx)^2 + (iy-jy)^2);
                    end
                    total = total/(obj.myNuclei.length());
                    dist(i) = total;
                end
                avgDist = mean(dist);
            end
        end
        
    end
end