classdef aMuscleFiberList2 < matlab.mixin.SetGetExactNames
    %{
    aMuscleFiber2List Class
    
    Purpose: 
        To maintain a list of all muscle fibers within the model
    
    Description:
        This will keep an array of muscle fibers that can be called upon:
            Reference the property values of specific objects using array
            indexing
                objArray(ix).PropName
            Reference all values of the same property in obj array
                objArray.PropName
    
    TODO:
    %}
    
    properties
        allFibers = aMuscleFiber2.empty;     %an array of the satellite cells it contains
        mechanisms;
        nucMechanisms;
        fibrilMechanisms;
        ratioSteady;
    end
    
    methods        
        %{
        aMuscleFiberList2 Constructor
        -------------------------------------------------------------------
        Description:
            Constructor for aMuscleFiberList2
        Inputs:
            n - a number of muscle fibers to add
        Outputs:
            obj - aMuscleFiberList2 instance
        %}
        function obj = aMuscleFiber2List2(n, mechs)
            obj.ratioSteady = 0;
            if nargin ~= 0
                if (n ~= 0)
                    for (i = 1:n)
                        obj.allFibers(i) = aMuscleFiber2;
                    end
                end
                if (~isempty(mechs))
                    obj.mechanisms = mechs;
                end
            end
        end
                
        %{
        length
        -------------------------------------------------------------------
        Description:
            Returns the length of the list of muscle fibers
        Inputs:
            obj - aMuscleFiberList2 instance
        Outputs:
            lngth - number of fibers in it's allFibers array
        %}
        function [lngth] = length(obj)
%             obj.allFibers
            lngth = length(obj.allFibers);
        end
        
        %{
        addFiber
        -------------------------------------------------------------------
        Description:
            Adds another muscle fiber to its list of muscle fibers
        Inputs:
            obj - aMuscleFiberList2 instance
            x-l - defines a cylinder in space
            gr - growth rate
            dr - decay rate
            nMyo - initial number of myofibrils in fiber
            nucInfo - array of nucleus information
        Outputs:
            NA
        %}
        function addFiber(obj, x, y, z, fibrilInfo, fibListInfo, nucInfo, nmechs, fmechs)
            if nargin == 1
                newCell = aMuscleFiber2();
                obj.allFibers = [obj.allFibers, newCell];
            elseif nargin == 5
                newCell = aMuscleFiber2(x,y,z,r);
                obj.allFibers = [obj.allFibers, newCell];
            elseif nargin == 8
                newCell = aMuscleFiber2(x,y,z,fibrilInfo,nucInfo,nmechs,fmechs);
                obj.allFibers = [obj.allFibers, newCell];
            elseif nargin == 9
                newCell = aMuscleFiber2(x,y,z,fibrilInfo,fibListInfo,nucInfo,nmechs,fmechs);
                obj.allFibers = [obj.allFibers, newCell];
            else
                error('aMuscleFiber2List : addFiber: Wrong number of input arguments');
            end
            
        end
        
        %{
        getFiber
        -------------------------------------------------------------------
        Description:
            Returns an instance of a muscle fiber in this list
        Inputs:
            obj - aMuscleFiberList2 instance
            idx - index corresponding to position of particular muscle
            fiber in this list
        Outputs:
            fiber - aMuscleFiber2 instance
        %}
        function [fiber] = getFiber(obj, idx)
            fiber = obj.allFibers(idx);
        end
        
        %{
        update
        -------------------------------------------------------------------
        Description:
            Updates all contained muscle fibers and checks each muscle
            fiber to make sure they are not in contact with one another
        Inputs:
            obj - aMuscleFiberList2 instance
        Outputs:
            NA
        %}
        function update(obj, xl, yl, maxNuclei, maxFibrils)
            if (~isempty(obj.allFibers))
                for (i = length(obj.allFibers):-1:1)
                    if (~isempty(obj.allFibers(i)) && ~isempty(obj.allFibers(i).myMyofibrils))
                        obj.allFibers(i).update(xl, yl, maxNuclei, maxFibrils);
                    else
%                         disp('here 1');
                        obj.allFibers(i).die();
                        obj.allFibers(i) = [];
                    end
                    if(any(any(any(isnan(obj.allFibers(i).boundaryPoints)))))
                        sprintf('fiber @ index %i has NaN bound',i);
                    end
                end
                for (i = length(obj.allFibers):-1:1)
                    if (isempty(obj.allFibers(i).myMyofibrils) || obj.checkMyofibrilsInWorld(xl,yl,i))
%                         disp('here 2');
                        obj.allFibers(i).die();
                        obj.allFibers(i) = [];
                    end
                end
                push = obj.checkFibSpread(xl, yl);
                while (push)
                    push = obj.checkFibSpread(xl, yl);
                end
                for (i = obj.length():-1:1)
                    if (~isempty(obj.allFibers(i)) && ~isempty(obj.allFibers(i).myMyofibrils))
%                         obj.allFibers(i).resetCentroid();
                        obj.allFibers(i).getBoundary(xl, yl);
                    else
%                         disp('here 3');
                        obj.allFibers(i).die();
                        obj.allFibers(i) = [];
                    end
                end
                obj.checkIsSteady();
            end
        end
        
        function killTrigger(obj, propToKillFibers, propToKillFibrils, propToKillNuclei)
            %rounds down the number to kill
            if(propToKillFibers > 0)
                disp('trigger killing muscle fibers');
                numToKill = floor(obj.length()*propToKillFibers);
                idxsToKill = randperm(obj.length(), numToKill);
                idxsToKill = sort(idxsToKill);
                if(~isempty(obj.allFibers))
                    for i = length(idxsToKill):-1:1
                        obj.die(idxsToKill(i));
                    end
                end
            end
            if(propToKillFibrils > 0)
                for j = 1:obj.length()
                    obj.allFibers(j).myMyofibrils.killTrigger(propToKillFibrils);
                end
            end
            if(propToKillNuclei > 0)
                for j = 1:obj.length()
                    obj.allFibers(j).myNuclei.killTrigger(propToKillNuclei);
                end
            end
        end
        
        function hypertrophyFiberChanges(obj, fibsplit)
            disp('placeholder fiber change function in aMuscleFiberList2');
        end
        
        function hypertrophyMyofibrilChanges(obj, grm, drm, mrm)
            if(~isempty(obj.allFibers))
                for i = 1:obj.length()
                    obj.allFibers(i).myMyofibrils.hypertrophyChanges(...
                        grm, drm, mrm);
                end
            end
        end
        
        %{
        die
        -------------------------------------------------------------------
        Description:
            Kills a muscle fiber at a particular index
        Inputs:
            obj - aMuscleFiberList2 instance
            idx - index of muscle fiber to delete in the list
        Outputs:
            NA
        %}
        function die(obj, idx)
            if (~isempty(obj.allFibers))
                if (idx > 0 && idx <= length(obj.allFibers))
                    %fprintf('Myoblast at idx %i is dying\n', idx);
                    obj.allFibers(idx).die();
                    obj.allFibers(idx) = [];
                    
                else
                    disp('Index out of bounds. No muscle fibers killed.');
                end
            else
                disp('No muscle fibers left to die');
            end
        end
        
        function checkIsSteady(obj)
            numSteady = 0;
            for i = 1:obj.length()
                if(obj.allFibers(i).isSteady)
%                     fprintf('Fiber at idx %i is steady\n', i);
                    numSteady = numSteady+1;
                end
            end
            obj.ratioSteady = numSteady/obj.length();
        end
        
        %{
        clear
        -------------------------------------------------------------------
        Description:
            Kills and removes all muscle fibers from the list
        Inputs:
            obj - aMuscleFiberList2 instance
        Outputs:
            NA
        %}
        function clear(obj)
            if(~isempty(obj.allFibers))
                for (i = 1:obj.length())
                    obj.die(1);
                end
            end
        end
        
        %Returns the x, y, and z coordinates of every muscle fiber in the
        %matrix allPos
        %{
        getAllPositions
        -------------------------------------------------------------------
        Description:
            Returns the x, y, and z coordinates of every muscle fiber in
            the matrix allPos
        Inputs:
            obj - aMuscleFiberList2
        Outputs:
            allPos - a matrix containing the x,y,z coordinates of every
            muscle fiber in the list
        %}
        function [allPos] = getAllPositions(obj)
            allPos = zeros(obj.length(),3);
            for (i = 1:(obj.length()))
                allPos(i, 1) = obj.allFibers(i).xPos();
                allPos(i, 2) = obj.allFibers(i).yPos();
                allPos(i, 3) = obj.allFibers(i).zPos();
            end
        end
        
        %{
        checkFibSpread
        -------------------------------------------------------------------
        Description:
            Checks all muscle fibers in the list and pushes them away from
            each other if they are overlapping
        Inputs:
            obj - aMuscleFiberList2 instance
        Outputs:
            pushOccurred - a boolean telling whether any muscle fibers had
            to be pushed away
        %}
        function [pushOccurred] = checkFibSpread(obj, xl, yl)
            pushOccurred = false;
            if(obj.length()>1)
                for i = 1:(obj.length()-1)
                    for j = (i+1):obj.length()
                        if (~isempty(obj.allFibers(i).boundaryPoints) && ...
                                ~isempty(obj.allFibers(j).boundaryPoints) &&...
                                ~any(any(any(isnan(obj.allFibers(i).boundaryPoints)))) &&...
                                ~any(any(any(isnan(obj.allFibers(j).boundaryPoints)))))
                            halflength1 = obj.allFibers(i).length/2;
                            halflength2 = obj.allFibers(j).length/2;
                            ztop1 = obj.allFibers(i).zPos + halflength1;
                            zbot1 = obj.allFibers(i).zPos - halflength1;
                            ztop2 = obj.allFibers(j).zPos + halflength2;
                            zbot2 = obj.allFibers(j).zPos - halflength2;
                            fib1xBounds = obj.allFibers(i).boundaryPoints(:,1,1);
                            fib1yBounds = obj.allFibers(i).boundaryPoints(:,2,1);
%                             fib1Ind = boundary(fib1xBounds, fib1yBounds);
%                             obj.allFibers(j).boundaryPoints
                            fib2xBounds = obj.allFibers(j).boundaryPoints(:,1,1);
                            fib2yBounds = obj.allFibers(j).boundaryPoints(:,2,1);
%                             fib2Ind = boundary(fib2xBounds, fib2yBounds);
                            pushOccurred = false;
                            while (any(inpolygon(fib1xBounds,...
                                    fib1yBounds,...
                                    fib2xBounds,...
                                    fib2yBounds)) &&(ztop1 > zbot2) && (zbot1 < ztop2) &&...
                                    ~isempty(obj.allFibers(i).boundaryPoints) && ...
                                    ~isempty(obj.allFibers(j).boundaryPoints) &&...
                                    ~any(any(any(isnan(obj.allFibers(i).boundaryPoints)))) &&...
                                    ~any(any(any(isnan(obj.allFibers(j).boundaryPoints)))))     
                                try
                                pushOccurred = true;
                                obj.allFibers(j).fibPush(obj.allFibers(i), xl, yl);
                                fib1xBounds = obj.allFibers(i).boundaryPoints(:,1,1);
                                fib1yBounds = obj.allFibers(i).boundaryPoints(:,2,1);
%                                 fib1Ind = boundary(fib1xBounds, fib1yBounds);
                                fib2xBounds = obj.allFibers(j).boundaryPoints(:,1,1);
                                fib2yBounds = obj.allFibers(j).boundaryPoints(:,2,1);
%                                 fib2Ind = boundary(fib2xBounds, fib2yBounds);
                                catch
%                                     obj.allFibers(i).boundaryPoints
%                                     obj.allFibers(j).boundaryPoints
                                    disp('ERROR OCCURRED');
                                end
                            end
%                         else
%                             obj.allFibers(i).myMyofibrils.length()
%                             obj.allFibers(i).myMyofibrils.getFibril(1).radius
%                             obj.allFibers(j).myMyofibrils.length()
%                             obj.allFibers(j).myMyofibrils.getFibril(1).radius
%                             disp('one of these has no boundaries');
                        end
                    end
                end
            end
        end
        
        function [allOut] = checkMyofibrilsInWorld(obj, xl, yl, i)
            if(~isempty(obj.allFibers))                
                allOut = obj.allFibers(i).checkMyofibrilsInWorld(xl,yl);
            end
        end
        
        function s = saveState(obj)
            if (~isempty(obj.allFibers))
                s.number = obj.length();
                s.allPos = obj.getAllPositions();
                ann = 0;
                amn = 0;
                avgNucSpread = 0;
                avgFiberVolume = 0;
                for i = 1:obj.length()
                    s(i).bounds = obj.allFibers(i).boundaryPoints;
                    s(i).boundInds = obj.allFibers(i).boundaryIndicies;
                    s(i).boundVolume = obj.allFibers(i).myMyofibrils.totalVolume();
                    s(i).myofibrils = obj.allFibers(i).myMyofibrils.saveState();
                    s(i).nuclei = obj.allFibers(i).myNuclei.saveState();
                    ann = ann + s(i).nuclei.number;
                    amn = amn + s(i).myofibrils.number;
                    avgNucSpread = avgNucSpread + s(i).nuclei.avgNucSpread();
                    avgFiberVolume = avgFiberVolume + s(i).boundVolume;
                end
                num = obj.length();
                ann = ann / num;
                amn = amn / num;
                avgNucSpread = avgNucSpread / num;
                avgFiberVolume = avgFiberVolume / num;
                s(1).avgNucNumber = ann;
                s(1).avgMyoNumber = amn;
                s(1).avgNucSpread = avgNucSpread;     
                s(1).avgFiberVolume = avgFiberVolume;
            else
                s = struct([]);
            end
        end
        
    end
    
    
end