classdef aMyofibrilList2 < matlab.mixin.SetGetExactNames
    %{
    aMyofibril2List Class
    
    Purpose: 
        To maintain a list of all myofibrils within a muscle fiber
    
    Description:
        This will keep an array of myofibrils that can be called upon:
            Reference the property values of specific objects using array
            indexing
                objArray(ix).PropName
            Reference all values of the same property in obj array
                objArray.PropName
    
    TODO:
    %}
    
    properties
        allFibrils = aMyofibril2.empty;     %an array of the satellite cells it contains
        interfibrilDist;
        edgeDist;
        projectionQuality;
        maxSplits;
        maxFibFromNucDist;
        mechanisms;
    end
    
    methods
        %{
        aMyofibrilList2 constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aMyofibrilList2
        Inputs:
            n - number of initial myofibrils in the myofibril list
            mechs - structure of myofibril mechanisms
        Outputs:
            obj - aMyofibrilList2 instance
        %}
        function obj = aMyofibrilList2(n, mechs)            
            if nargin ~= 0
                if (n ~= 0)
                    for (i = 1:n)
                        obj.allFibrils(i) = aMyofibril2;
                    end
                end
                if (~isempty(mechs))
                    obj.mechanisms = mechs;
                end
            end
            obj.interfibrilDist = 0.00006;
            obj.edgeDist = 0.0012;
            obj.projectionQuality = 50;
            obj.maxFibFromNucDist = [];
        end
        
        %{
        length
        ---------------------------------------------------------------------------
        Description:
            Returns the number of myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            lngth - Number of myofibrils in the list
        %}
        function [lngth] = length(obj)
            lngth = length(obj.allFibrils);
        end
        
        %{
        addFibril
        ---------------------------------------------------------------------------
        Description:
            Adds another myofibril to the list of myofibrils
        Inputs:
            obj - aMyofibrilList2 instance
            x,y,z,r,l - defines a myofibril cylinder in space
            gr - growth rate constant of myofibril
            dr - decay rate constant of myofibril
            maxgr-maxsplits - maximum values for myofibrils
        Outputs:
            NA
        %}
        function addFibril(obj, x, y, z, r, l, gr, dr, maxgr, maxdr, maxr, maxl, maxsplits)
            if nargin == 1
                newFibril = aMyofibril2();
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 5
                newFibril = aMyofibril2(x,y,z,r);
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 6
                newFibril = aMyofibril2(x,y,z,r,l);
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 8
                newFibril = aMyofibril2(x,y,z,r,l,gr,dr);
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 10
                newFibril = aMyofibril2(x,y,z,r,l,gr,dr,maxgr,maxdr);
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 12
                newFibril = aMyofibril2(x,y,z,r,l,gr,dr,maxgr,maxdr,maxr,maxl);
                obj.allFibrils = [obj.allFibrils, newFibril];
            elseif nargin == 13
                newFibril = aMyofibril2(x,y,z,r,l,gr,dr,maxgr,maxdr,maxr,maxl,maxsplits);
                obj.allFibrils = [obj.allFibrils, newFibril];
            else
                error('aMyofibril2List : addFibril: Wrong number of input arguments');
            end
        end
        
        %{
        getFibril
        ---------------------------------------------------------------------------
        Description:
            Returns an instance of a myofibril at a particular index in the
            list
        Inputs:
            obj - aMyofibrilList2 instance
            idx - index to myofibril in list
        Outputs:
            fibril - aMyofibril2 instance
        %}
        function [fibril] = getFibril(obj, idx)
            fibril = obj.allFibrils(idx);
        end
        
        %{
        getList
        ---------------------------------------------------------------------------
        Description:
            Returns the entire array of myofibrils
        Inputs:
            obj - aMyofibrilList2
        Outputs:
            fibrils - an array containing all myofibrils in the list
        %}
        function [fibrils] = getList(obj)
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    fibrils(i) = obj.allFibrils(i);
                end
            end
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates all contained myofibrils
            Packs all the myofibrils
        Inputs:
            obj - aMyofibrilList2 instance
            parentFib - aMuscleFiber2 instance
            nucs - a list of nuclei
            maxNuclei - number of nuclei where sat cells stop producing
            maxFibrils - calculated from max splits
        Outputs:
            NA
        %}
        function update(obj, parentFib, nucs, maxNuclei, maxFibrils)               
            %push = obj.checkFibrilSpread(parentFib);
%             maxmyo2nucdist = obj.maxAverageMyofibrilFromNucleusDistance(nucs);
            minDists = obj.allMinMyofibrilFromNucleusDistances(nucs);
            highestMin = obj.highestMinMyofibrilFromNucleusDistance(nucs);
            localDistSums = obj.sumOneOverMyofibrilFromNucleusDistancesSquared(nucs);
            totalVol = obj.totalVolume();
            for i = obj.length():-1:1
                if (obj.allFibrils(i).radius < 0.0)
                    obj.die(i);
%                     obj.allFibrils(i) = [];
                else                    
%                     myo2nucdist = obj.averageMyofibrilFromNucleusDistance(nucs,i);
%                     myo2nucdist = 0;
                    if(obj.length()==1)
                        obj.allFibrils(i).update(parentFib, obj.mechanisms, localDistSums(i), totalVol);
                    else
                        obj.allFibrils(i).update(parentFib, obj.mechanisms, localDistSums(i), totalVol);
                    end
                end
            end
            if (obj.length()>1)
                obj.pack(parentFib);
            end
            %push = obj.checkFibrilSpread(parentFib);
        end
        
        %{
        killTrigger
        ---------------------------------------------------------------------------
        Description:
            This can activate when a steady state is reached. It kills a
            certain percentage of myofibrils in the muscle fiber.
        Inputs:
            obj - aMyofibrilList2 instance
            propToKill - the proportion of myofibrils to die
        Outputs:
            NA
        %}
        function killTrigger(obj, propToKill)
            disp('trigger killing myofibrils');
            %rounds down the number to kill
            numToKill = floor(obj.length()*propToKill);
            idxsToKill = randperm(obj.length(), numToKill);
            idxsToKill = sort(idxsToKill);
            if(~isempty(obj.allFibrils))
                for i = length(idxsToKill):-1:1
                    obj.die(idxsToKill(i));
                end
            end
        end
        
        %TO CHANGE
        %{
        hypertrophyChanges
        ---------------------------------------------------------------------------
        Description:
            Changes that are made to
        Inputs:
            
        Outputs:
            
        %}
        function hypertrophyChanges(obj, grm, drm, mrm)
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    obj.allFibrils(i).natGrowRate =...
                        obj.allFibrils(i).natGrowRate * grm;
                    obj.allFibrils(i).natDecayRate =...
                        obj.allFibrils(i).natDecayRate * drm;
                    obj.allFibrils(i).maxR =...
                        obj.allFibrils(i).maxR * mrm;
                end
            end
        end
        
        function [isSteady] = checkIsSteady(obj)
            isSteady = false;
            if(~isempty(obj.allFibrils))
                isSteady = true;
                for i = 1:obj.length()
                    if(obj.allFibrils(i).numSplits ~= obj.allFibrils(i).maxSplits)
                        isSteady = false;
                    end
                end
            end
        end
        
%         function [maxDist] = maxMyofibrilFromNucleusDistance(obj,nucs)
%             maxDist = [];
%             if (~isempty(nucs)&& ~isempty(obj.allFibrils))
%                 for i = 1:obj.length()
%                     total = 0;
%                     for j = 1:nucs.length()
%                         %not taking z into account because for now all
%                         %fibrils in a fiber have the same length
%                         ix = obj.allFibrils(i).xPos; jx = nucs.getNucleus(j).xPos;
%                         iy = obj.allFibrils(i).yPos; jy = nucs.getNucleus(j).yPos;
%                         dist = sqrt((ix-jx)^2 + (iy-jy)^2);
%                         total = total + dist;
%                     end
%                     total = total/(nucs.length());
%                     if(isempty(maxDist) || total > maxDist)
%                         maxDist = total;
%                     end
%                 end
%                 if (nucs.length() == 0)
%                     disp('NO NUCLEI');
%                 end
%             end
%         end

        %{
        averageMyofibrilFromNucleusDistance
        ---------------------------------------------------------------------------
        Description:
            Calculates the average distance from a myofibril at index i to
            all the nuclei in the muscle fiber
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
            i - index of myofibril in the list
        Outputs:
            avgDist - a scalar telling the average distance from the
            myoifibril to all the nuclei in the fiber
        %}
        function [avgDist] = averageMyofibrilFromNucleusDistance(obj,nucs,i)
            avgDist = 0;
            if (~isempty(nucs) && ~isempty(obj.allFibrils(i)))
                total = 0;
                for j = 1:nucs.length()
                    %not taking z into account because for now all
                    %fibrils in a fiber have the same length
                    ix = obj.allFibrils(i).xPos; jx = nucs.getNucleus(j).xPos;
                    iy = obj.allFibrils(i).yPos; jy = nucs.getNucleus(j).yPos;
                    dist = sqrt((ix-jx)^2 + (iy-jy)^2);
                    total = total + dist;
                end
                if (nucs.length() == 0)
                    disp('NO NUCLEI');
                end
                total = total/(nucs.length());
                avgDist = total;
            end
        end
        
        %{
        maxAverageMyofibrilFromNucleusDistance
        ---------------------------------------------------------------------------
        Description:
            Calculates the average distance from myofibrils to nuclei that
            is the largest in the list
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            maxAvgDist - a scalar telling the highest average fibril to
            nuclei distance
        %}
        function [maxAvgDist] = maxAverageMyofibrilFromNucleusDistance(obj,nucs)
            maxAvgDist = [];
            for i = 1:obj.length()
                avgdist = obj.averageMyofibrilFromNucleusDistance(nucs,i);
                if(isempty(maxAvgDist) || avgdist > maxAvgDist)
                    maxAvgDist = avgdist;
                end
            end
        end
        
        %{
        allMyofibrilFromNucleusDistances
        ---------------------------------------------------------------------------
        Description:
            returns a matrix allDist describing the distances from all
            nuclei to all myofibrils
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            allDist - a matrix containing distances where each column
            describes the distances from all nuclei to ONE myofibril
        %}
        function [allDist] = allMyofibrilFromNucleusDistances(obj,nucs)
            allDist = [];
            if(~isempty(obj.allFibrils) && ~isempty(nucs.allNuclei))
                %  each column contains dist from 1 myofibril to all nuclei
                allDist = zeros(obj.length(),nucs.length());
                for i = 1:obj.length()
                    for j = 1:nucs.length()
                        ix = obj.allFibrils(i).xPos; jx = nucs.getNucleus(j).xPos;
                        iy = obj.allFibrils(i).yPos; jy = nucs.getNucleus(j).yPos;
                        dist = sqrt((ix-jx)^2 + (iy-jy)^2);
                        allDist(j,i) = dist;
                    end
                end
            end
        end
        
        %{
        sumOneOverMyofibrilFromNucleusDistancesSquared
        ---------------------------------------------------------------------------
        Description:
            Takes all the nucleus to myofibril distances and sums up the
            nucleus distances for each myofibril in the form of
            1/(distance)^2
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            sums - an array containing a number for each myofibril
            describing the sum(1/(distance to nuclei)^2)
        %}
        function [sums] = sumOneOverMyofibrilFromNucleusDistancesSquared(obj,nucs)
            allDist = obj.allMyofibrilFromNucleusDistances(nucs);
            % i: 1 to # fibrils            j: 1 to # nuclei
            sums = zeros(size(allDist,1),1);
            for i = 1:size(allDist,2)
                for j = 1:size(allDist,1)
                    %NOW in MICROMETERS
                    if(allDist(j,i)~=0)
                        if(allDist(j,i) >= obj.allFibrils(i).radius)
                            sums(i) = sums(i) + (1/((allDist(j,i)*1000)^2));
                        else
                            sums(i) = sums(i) + (1/((obj.allFibrils(i).radius*1000)^2));
                        end
                    end
                end
            end
        end
        
        %{
        allMinMyofibrilFromNucleusDistances
        ---------------------------------------------------------------------------
        Description:
            Gets the smallest myofibril to nuclei distance for each
            myofibril
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            allMins - an array containing a distance for each myofibril
            describing the distance from the myofibril to its nearest
            nucleus
        %}
        function [allMins] = allMinMyofibrilFromNucleusDistances(obj,nucs)
            allDist = obj.allMyofibrilFromNucleusDistances(nucs);
            allMins = min(allDist);
        end
        
        %{
        highestMinMyofibrilFromNucleusDistance
        ---------------------------------------------------------------------------
        Description:
            Returns the highest of the min distances from myofibrils to
            nuclei. Essentially returns the lowest distance from a
            myofibril to a nucleus in the entire fiber.
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            highestMin - the largest minimum nucleus from myofibril
            distance
        %}
        function [highestMin] = highestMinMyofibrilFromNucleusDistance(obj,nucs)
            allDist = obj.allMyofibrilFromNucleusDistances(nucs);
            mindists = min(allDist);
            highestMin = max(mindists);
        end
        
        %{
        pack
        ---------------------------------------------------------------------------
        Description:
            An algorithm that moves myofibrils closer to one another based
            on their distance from the average myofibril position.
        Inputs:
            obj - aMyofibrilList2 instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function pack(obj, parentFib)
            for i = 1:length(obj.allFibrils)
                origX = obj.allFibrils(i).xPos;
                origY = obj.allFibrils(i).yPos;
                xVec(i) = 0;
                yVec(i) = 0;
                for j = 1:length(obj.allFibrils)
                    if (i ~= j)
                        ox  = obj.allFibrils(j).xPos - origX;
                        oy  = obj.allFibrils(j).yPos - origY;    
                        theta = atan2(oy, ox);
                        oH = oy / sin(theta);
                        newH = oH - obj.allFibrils(i).radius - obj.allFibrils(j).radius - obj.interfibrilDist;
%                         if(newH~=0)
%                             newH = 1/newH;
%                         end
                        xVec(i) = xVec(i)+(newH * cos(theta));
                        yVec(i) = yVec(i)+(newH * sin(theta));
                    end
                end
                vec(i,:) = [xVec(i), yVec(i)];
                vec(i,:) = obj.normalizeVector2d(vec(i,:));
                vec(i,:) = vec(i,:) * obj.interfibrilDist;
%                 vec(i,:) = vec(i,:)/(obj.length()-1);
            end
            for i = 1:length(obj.allFibrils)
                obj.allFibrils(i).xPos = obj.allFibrils(i).xPos + vec(i,1);
                obj.allFibrils(i).yPos = obj.allFibrils(i).yPos + vec(i,2);
            end
            push = obj.checkFibrilSpread(parentFib, true);
            while (push)
                push = obj.checkFibrilSpread(parentFib, true);
            end
        end
        
        %{
        normalizeVector2d
        ---------------------------------------------------------------------------
        Description:
            Given a 2-dimensional vector, returns a vector in the same
            direction with a magnitude of 1
        Inputs:
            obj - aMyofibrilList2 instance
            vector2d - vector to normalize
        Outputs:
            unitVec - vector in the direction of vector2d with a magnitude
            of 1
        %}
        function [unitVec] = normalizeVector2d(obj, vector2d)
            magnitude = sqrt(vector2d(1)^2 + vector2d(2)^2);
            unitVec = vector2d/magnitude;
        end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Deletes the the myofibril at a particular index in the list
        Inputs:
            obj - aMyofibrilList2 instance
            idx - index to particular myofibril in the list
        Outputs:
            NA
        %}
        function die(obj, idx)
            if (~isempty(obj.allFibrils))
                if (idx > 0 && idx <= length(obj.allFibrils))
%                     fprintf('Myofibril at idx %i is dying\n', idx);
                    obj.allFibrils(idx).die();
                    obj.allFibrils(idx) = [];
                else
                    disp('Index out of bounds. No myofibrils killed.');
                end
            else
                disp('No myofibrils left to die');
            end
        end
            
        %{
        resetFibrilGrowth
        ---------------------------------------------------------------------------
        Description:
            Resets variables having to do with myofibril growth
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            NA
        %}
        function resetFibrilGrowth(obj)
            if (~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    obj.allFibrils(i).shouldGrow = true;
                end
            end
        end
        
        %{
        clear
        ---------------------------------------------------------------------------
        Description:
            Kills and removes all myofibrils from the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            NA
        %}
        function clear(obj)
            if(~isempty(obj.allFibrils))
                for (i = 1:obj.length())
                    obj.die(1);
                end
            end
        end
        
        %{
        getAllPositions
        ---------------------------------------------------------------------------
        Description:
            Returns the x, y, and z coordinates of every muscle fiber in
            the matrix allPos
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            allPos - a matrix of all myofibril positions
        %}
        function [allPos] = getAllPositions(obj)
            allPos = zeros(obj.length(),3);
            for (i = 1:(obj.length()))
                allPos(i, 1) = obj.allFibrils(i).xPos;
                allPos(i, 2) = obj.allFibrils(i).yPos;
                allPos(i, 3) = obj.allFibrils(i).zPos;
            end
        end
        
        %{
        averageRadius
        ---------------------------------------------------------------------------
        Description:
            Returns the average radius of myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            avgR - average myofibril radius
        %}
        function avgR = averageRadius(obj)
            avgR = 0;
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    avgR = avgR + obj.allFibrils(i).radius;
                end
                avgR = avgR/obj.length();
            end
        end
        
        %{
        allRadii
        ---------------------------------------------------------------------------
        Description:
            Returns an array of the radii of all myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            radii - an array containing the radii of all myofibrils in the
            list
        %}
        function radii = allRadii(obj)
            radii = [];
            if (~isempty(obj.allFibrils))
                radii = [];
                for i = 1:obj.length()
                    radii(i) = obj.allFibrils(i).radius;
                end
            end
        end
        
        %{
        averageLength
        ---------------------------------------------------------------------------
        Description:
            Returns the average length of myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            avgL - average myofibril length
        %}
        function avgL = averageLength(obj)
            avgL = 0;
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    avgL = avgL + obj.allFibrils(i).length;
%                     if(any(isnan(obj.allFibrils(i).length)))                        
%                         sprintf('myofibril length at %i is NaN',i)
%                     end
                end
                avgL = avgL/obj.length();
            end
%             if(any(isnan(avgL)))
%                 disp('myofibril average length is NaN');
%             end
        end
        
        %{
        longestLength
        ---------------------------------------------------------------------------
        Description:
            Returns the length of the longest myofibril in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            longestL - the longest length out of the myofibrils in the list
        %}
        function longestL = longestLength(obj)
            longestL = 0;
            for i = 1:obj.length()
                if(obj.allFibrils(i).length > longestL)
                    longestL = obj.allFibrils(i).length;
                end
            end
        end
        
        %{
        averagePosition
        ---------------------------------------------------------------------------
        Description:
            Returns the coordinates of the average position of the
            myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            avgX,avgY,avgZ - average coordinates for all myofibrils in list
        %}
        function [avgX, avgY, avgZ] = averagePosition(obj)
            [positions] = obj.getAllPositions();
            if(isempty(positions))
                disp('no myofibril positions');
            end
            avgX = 0;
            avgY = 0;
            avgZ = 0;
%             if(any(any(isnan(positions))))
%                 positions
%             end
            if(~isempty(obj.allFibrils))
                avgX = sum(positions(:,1))/obj.length();
                avgY = sum(positions(:,2))/obj.length();
                avgZ = sum(positions(:,3))/obj.length();
            end
        end
        
        %{
        maxDistanceFromCentroid
        ---------------------------------------------------------------------------
        Description:
            Returns the distance of the myofibril with the largest distance
            away from the centroid of the myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            maxDistFromCent - the largest distance from a myofibril in the
            list to the centroid of the myofibrils
        %}
        function [maxDistFromCent] = maxDistanceFromCentroid(obj)
            maxDistFromCent = [];
            if(~isempty(obj.allFibrils))
                allPos = obj.getAllPositions();
                [cx,cy,cz] = obj.averagePosition();
                for i = 1:obj.length()
                    dist = sqrt((allPos(i,1)-cx)^2 + (allPos(i,2)-cy)^2);
                    if(isempty(maxDistFromCent) || dist > maxDistFromCent)
                        maxDistFromCent = dist;
                    end
                end
            end
        end
        
        %{
        allDistancesFromCentroid
        ---------------------------------------------------------------------------
        Description:
            Returns a matrix containing the distances from each myofibril
            to the centroid of the myofibrils in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            allDist - an array with the distance from each myofibril to the
            centroid of the myofibrils in the list
        %}
        function [allDist] = allDistancesFromCentroid(obj)
            allDist = [];
            if(~isempty(obj.allFibrils))
                allPos = obj.getAllPositions();
                [cx,cy,cz] = obj.averagePosition();
                for i = 1:obj.length()
                    allDist(i) = sqrt((allPos(i,1)-cx)^2 + (allPos(i,2)-cy)^2);
                end
            end
        end
        
        %{
        xyLimits
        ---------------------------------------------------------------------------
        Description:
            Returns the area in the world that the myofibrils in the list
            occupy, described using x and y bounds. Essentially gets the
            lowest and highest x and y positions out of the myofibrils in
            the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            xl - an array containing the lowest and highest x positions of
            the myofibrils in the list
            yl - an array containing the lowest and highest y positions of
            the myofibrils in the list
        %}
        function [xl, yl] = xyLimits(obj)
            xl = []; yl = [];
            if(~isempty(obj.allFibrils))
                xl(1) = obj.allFibrils(1).xPos;
                xl(2) = obj.allFibrils(1).xPos;
                yl(1) = obj.allFibrils(1).yPos;
                yl(2) = obj.allFibrils(1).yPos;
                for i = 1:obj.length()
                    xp = obj.allFibrils(i).xPos;
                    yp = obj.allFibrils(i).yPos;
                    if(xp < xl(1))
                        xl(1) = xp;
                    elseif(xp > xl(2))
                        xl(2) = xp;
                    end
                    if(yp < yl(1))
                        yl(1) = yp;
                    elseif(yp > yl(2))
                        yl(2) = yp;
                    end
                end
            end
        end
        
        %{
        checkFibrilSpread
        ---------------------------------------------------------------------------
        Description:
            Checks all myofibrils to see if they are overlapping with each
            other and pushes them away from each other if they are
        Inputs:
            obj - aMyofibrilList2 instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            pushOccurred - a boolean describing whether any myofibrils had
            to be pushed
        %}
        function [pushOccurred] = checkFibrilSpread(obj, parentFib, useSpreadConst)
            pushOccurred = false;
            if(~isempty(obj.allFibrils))
                for i = 1:(length(obj.allFibrils)-1)
                    for j = (i+1):length(obj.allFibrils)
                        fib1x = obj.allFibrils(i).xPos;
                        fib1y = obj.allFibrils(i).yPos;
                        fib1z = obj.allFibrils(i).zPos;
                        fib1r = obj.allFibrils(i).radius;
                        fib1l = obj.allFibrils(i).length;
                        fib2x = obj.allFibrils(j).xPos;
                        fib2y = obj.allFibrils(j).yPos;
                        fib2z = obj.allFibrils(j).zPos;
                        fib2r = obj.allFibrils(j).radius;
                        fib2l = obj.allFibrils(j).length;
                        while (sqrt((fib1x-fib2x)^2 + (fib1y-fib2y)^2) < (fib1r + fib2r + obj.interfibrilDist) ...
                                &&  (fib1z - fib1l/2) < (fib2z + (fib2l/2)) && ...
                                (fib1z + fib1l/2) > (fib2z - (fib2l/2)))
                            pushOccurred = true;
                            fib1x = obj.allFibrils(i).xPos;
                            fib1y = obj.allFibrils(i).yPos;
                            fib1z = obj.allFibrils(i).zPos;
                            fib1r = obj.allFibrils(i).radius;
                            fib1l = obj.allFibrils(i).length;
                            fib2x = obj.allFibrils(j).xPos;
                            fib2y = obj.allFibrils(j).yPos;
                            fib2z = obj.allFibrils(j).zPos;
                            fib2r = obj.allFibrils(j).radius;
                            fib2l = obj.allFibrils(j).length;
                            [ax,ay,az] = obj.averagePosition();
                            maxDist = obj.maxDistanceFromCentroid();
                            dist1 = sqrt((fib1x-ax)^2 + (fib1y-ay)^2);
                            dist2 = sqrt((fib2x-ax)^2 + (fib2y-ay)^2);
                            ratio = dist1/maxDist;
                            
                            if (dist2 >= dist1)
%                                 fprintf('%f > %f \n',dist2,dist1);
                                obj.allFibrils(j).fibrilPush(obj.allFibrils(i), parentFib, (obj.interfibrilDist), useSpreadConst, dist2);
%                                 obj.allFibrils(j).fibrilPush2(obj.allFibrils(i), parentFib, (obj.interfibrilDist), useSpreadConst, dist2, ax, ay);
                            else
%                                 fprintf('%f > %f \n',dist1,dist2);
                                obj.allFibrils(i).fibrilPush(obj.allFibrils(j), parentFib, (obj.interfibrilDist), useSpreadConst, dist1);
%                                 obj.allFibrils(i).fibrilPush2(obj.allFibrils(j), parentFib, (obj.interfibrilDist), useSpreadConst, dist1, ax, ay);
                            end
                        end
                    end
                end
            end
        end
        
        %{
        checkMyofibrilSplit
        ---------------------------------------------------------------------------
        Description:
            Checks all myofibrils and sees if they should split (by chance
            or radius)
        Inputs:
            obj - aMyofibrilList2 instance
            splitChance - The base split chance that is modified based on
            myofibril size
            splitRadius - The radius at which a myofibril splits
        Outputs:
            didSplit - a boolean describing whether any myofibrils in the
            list split
        %}
        function [didSplit] = checkMyofibrilSplit(obj, splitChance, splitRadius)         
            didSplit = false;
            splitsThisTick = 0;
            maxSplitsPerTick = 10000;
            if (splitChance > 0)
                if (~isempty(obj.allFibrils))
                    for i = obj.length():-1:1
                        newsplitChance = splitChance*((obj.allFibrils(i).radius*1000)^2/0.7854);
                        if (rand < newsplitChance && splitsThisTick < maxSplitsPerTick...
                                &&(obj.allFibrils(i).numSplits < obj.allFibrils(i).maxSplits || obj.allFibrils(i).maxSplits < 0))
                            didSplit = true;
                            randTheta = 2*pi()*rand();
                            newR = obj.allFibrils(i).radius/sqrt(2);
                            if(isnan(newR))
                                disp('splitting myofibril newR is NaN');
                            end
                            newz = obj.allFibrils(i).zPos;
                            newl = obj.allFibrils(i).length;
                            fibrilX = newR*cos(randTheta) +...
                                obj.allFibrils(i).xPos;
                            fibrilY = newR*sin(randTheta) +...
                                obj.allFibrils(i).yPos;
                            obj.addFibril(fibrilX, fibrilY, newz, newR, newl,...
                                obj.allFibrils(i).natGrowRate, obj.allFibrils(i).natDecayRate,...
                                obj.allFibrils(i).maxGR, obj.allFibrils(i).maxDR,...
                                obj.allFibrils(i).maxR, obj.allFibrils(i).maxL,...
                                obj.maxSplits);
                            obj.allFibrils(i).xPos = obj.allFibrils(i).xPos - newR*cos(randTheta);
                            obj.allFibrils(i).yPos = obj.allFibrils(i).yPos - newR*sin(randTheta);
                            obj.allFibrils(i).radius = newR;
                            obj.allFibrils(i).numSplits = obj.allFibrils(i).numSplits + 1;
                            obj.allFibrils(obj.length()).numSplits = obj.allFibrils(i).numSplits;
                            splitsThisTick = splitsThisTick+1;
                        end
                    end
                end
            elseif (splitRadius > 0)
                if (~isempty(obj.allFibrils))
                    for i = obj.length():-1:1
                        if (splitRadius <= obj.allFibrils(i).radius && splitsThisTick < maxSplitsPerTick...
                                &&(obj.allFibrils(i).numSplits < obj.allFibrils(i).maxSplits || obj.allFibrils(i).maxSplits < 0))
                            didSplit = true;
                            randTheta = 2*pi()*rand();
                            newR = obj.allFibrils(i).radius/sqrt(2);
                            if(isnan(newR))
                                disp('splitting myofibril newR is NaN');
                            end
                            newz = obj.allFibrils(i).zPos;
                            newl = obj.allFibrils(i).length;
                            fibrilX = newR*cos(randTheta) +...
                                obj.allFibrils(i).xPos;
                            fibrilY = newR*sin(randTheta) +...
                                obj.allFibrils(i).yPos;
                            obj.addFibril(fibrilX, fibrilY, newz, newR, newl,...
                                obj.allFibrils(i).natGrowRate, obj.allFibrils(i).natDecayRate,...
                                obj.allFibrils(i).maxGR, obj.allFibrils(i).maxDR,...
                                obj.allFibrils(i).maxR, obj.allFibrils(i).maxL,...
                                obj.maxSplits);
                            obj.allFibrils(i).xPos = obj.allFibrils(i).xPos - newR*cos(randTheta);
                            obj.allFibrils(i).yPos = obj.allFibrils(i).yPos - newR*sin(randTheta);
                            obj.allFibrils(i).radius = newR;
                            obj.allFibrils(i).numSplits = obj.allFibrils(i).numSplits + 1;
                            obj.allFibrils(obj.length()).numSplits = obj.allFibrils(i).numSplits;
                            splitsThisTick = splitsThisTick+1;
                        end
                    end
                end
            end
        end
        
        %{
        getBoundary
        ---------------------------------------------------------------------------
        Description:
            Gets a set of points that describes the outer boundary of the
            list of myofibrils as if it had been dilated. Essentially gets
            points to describe the perimeter for the group of myofibrils
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            topBounds - Matrix of x,y,z coordinates for the tops of
            myofibrils
            midBounds - Matrix of x,y,z coordinates for the middle of the
            myofibrils
            botBounds - Matrix of x,y,z coordinates for the bottoms of
            myofibrils
        %}
        function [topBounds, midBounds, botBounds] = getBoundary(obj)
            topBounds = zeros(obj.length(),3);
            botBounds = zeros(obj.length(),3);
            [cX, cY, cZ] = obj.averagePosition();
            if(any(isnan(cX)))
                disp('NaN myofibril centroid x');
            end
            if(isempty(cX))
                disp('isempty myofibril centroid x');
            end
            if(any(isnan(cY)))
                disp('NaN myofibril centroid y');
            end
            if(isempty(cY))
                disp('isempty myofibril centroid y');
            end
            if(any(isnan(cZ)))
                disp('NaN myofibril centroid z');
            end
            if(isempty(cZ))
                disp('isempty myofibril centroid z');
            end
            maxL = obj.longestLength();
            for (i = 1:(obj.length()))
                %x, y, top, bot
                topBounds(i, 1) = obj.allFibrils(i).xPos;
                topBounds(i, 2) = obj.allFibrils(i).yPos;
                topBounds(i, 3) = obj.allFibrils(i).zPos + (maxL/2);
                if(any(isnan(obj.allFibrils(i).zPos)))
                    disp('bad Z');
                end
                if(any(isnan(obj.allFibrils(i).length)))
                    disp('bad length');
                end
                botBounds(i, 1) = obj.allFibrils(i).xPos;
                botBounds(i, 2) = obj.allFibrils(i).yPos;
                botBounds(i, 3) = obj.allFibrils(i).zPos - (maxL/2);                
                
%                 theta = atan2(topBounds(i, 2)-cY, topBounds(i, 1)-cX);
%                 dx = (obj.edgeDist + obj.allFibrils(i).radius) * cos(theta);
%                 dy = (obj.edgeDist + obj.allFibrils(i).radius) * sin(theta);
%                 topBounds(i, 1) = topBounds(i, 1) + dx;
%                 topBounds(i, 2) = topBounds(i, 2) + dy;
%                 botBounds(i, 1) = botBounds(i, 1) + dx;
%                 botBounds(i, 2) = botBounds(i, 2) + dy;
            end
            tempTopZ = topBounds(:,3);
            tempBotZ = botBounds(:,3);
            radii = obj.allRadii();
            avgR = obj.averageRadius();
            [xl, yl] = obj.xyLimits();
            if(~isempty([xl yl]))
                xspread = xl(2)-xl(1);
                yspread = yl(2)-yl(1);
                xl(1) = xl(1)-(avgR+obj.edgeDist*2)*1.1; xl(2) = xl(2)+(avgR+obj.edgeDist*2)*1.1;
                yl(1) = yl(1)-(avgR+obj.edgeDist*2)*1.1; yl(2) = yl(2)+(avgR+obj.edgeDist*2)*1.1;
                [x, y] = obj.makeBoundaryPoints(topBounds, obj.projectionQuality, radii, (xl*1), (yl*1));
                if (~isempty(x) && ~isempty(y))
                    x = x';
                    y = y';
                    topxyz = [x, y];
                    topxyz(:,3) = tempTopZ(1);            
                    botxyz = [x, y];
                    botxyz(:,3) = tempBotZ(1);
                    midZ = (tempTopZ(1)+tempBotZ(1))/2;
                    midxyz = [x, y];
                    midxyz(:,3) = midZ;
                    topBounds = topxyz;
                    botBounds = botxyz;
                    midBounds = midxyz;
                    l = length(topBounds);
                    topBounds(l+1, 1) = cX;
                    topBounds(l+1, 2) = cY;
                    topBounds(l+1, 3) = cZ + (maxL/2);
                    botBounds(l+1, 1) = cX;
                    botBounds(l+1, 2) = cY;
                    botBounds(l+1, 3) = cZ - (maxL/2);
                    midBounds(l+1, 1) = midBounds(1,1);
                    midBounds(l+1, 2) = midBounds(1,2);
                    midBounds(l+1, 3) = midZ;
                else
                    disp('hello');
    %                 topBounds
                    topBounds = []; midBounds = []; botBounds = [];
                end
            else
                topBounds = []; midBounds = []; botBounds = [];
            end
        end
        
        %{
        makeBoundaryPoints
        ---------------------------------------------------------------------------
        Description:
            Calls xy2grid and expand with an original set of myofibril
            centers to obtain a set of points describing the boundaries of
            myofibrils
        Inputs:
            obj - aMyofibrilList2 instance
            xy - a #myofibrils-by-2 matrix describing myofibril centers on
            the xy plane
            n - the "projection resolution" that determines how precies the
            found boundary points will be
            r - an array of the radii of all myofibrils
            xl,yl - the boundaries of the group of myofibrils
        Outputs:
            xb,yb - Spatial coordinates describing the boundary points of
            the myofibrils
        %}
        function [xb, yb] = makeBoundaryPoints(obj, xy, n, r, xl, yl)
            [nx, ny] = obj.xy2grid(xy(:,1), xy(:,2), n, xl, yl);
            [xb, yb] = obj.expand(nx,ny,n,r,xl,yl);
%             xb = xb + xl(1);
%             yb = yb + yl(1);
        end
        
        %{
        xy2grid
        ---------------------------------------------------------------------------
        Description:
            Converts a set of x,y coordinates to corresponding pixel values on a
            n-by-n grid.
        Inputs:
            obj - aMyofibrilList instance
            x,y - A set of points describing myofibril centers
            n - number of pixel on each axis
            xl,yl - limits of group of myofibrils
        Outputs:
            gridx,gridy - myofibril centers on a binary image
        %}
        function [gridx, gridy] = xy2grid(obj, x, y, n, xl, yl)
            xpix = (xl(2)-xl(1))/n;
            ypix = (yl(2)-yl(1))/n;
            for i = 1:numel(x)        
                gridx(i) = round((x(i)-xl(1)) / xpix);
                gridy(i) = round((y(i)-yl(1)) / ypix);
            end
            gridx;
            gridy;
%             bw = zeros(n);
%             for j = 1:numel(gridx)
%                 if(gridy(j) > 0 && gridx(j) > 0)
%                     bw(gridx(j),gridy(j))=1;
%                 end
%             end
        end
        
        %{
        grid2xy
        ---------------------------------------------------------------------------
        Description:
            Converts pixel coordinates into spatial (x,y) coordinates to
            place back into the simulation
        Inputs:
            obj - aMyofibrilList instance
            x,y - A set of points describing myofibril centers in "pixel
            space"
            n - number of pixel on each axis
            xl,yl - limits of each axis
        Outputs:
            newx,newy - x,y coordinates in space
        %}
        function [newx, newy] = grid2xy(obj, x, y, n, xl, yl)
            xpix = (xl(2)-xl(1))/n;
            ypix = (yl(2)-yl(1))/n;
            newx = [];
            newy = [];
            for i = 1:numel(x)
                newx(i) = (x(i)*xpix)+(xl(1));
                newy(i) = (y(i)*ypix)+(yl(1));
            end
        end
        
        %{
        expand
        ---------------------------------------------------------------------------
        Description:
            Takes 'Grid coordinates' of myofibril centers and dilates them
            to be an edgeDist larger than the myofibril radii
        Inputs:
            obj - aMyofibrilList2 instance
            x,y - A set of points describing myofibril centers in "pixel
            space"
            n - number of pixel on each axis
            r - an array containing the radius for each myofibril
            xl,yl - the limits of the group of myofibrils
        Outputs:
            xpoints,ypoints - spatial points describing the dilated
            myofibrils
        %}
        function [xpoints, ypoints] = expand(obj, x, y, n, r, xl, yl)
            projection = zeros(n);
            bw = projection;
            xpix = (xl(2)-xl(1))/(n);
            ypix = (yl(2)-yl(1))/(n);
            [cols, rows] = meshgrid(1:n, 1:n);
            for j = 1:numel(r)
                if (x(j) > 0 && y(j) > 0)
                    bw(x(j),y(j))=1;                    
                    circlePixels = (cols-y(j)).^2 ...
                        + (rows-x(j)).^2 <= ((r(j)/xpix)+(obj.edgeDist/xpix)).^2;
%                     numel(find(circlePixels))
                    bw = bw + circlePixels;
                end
            end            
            %dilater = strel('disk',ceil((r/xpix)+(obj.edgeDist/xpix)));
            %bw = imdilate(bw,dilater);
            bw = bwperim(bw);       
            [xg,yg] = find(bw);
            [xpoints, ypoints] = obj.grid2xy(xg,yg,n,xl,yl);
        end
        
        %{
        
        ---------------------------------------------------------------------------
        Description:
            
        Inputs:
            
        Outputs:
            
        %}
        function [allOut] = checkMyofibrilsInWorld(obj, xl, yl)
            allOut = true;
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    if(~(obj.allFibrils(i).xPos<xl(1)...
                            || obj.allFibrils(i).xPos>xl(2)...
                            || obj.allFibrils(i).yPos<yl(1)...
                            || obj.allFibrils(i).yPos>yl(2)))
                        allOut = false;
                    end
                end
            end
            if(allOut)
                disp('all out');
            end
        end
        
        %total volume in CUBIC MICROMETERS
        function [totalVol] = totalVolume(obj)
            totalVol = 0;
            if(~isempty(obj.allFibrils))
                for i = 1:obj.length()
                    totalVol = totalVol +...
                        ((obj.allFibrils(i).radius*1000)^2 * (obj.allFibrils(i).length*1000))*pi;
                end
            end
        end
        
        function s = saveState(obj)
            if (~isempty(obj.allFibrils))
                s.number = obj.length();     
                s.avgLength = obj.averageLength();
                s.allPos = obj.getAllPositions();
                for i = 1:obj.length()
                    s.radius(i) = obj.allFibrils(i).radius;
                    s.length(i) = obj.allFibrils(i).length;
                    s.volume(i) = pi * (s.radius(i)^2) * s.length(i);                    
                end
            else
                s = struct([]);
            end
        end
        
        
    end
    
    
end