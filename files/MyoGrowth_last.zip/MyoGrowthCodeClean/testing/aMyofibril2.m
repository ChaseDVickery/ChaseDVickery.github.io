classdef aMyofibril2 < matlab.mixin.SetGetExactNames
    %{
    aMyofibril Class
    
    Purpose: 
        Agent based on myofibrils contained within skeletal muscle cells (aMuscleFiber).
        Their purpose is to brow based on external factors and internal
        constants.
    
    Description:
        Myofibrils will be contained within muscle fibers (aMuscleFiber).
        Myofibrils will grow based on proximity and number of nuclei inside
        the cell as well as constants. Myofibrils will only be able to grow
        to a certain size before splitting into 2 myofibrils.
    
    TODO:
        -Remove/Replace the roll function
        -Remove/Replace the rllAwayFrom function
        -Redo move function
    %}
    
    properties
        xPos;                           %x position in 3D
        yPos;                           %y position in 3D
        zPos;                           %z position in 3D
        radius;                         %radius of cell for contact detection
        maxR;
        length;
        maxL;
        maxSplits;
        numSplits;
        natGrowRate;
        maxGR;
        natDecayRate;
        maxDR;
        delTheta;
        touchingEdge;
        spreadConstant;
    end
    
    properties (Constant)
        
    end
    
    methods
        %{
        aMyofibril2 constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aMyofibril2
        Inputs:
            x-l - defines a cylinder in space
            gr - growth rate constant of the myofibril
            dr - decay rate constant of the myofibril
            maxgr,maxdr - max allowable gr and dr
            maxr,maxl - max allowable radius and length
            maxsplits - max allowable number of splits
        Outputs:
            obj - aMyofibril2 instance
        %}
        function obj = aMyofibril2(x, y, z, r, l, gr, dr, maxgr, maxdr, maxr, maxl, maxsplits)
            obj.natGrowRate = 0;
            obj.natDecayRate = 0;
            obj.delTheta = pi()/72; %in radians
            obj.touchingEdge = false;
            obj.numSplits = 0;
            obj.maxSplits = 0;
            obj.spreadConstant = 1;
            if nargin == 0
                obj.xPos = 0;
                obj.yPos = 0;
                obj.zPos = 0;
                obj.radius = 1;
                obj.length = 1;
            elseif nargin == 3
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = 1;
                obj.length = 1;
            elseif nargin == 4
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = 1;
            elseif nargin == 5
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
            elseif nargin == 7
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
                obj.natGrowRate = gr;
                obj.natDecayRate = dr;
            elseif nargin == 9
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
                obj.natGrowRate = gr;
                obj.natDecayRate = dr;
                obj.maxGR = maxgr;
                obj.maxDR = maxdr;
            elseif nargin == 11
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
                obj.natGrowRate = gr;
                obj.natDecayRate = dr;
                obj.maxGR = maxgr;
                obj.maxDR = maxdr;
                obj.maxR = maxr;
                obj.maxL = maxl;
            elseif nargin == 12
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.radius = r;
                obj.length = l;
                obj.natGrowRate = gr;
                obj.natDecayRate = dr;
                obj.maxGR = maxgr;
                obj.maxDR = maxdr;
                obj.maxR = maxr;
                obj.maxL = maxl;
                obj.maxSplits = maxsplits;
            else
                error('aMyofibril : aMyofibril: Wrong number of input arguments');
            end
%             obj.maxGR
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates the myofibril
                -Growth
        Inputs:
            obj - aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
            mechs - a structure of mechanisms
            localDistSum - a sum of 1/(myofibril from nuc dist)^2
            totalVol - a sum of all myofibril volumes in cubic �m
        Outputs:
            NA
        %}
        function update(obj, parentFib, mechs, localDistSum, totalVol)
            gr = obj.natGrowRate;
            dr = obj.natDecayRate;
            
            volRatio = totalVol/11.7810;
            if(isempty(volRatio))
                disp('volRatio empty');
            end
            if(isnan(volRatio))
                disp('volRatio is NaN');
            end
            if(isinf(volRatio))
                disp('volRatio is Inf');
            end
            growMechProp = 1;
            decayMechProp = 1;
            
            growDistNucWeight = 1;
            decaySizeMyofibrilWeight = 1;
            decayFiberCSAWeight = 0.3;
            
            if(mechs.myofibrilgrownumnucleus)
                tempgr = growMechProp*parentFib.myNuclei.length();
                if(~any(isnan(tempgr)))
                    growMechProp = tempgr;
                else
                    disp('NaN tempgr myofibrilgrownumnucleus');
                end
            end
            if(mechs.myofibrilgrowdistnucleus)
                tempgr = growMechProp*growDistNucWeight*localDistSum;
                if(isempty(localDistSum))
                    disp('dist sums empty');
                end
                if(isnan(localDistSum))
                    disp('dist sums is NaN');
                end
                if(isinf(localDistSum))
                    disp('dist sums is Inf');
                end
                if(~any(isnan(tempgr)))
                    growMechProp = tempgr;
                else
                    disp('NaN tempgr myofibrilgrowdistnucleus');
                end
            end
            if(mechs.myofibrilgrownucleardensity)
%                 tempgr = gr * (parentFib.myNuclei.length()/totalVol);
                tempgr = growMechProp * (parentFib.myNuclei.length()/volRatio);
                if(~any(isnan(tempgr)))
                    growMechProp = tempgr;
                else
                    disp('NaN tempgr myofibrilgrownucleardensity');
                end
            end
            
            if(mechs.myofibrildecaysizemyofibril)
                tempdr = decayMechProp * decaySizeMyofibrilWeight * ((obj.radius*1000)^2);
                if(isempty(obj.radius))
                    disp('radius empty');
                end
                if(isnan(obj.radius))
                    disp('radius is NaN');
                end
                if(isinf(obj.radius))
                    disp('radius is Inf');
                end
                if(~any(isnan(tempdr)))
                    decayMechProp = tempdr;
                else
                    disp('NaN tempdr myofibrildecaysizemyofibril');
                end
            end
            if(mechs.myofibrildecaynummyofibril)
                tempdr = decayMechProp * parentFib.myMyofibrils.length();
                if(~any(isnan(tempdr)))
                    decayMechProp = tempdr;
                else
                    disp('NaN tempdr myofibrildecaynummyofibril');
                end
            end
            if(mechs.myofibrildecaytotalvolume)
%                 tempdr = dr * totalVol;
                tempdr = decayMechProp * volRatio;
                if(~any(isnan(tempdr)))
                    decayMechProp = tempdr;
                else
                    disp('NaN tempdr myofibrildecaytotalvolume');
                end
            end
            if(mechs.myofibrildecayfiberarea)
                tempdr = decayMechProp * decayFiberCSAWeight * parentFib.csa;
                if(isempty(parentFib.csa))
                    disp('CSA empty');
                end
                if(isnan(parentFib.csa))
                    disp('CSA is NaN');
                end
                if(isinf(parentFib.csa))
                    disp('CSA is Inf');
                end
                if(~any(isnan(tempdr)))
                    decayMechProp = tempdr;
                else
                    disp('NaN tempdr myofibrildecayfiberarea');
                end
            end
%             parentFib.csa
            
%             growMechProp
%             decayMechProp
            if(isempty(growMechProp))
                disp('growMechProp empty');
            end
            if(isnan(growMechProp))
                disp('growMechProp is NaN');
            end
            if(isinf(growMechProp))
                disp('growMechProp is Inf');
            end
            if(isempty(decayMechProp))
                disp('decayMechProp empty');
            end
            if(isnan(decayMechProp))
                disp('decayMechProp is NaN');
            end
            if(isinf(decayMechProp))
                disp('decayMechProp is Inf');
            end
            gr = gr * growMechProp;
            dr = dr * decayMechProp;
%             a = 0.7;
%             b = 1.3;
%             gr = gr * (a + (b-a)*rand(1,1));
%             dr = dr * (a + (b-a)*rand(1,1));
%             if(gr > obj.maxGR && obj.maxGR >= 0)
% %                 disp('lowering gr');
%                 gr = obj.maxGR;
%             end
%             if(dr > obj.maxDR && obj.maxDR >= 0)
% %                 disp('lowering dr');
%                 dr = obj.maxDR;
%             end
%             dr
            obj.grow(gr,dr);
            obj.spreadConstant = 1;
        end
        
        %function resetVec(obj)
        %    obj.touchingEdge = false;
        %end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Deletes the myofibril
        Inputs:
            obj - aMyofibril2 instance
        Outputs:
            NA
        %}
        function die(obj)
            disp('fibril dying');
            delete(obj);
        end
        
        %{
        grow
        ---------------------------------------------------------------------------
        Description:
            Tells the myofibril to grow based on given gr, dr
        Inputs:
            obj - aMyofibril2 instance
            gr - the amount it should grow
            dr - the amount it should decay
        Outputs:
            NA
        %}
        function grow(obj, gr, dr)
            if (~obj.touchingEdge)
%                 if (gr > obj.maxGR)
%                     gr = obj.maxGR;
%                 end
%                 if (dr > obj.maxDR)
%                     dr = obj.maxDR;
%                 end
%                 rad2len = 0.35/obj.numSplits;
rad2len = 1;
len2rad = 20;
% gr
% dr
% gr-dr
                if (any(isnan(gr)))
                    disp('bad grow rate');
                end
                if (any(isinf(gr)))
                    disp('bad grow rate (inf)');
                end
                if (any(isnan(dr)))
                    disp('bad decay rate');
                end
                if (any(isinf(dr)))
                    disp('bad decay rate (inf)');
                end
                obj.radius = obj.radius + ((gr - dr)*rad2len);
                obj.length = obj.length + ((gr - dr)*len2rad);
%                 if(obj.radius > obj.maxR && obj.maxR > 0)
%                     obj.radius = obj.maxR;
%                 end
%                 if(obj.length > obj.maxL && obj.maxL > 0)
%                     obj.length = obj.maxL;
%                 end
            else
                %obj.roll(parentFib);
            end
        end
        
        function [vol] = getVolume(obj)
            vol = ((obj.radius*1000)^2)*obj.length*1000;
        end
        
        %TO DELETE
        %{
        roll
        ---------------------------------------------------------------------------
        Description:
            Makes the fibril roll along the inside of the fiber.
        Inputs:
            obj - aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function roll(obj, parentFib)
%             rebMag = sqrt(rebVecx^2 + rebVecy^2);
%             sprMag = sqrt(sprVecx^2 + sprVecy^2);
%             if (rebMag == 0 || sprMag == 0)
%                 rollVecx = 0; rollVecy = 0;
%             else
%                 disp('NOT zeros');
%                 rollVecx = (rebVecx/rebMag) + (sprVecx/sprMag);
%                 rollVecy = (rebVecy/rebMag) + (sprVecy/sprMag);
%             end
%             obj.xPos = obj.xPos + 3*rollVecx;
%             obj.yPos = obj.yPos + 3*rollVecy;
            x = obj.xPos - parentFib.xPos;
            y = obj.yPos - parentFib.yPos;
            theta0 = atan2(y, x);
            thetaNew = obj.delTheta + theta0;
            newx = ((parentFib.radius - obj.radius) * cos(thetaNew)) + parentFib.xPos;
            newy = ((parentFib.radius - obj.radius) * sin(thetaNew)) + parentFib.yPos;
            obj.xPos = newx; obj.yPos = newy;
        end
        
        %TO DELETE
        %{
        rollAwayFrom
        ---------------------------------------------------------------------------
        Description:
            Makes myofibrils roll in opposite directions if touching
            another myofibril
        Inputs:
            obj - this aMyofibril instance
            otherfibril - another aMyofibril instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function rollAwayFrom(obj, otherfibril, parentFib)
            obj.delTheta = -1*obj.delTheta;
            obj.roll(parentFib);
            otherfibril.roll(parentFib);
            obj.delTheta = -1*obj.delTheta;
        end
        
        %TO DELETE
        %{
        move
        ---------------------------------------------------------------------------
        Description:
            Moves the myofibril towards the outer part of the fiber based
            on a gradient
        Inputs:
            obj - aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function move(obj, parentFib)
            x = obj.xPos - parentFib.xPos;
            y = obj.yPos - parentFib.yPos;
            dx = 1/(100*(x));
            dy = 1/(100*(y));
            if (x == 0 && y == 0)
                dx = 0.1;
                dy = 0.1;
            else
                %if moving would put it out of the fiber, don't move
                if (sqrt((x + dx)^2 + (y + dy)^2) > parentFib.radius - obj.radius)
                    dx = 0; dy = 0;
                    %if fiber is really close to parent position 
                    if (sqrt((x)^2 + (y)^2) < parentFib.radius/10 || x == 0 || y == 0)
                        dx = 0.1; dy = 0.1;
                        if (x < 0)
                            dx = -1*dx;
                        end
                        if (y < 0)
                            dy = -1*dy;
                        end
                    end
                end
            end
            obj.xPos = obj.xPos + dx;
            obj.yPos = obj.yPos + dy;
        end
        
        %TO CHANGE
        %{
        fibrilPush
        ---------------------------------------------------------------------------
        Description:
            Called by a list of myofibrils that pushes this fibril and
            another fibril away from each other by an equal amount until
            they are no longer in contact
        Inputs:
            obj - aMyofibril2 instance
            otherfibril - another aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
            interDist - extra distance between myofibrils
            useSC - boolean whether the spread constant should be used
            dist - distance from myofibril centroid
        Outputs:
            NA
        %}
        function fibrilPush(obj, otherfibril, parentFib, interDist, useSC, dist)
            x = obj.xPos - otherfibril.xPos;
            y = obj.yPos - otherfibril.yPos;
            if(x^2==0 && y^2==0)
                x = obj.radius*rand()/2;
                y = obj.radius*rand()/2;
                disp('myofibrils on same position. Changing.');
            end
            
            sc = 2;
%             distFromCentRatio = 50;
%             disp(distFromCentRatio);

%             distFromCentRatio = distFromCentRatio*sqrt(2);
%             if(distFromCentRatio < 1)
                distanceRatio = 1;
%             end
            
%             distanceRatio = dist/obj.radius;
            
%             sc = (obj.spreadConstant + otherfibril.spreadConstant)/2;
%             sc = 1/sc;
%             obj.spreadConstant = obj.spreadConstant+1;
%             otherfibril.spreadConstant = otherfibril.spreadConstant+1;
            if(useSC)
                newx = sqrt((x^2 * (obj.radius + otherfibril.radius + interDist*sc*distanceRatio)^2) / (x^2 + y^2));
                newy = sqrt((y^2 * (obj.radius + otherfibril.radius + interDist*sc*distanceRatio)^2) / (x^2 + y^2));
            else                
                newx = sqrt((x^2 * (obj.radius + otherfibril.radius + interDist)^2) / (x^2 + y^2));
                newy = sqrt((y^2 * (obj.radius + otherfibril.radius + interDist)^2) / (x^2 + y^2));
            end
            if (x >= 0)
                dx = (((newx - x))/2);
            else
                dx = (((-newx - x))/2);
            end
            if (y >= 0)
                dy = (((newy - y))/2);
            else
                dy = (((-newy - y))/2);
            end
            if(isnan(dx))
                disp('dx is NaN');
            end
            if(isnan(dy))
                disp('dy is NaN');
            end
%             if (obj.touchingEdge == false && otherfibril.touchingEdge == false)
                obj.xPos = obj.xPos + dx;
                otherfibril.xPos = otherfibril.xPos - dx;
                obj.yPos = obj.yPos + dy;
                otherfibril.yPos = otherfibril.yPos - dy;
%             elseif (obj.touchingEdge == true && otherfibril.touchingEdge == false)
%                 otherfibril.xPos = otherfibril.xPos - 2*dx;
%                 otherfibril.yPos = otherfibril.yPos - 2*dy;                
%             elseif (obj.touchingEdge == false && otherfibril.touchingEdge == true)
%                 obj.xPos = obj.xPos + 2*dx;
%                 obj.yPos = obj.yPos + 2*dy;
%             end
        end
        
        %TO CHANGE
        %{
        fibrilPush2
        ---------------------------------------------------------------------------
        Description:
            Pushesone myofibril the full distance of the push away from the
            myofibril centroid
        Inputs:
            obj - aMyofibril2 instance
            otherfibril - another aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
            interDist - interfibril distance
            useSC - boolean whether to use spread constant
            dist - distance from myofibril centroid
            cx,cy - myofibril centroid
        Outputs:
            NA
        %}
        function fibrilPush2(obj, otherfibril, parentFib, interDist, useSC, dist, cx, cy)
            x = obj.xPos - cx;
            y = obj.yPos - cy;
            theta = atan2(y,x);
            newH = sqrt(x^2 + y^2) + interDist;
            dx = interDist*cos(theta);
            dy = interDist*sin(theta);
            obj.xPos = obj.xPos + dx;
            obj.yPos = obj.yPos + dy;

        end
        
        %TO DELETE
        %{
        rebound
        ---------------------------------------------------------------------------
        Description:
            Pushes the myofibril away from the edge of the fiber if
            touching
        Inputs:
            obj - aMyofibril2 instance
            parentFib - aMuscleFiber2 instance
        Outputs:
            NA
        %}
        function rebound(obj, parentFib)
            x = obj.xPos - parentFib.xPos;
            y = obj.yPos - parentFib.yPos;
%             obj.touchingEdge = true;
            newx = sqrt((x^2 * (parentFib.radius - obj.radius)^2) / (x^2 + y^2));
            newy = sqrt((y^2 * (parentFib.radius - obj.radius)^2) / (x^2 + y^2));
            if (x >= 0)
                newx = (newx + 0.01) + parentFib.xPos;
            else
                newx = -1*(newx + 0.01) + parentFib.xPos;
            end
            if (y >= 0)
                newy = (newy + 0.01) + parentFib.yPos;
            else
                newy = -1*(newy + 0.01) + parentFib.yPos;
            end
            obj.xPos = newx;
            obj.yPos = newy;
            %obj.radius = obj.radius + obj.natDecayRate;
        end
    end
end