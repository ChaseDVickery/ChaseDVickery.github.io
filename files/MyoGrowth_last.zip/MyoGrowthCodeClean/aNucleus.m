classdef aNucleus < matlab.mixin.SetGetExactNames
    %{
    aNucleus Class
    
    Purpose: 
        Agent based on nucleus of skeletal muscle fibers. Their purpose is
        to create and grow myofibrils (aMyofibril).
    
    Description:
        Nuclei will be part of myoblasts (aMyoblast) until otherwise
        contributed to a muscle fiber (aMuscleFiber). Once inside a muscle
        fiber, a nucleus will contribute to the creation and growth of
        myofibrils based on their proximity.
    
    
    %}
    
    properties
        xPos;                           %x position in 3D
        yPos;                           %y position in 3D
        zPos;                           %z position in 3D
        speed;                          %+/- max distance traveled in each dimension each time step
        radius;                         %radius of cell for contact detection
    end
    
    properties (Constant)
        
    end
    
    methods
        %{
        aNucleus constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aNucleus
        Inputs:
            x,y,z,r - defines a sphere in space
            spd - speed of floating nucleus in fiber
        Outputs:
            obj - aNucleus instance
        %}
        function obj = aNucleus(x, y, z, spd, r)
            if nargin == 0
                obj.xPos = 0;
                obj.yPos = 0;
                obj.zPos = 0;
                obj.speed = 0.5;
                obj.radius = 1;
            elseif nargin == 4
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = 1;
            elseif nargin == 5
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = r;
            else
                error('aNucleus : aNucleus : Wrong number of input arguments');
            end
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates the nucleus
                -Moves it
        Inputs:
            obj - aNucleus instance
            xb,yb,zb,rb,lb - defines confining cylinder of surrounding
            muscle fiber
        Outputs:
            NA
        %}
        function update(obj, bounds, fibrils, sv, mechs)
            vector = zeros(1,3);
            if(mechs.nucleusrandomspread)
%                 obj.move(bounds);
                randvec = obj.getMoveRandom();                
                randvec = obj.normalizeVector(randvec);                
                vector(1) = vector(1) + randvec(1);
                vector(2) = vector(2) + randvec(2);
                vector(3) = vector(3) + randvec(3);
            end
            if(mechs.nucleuspushspread && ~isempty(sv) && any(sv))
                sv = obj.normalizeVector(sv);                
                vector(1) = vector(1) + sv(1);
                vector(2) = vector(2) + sv(2);
                vector(3) = vector(3) + sv(3);
            end
            vector = obj.normalizeVector(vector);            
            vector = vector*obj.speed;            
            obj.move(bounds,fibrils,vector);
        end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Deletes the nucleus
        Inputs:
            obj - aNucleus instance
        Outputs:
            NA
        %}
        function die(obj)
            delete(obj);
        end
        
        function [unitVec] = normalizeVector(obj, vector3d)
            magnitude = sqrt(vector3d(1)^2 + vector3d(2)^2 + vector3d(3)^2);
            unitVec = vector3d/magnitude;
        end
        
        %{
        move
        -------------------------------------------------------------------
        Description:
            Moves to a new random position based on its speed after it
            verifies the position is value with checkContact
        Inputs:
            obj - aNucleus instance
            xb,yb,zb - defines position of surrounding fiber
            boundary - defines boundary of fiber
        Outputs:
            NA
        %}
        function move(obj, bounds, fibrils, vec)%sv)  
            if(any(isnan(vec)))
                disp('bad nucleus movement vector');
            end
            newx = obj.xPos + vec(1);
            newy = obj.yPos + vec(2);
            newz = obj.zPos + vec(3);
            [xyValid,zValid] = obj.checkContactFibrils([newx newy newz],fibrils);
            if (obj.checkContactBounds(newx,newy, bounds) && xyValid)
                obj.xPos = newx;
                obj.yPos = newy;
            end
            if (obj.checkContactEnds(newz, bounds) && zValid)
%                 fprintf('old z: %f\nnew z: %f\n',obj.zPos,newz);
                obj.zPos = newz;
            end
        end
        
        function [randvec] = getMoveRandom(obj)
            randvec(1) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(2) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(3) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
        end
        
        %{
        move
        -------------------------------------------------------------------
        Description:
            Moves to a new random position based on its speed after it
            verifies the position is value with checkContact
        Inputs:
            obj - aNucleus instance
            xb,yb,zb - defines position of surrounding fiber
            boundary - defines boundary of fiber
        Outputs:
            NA
        %}
%         function movepush(obj, bounds, sv)%centroid)           
%             xPos = obj.xPos;
%             yPos = obj.yPos;
%             zPos = obj.zPos;
%             speed = obj.speed;
%             newx = 0; newy = 0; newz = 0;
%             if(~isempty(sv))
% %                 vec = [xPos-centroid(1), yPos-centroid(2), zPos-centroid(3)];
% %                 mag = sqrt(vec(1)^2 + vec(2)^2 + vec(3)^2);
% %                 vec = (vec/mag) * (obj.speed);                
% %                 newx = xPos + vec(1);
% %                 newy = yPos + vec(2);
% %                 newz = zPos + vec(3);
%                 svmag = sqrt(sv(1)^2 + sv(2)^2 + sv(3)^2);
%                 sv = (sv/svmag) * speed;
%                 newx = xPos + sv(1);
%                 newy = yPos + sv(2);
%                 newz = zPos + sv(3);
%             end
%             if (obj.checkContact(newx,newy,newz, bounds))
%                 obj.xPos = newx;
%                 obj.yPos = newy;
%                 obj.zPos = newz;
%             end
%         end
        
        %{
        checkContact
        -------------------------------------------------------------------
        Description:
            Checks if a new position would be valid and returns a boolean
            of 1 if it can move there and 0 if not.
        Inputs:
            obj - aNucleus instance
            xNew,yNew,zNew - proposed new position of myoblast
            xb,yb,zb,rb,lb - defines boundaries of surrounding fiber
        Outputs:
            isPositionValid - a boolean saying if proposed position is
            within the fiber
        %}
        function [isPositionValid] = checkContactBounds(obj, xNew, yNew, bounds)
            %if (abs(xNew-xb) < rb && abs(yNew-yb) < rb && zNew > (zb - lb/2) && zNew < (zb + lb/2))
            shape = vertcat(bounds(:,:,1),bounds(:,:,2),bounds(:,:,3));
            shape(:,3) = [];
            shapex = shape(:,1);
            shapey = shape(:,2);
            k = boundary(shapex, shapey);
            if (inpolygon(xNew,yNew,shapex(k),shapey(k)))
                isPositionValid = true;                
            else
                isPositionValid = false;
            end
        end
        
        function [isPositionValid] = checkContactEnds(obj, zNew, bounds)
            %if (abs(xNew-xb) < rb && abs(yNew-yb) < rb && zNew > (zb - lb/2) && zNew < (zb + lb/2))
            top = bounds(1,3,1);
            bot = bounds(1,3,3);
            if (zNew > bot && zNew < top)
                isPositionValid = true;                
            else
                isPositionValid = false;
            end
        end
        
        function [xyValid,zValid] = checkContactFibrils(obj, newpos, fibrils)
            xyValid = true;
            zValid = true;
            if(~isempty(fibrils.allFibrils))
                for i = 1:fibrils.length()
                    fib = fibrils.getFibril(i);
                    dist = sqrt((newpos(1)-fib.xPos)^2 +...
                        (newpos(2)-fib.yPos)^2);
                    top = fib.zPos+(fib.length/2);
                    bot = fib.zPos-(fib.length/2);
                    if(dist < obj.radius + fib.radius && newpos(3) < top && newpos(3) > bot)
                        if(~(obj.zPos < top && obj.zPos > bot))
                            xyValid = true;
                            zValid = false;
                        elseif(dist < obj.radius + fib.radius)
                            xyValid = false;
                            zValid = true;
                        else
                            xyValid = false;
                            zValid = true;
                        end
                    end
                end
            end
        end
        
        
        %{
        fibrilPush
        ---------------------------------------------------------------------------
        Description:
            Pushes the nucleus away from myofibrils if they are too close
        Inputs:
            obj - aNucleus instance
            fibx-fibl - defines a myofibril cylinder in space
        Outputs:
            NA
        %}
        function fibrilPush(obj, fibx, fiby, fibz, fibr, fibl)
%             if(any(isnan(fibx)))
%                 disp('bad fibx');
%             end
%             if(any(isnan(fiby)))
%                 disp('bad fiby');
%             end
%             if(any(isnan(obj.xPos)))
%                 disp('bad nucx');
%             end
%             if(any(isnan(obj.yPos)))
%                 disp('bad nucy');
%             end
            x = obj.xPos - fibx;
            y = obj.yPos - fiby;
            if(x^2==0 && y^2==0)
                x = obj.radius*rand();
                y = obj.radius*rand();
            end
%             if(x^2==0 && y^2==0)
%                 disp('bad difference');
%             end
%             if(any(isnan(fibr)))
%                 disp('bad fibr');
%             end
%             if(any(isnan(obj.radius)))
%                 disp('bad nucr');
%             end
            newx = sqrt((x^2 * ((fibr+obj.radius)/0.99)^2) / (x^2 + y^2));
            newy = sqrt((y^2 * ((fibr+obj.radius)/0.99)^2) / (x^2 + y^2));
            if(any(isnan(newx)))
                disp('bad newx');
            end
            if(any(isnan(newy)))
                disp('bad newy');
            end
            if (x >= 0)
                dx = (((newx - x)));
            else
                dx = (((-newx - x)));
            end
            if (y >= 0)
                dy = (((newy - y)));
            else
                dy = (((-newy - y)));
            end
            obj.xPos = obj.xPos + dx;
            obj.yPos = obj.yPos + dy;
        end
    end
end