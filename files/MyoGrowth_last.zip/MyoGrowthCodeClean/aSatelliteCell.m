classdef aSatelliteCell < matlab.mixin.SetGetExactNames
    %{
    aSatelliteCell Class
    
    Purpose: 
        Agent based on satellite cells of skeletal muscle. Their purpose is
        to spawn myoblasts.
    
    Description:
        Satellite cells will float randomly within a constrained environment. 
        At any given timestep, satellite cells will have an independent chance to
        die or spawn a myoblast (aMyoblast class). When encountering a
        muscle fiber (aMuscleFiber class), the satellite cell will stick to
        that point on the fiber.
    
    Methods:
        
    
    TODO:
        make move function more efficient
    %}
    
    properties
        xPos;                           %x position in 3D
        yPos;                           %y position in 3D
        zPos;                           %z position in 3D
        speed;                          %+/- max distance traveled in each dimension each time step
        radius;                         %radius of cell for contact detection
        fusedStatus;                    %boolean expressing whether it is fused or not
        connectedFiberIdx;
        fiberPlaceRatio=0;
    end
    
    properties (Constant)
        
    end
    
    methods
        %{
        aSatelliteCell constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aSatelliteCell
        Inputs:
            x,y,z,r - defines sphere of cell in space
            spd - speed of satellite cell
        Outputs:
            obj - aSatelliteCell instance
        %}
        function obj = aSatelliteCell(x, y, z, spd, r)
            if nargin == 0
                obj.xPos = 0;
                obj.yPos = 0;
                obj.zPos = 0;
                obj.speed = 0.5;
                obj.radius = 1;
                obj.fusedStatus = false;
            elseif nargin == 4
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = 1;
                obj.fusedStatus = false;
            elseif nargin == 5
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = r;
                obj.fusedStatus = false;
            else
                error('aSatelliteCell : aSatelliteCell: Wrong number of input arguments');
            end
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates a satellite cell if not touching a muscle fiber
                -Moves satellite cell
        Inputs:
            obj - aSatelliteCell
            xb,yb,zb - defines boundaries of the world
            fiberList - list of muscle fibers in the world
        Outputs:
            
        %}
        function update(obj, xb, yb, zb, mechs, pullMVecs, worldRestrict)
            if(~obj.fusedStatus)
                vector = zeros(1,3);
                if(mechs.satelliterandomspread)
                    randvec = obj.getMoveRandom();
                    randvec = obj.normalizeVector(randvec);
                    vector(1) = vector(1) + randvec(1);
                    vector(2) = vector(2) + randvec(2);
                    vector(3) = vector(3) + randvec(3);
                end        
                if(mechs.satellitemusclepullspread && ~isempty(pullMVecs) && any(pullMVecs))
                    muscpullvec = obj.normalizeVector(pullMVecs);
                    vector(1) = vector(1) + muscpullvec(1);
                    vector(2) = vector(2) + muscpullvec(2);
                    vector(3) = vector(3) + muscpullvec(3);
                end
                vector = obj.normalizeVector(vector);
                vector = vector*obj.speed;
                if (worldRestrict ~= 0 && ~any(isnan(worldRestrict)))
                    xb = xb*worldRestrict;
                    yb = yb*worldRestrict;
                    zb = zb*worldRestrict;
                end
                obj.move(xb, yb, zb, vector);
            end
        end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Deletes the satellite cell
        Inputs:
            obj - aSatelliteCell instance
        Outputs:
            NA
        %}
        function die(obj)
            delete(obj);
        end
        
        function [unitVec] = normalizeVector(obj, vector3d)
            magnitude = sqrt(vector3d(1)^2 + vector3d(2)^2 + vector3d(3)^2);
            unitVec = vector3d/magnitude;
        end
        
        %{
        move
        ---------------------------------------------------------------------------
        Description:
            Moves to a new random position based on its speed after it
            verifies the position is valid with checkContact
        Inputs:
            obj - aSatelliteCell instance
            xb,yb,zb - defines boundaries of the world
        Outputs:
            NA
        %}
        function move(obj, xb, yb, zb, vec)
            newx = obj.xPos + vec(1);
            newy = obj.yPos + vec(2);
            newz = obj.zPos + vec(3);
            if(obj.checkContact(newx,newy,newz,xb,yb,zb))                
                obj.xPos = newx;
                obj.yPos = newy;
                obj.zPos = newz;
            end
        end
        
        function [randvec] = getMoveRandom(obj)
            randvec(1) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(2) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(3) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
        end
        
        %{
        checkContact
        ---------------------------------------------------------------------------
        Description:
            Checks if a new position would be valid and returns a boolean
            of 1 if it can move there and 0 if not.
        Inputs:
            obj - aSatelliteCell instance
            xNew,yNew,zNew - proposed new position of satellite cell
            xb,yb,zb - defines boundaries of the world
        Outputs:
            isPositionValid - a boolean saying whether the proposed
            position is within the world
        %}
        function [isPositionValid] = checkContact(obj, xNew, yNew, zNew, xb, yb, zb)
            if (xNew < xb && xNew > -1*xb && yNew < yb && yNew > -1*yb && zNew < zb && zNew > -1*zb)
                isPositionValid = true;
            else
                isPositionValid = false;
            end
        end
        
        %{
        fibPush
        ---------------------------------------------------------------------------
        Description:
            Pushes the satellite cell to the periphery of the muscle fiber
            if they come into contact
        Inputs:
            obj - aSatelliteCell instance
            fibx-fibl - defines a cylindrical muscle fiber in space
        Outputs:
            NA
        %}
        function fibPush(obj,bounds)
            if (~isempty(bounds))
                shape = vertcat(bounds(:,:,1),bounds(:,:,2),bounds(:,:,3));
                shapez = shape(:,3);
                shapex = shape(:,1);
                shapey = shape(:,2);
                k = boundary(shapex, shapey);
                bshapex = shapex(k); bshapey = shapey(k); bshapez = shapez(k);
%                 dist = zeros(numel(bshapex),1);
                for i = 1:numel(bshapex)
                    dist(i) = sqrt((bshapex(i)-obj.xPos)^2 + (bshapey(i)-obj.yPos)^2 +...
                        (bshapez(i)-obj.zPos)^2);
                end
                [~, ind] = min(dist);
                obj.xPos = bshapex(ind);
                obj.yPos = bshapey(ind);
            end
%             if ((obj.fiberPlaceRatio == 0))
%                 obj.fiberPlaceRatio = (obj.zPos - fibz)/(fibl / 2);
%             end
%             obj.zPos = fibz + (obj.fiberPlaceRatio * fibl);
%             x = obj.xPos - fibx;
%             y = obj.yPos - fiby;
%             newx = sqrt((x^2 * fibr^2) / (x^2 + y^2));
%             newy = sqrt((y^2 * fibr^2) / (x^2 + y^2));
%             if (x >= 0)
%                 newx = newx + fibx;
%             else
%                 newx = -1*newx + fibx;
%             end
%             if (y >= 0)
%                 newy = newy + fiby;
%             else
%                 newy = -1*newy + fiby;
%             end
%             obj.xPos = newx;
%             obj.yPos = newy;
        end
    end
end