classdef aSimulationSpace < matlab.mixin.SetGetExactNames
    %{
    aSimulationSpace Class
    
    Purpose: 
        Is the overseer of the simulation. Its purpose is to keep track of
        the agents of the simulation and record data. The simulation space
        also store default values that can be changed with user input
    
    Description:
        The simulation space may be given a set of initial conditions.
        Using these conditions, the simulation space will set up the
        modeled world. The simulation space will keep track of timesteps
        and ticks as well as collect necessary data at these points. The
        simulation space will keep track of conditional properties of the
        simulation.
    
    TODO:
        -Add variable for length of recorded movie and translate it to a
        number of scenes in saveScene
    
    %}
    
    properties
        tickTime;
        currentTick;
        worldX;
        worldY;
        worldZ;
        %Satellite Cell things
        allSatelliteCells;
        numSatelliteCells;
        satelliteCellSpeed;
        myoblastSpawnChance;            %probability of myoblast to spawn each time step
        satelliteCellDieChance;
        satelliteCellRadius;
        satelliteCellWorldRestriction;
        %Myoblast things
        allMyoblasts;
        numMyoblasts;
        myoblastSpeed;
        myoblastDieChance;
        myoblastRadius;
        myoblastWorldRestriction;
        %Nuclei things
        allNuclei;
        %Muscle Fiber things
        allMuscleFibers;
        maxMuscleFibers;
        %Myofibril things
        fibrilRadius;
        fibrilLength;
        fibrilGrowRate;
        fibrilDecayRate;
        numMyofibrils;
        myofibrilMaxRadius;
        myofibrilMaxLength;
        myofibrilMaxGrowthRate;
        myofibrilMaxDecayRate;
        interfibrilDistance;
        myofibrilEdgeDistance;
        myofibrilProjectionQuality;
        allMyofibrils;        
        %Nucleus things
        nucleusSpeed;
        nucleusDieChance;
        nucleusRadius;
        
        %MECHANISMS
        nucleusRandomSpread;
        nucleusPushSpread;
        nucMechs;
        
        myoblastRandomSpread;
        myoblastPullSpread;
        myoblastMusclePullSpread;
        myoblastMechs;
        
        myofibrilGrowNumNucleus;
        myofibrilGrowDistNucleus;
        myofibrilGrowNuclearDensity;
        myofibrilDecaySizeMyofibril;
        myofibrilDecayNumMyofibril;
        myofibrilDecayTotalVolume;
        myofibrilDecayFiberArea;
        myofibrilSplitChance;
        myofibrilSplitRadius;
        myofibrilMaxSplits;
        myofibrilMechs;
        
        satelliteRandomSpread;
        satelliteMusclePullSpread;
        satelliteQuiescentNot;
        satelliteQuiescentFused;
        satelliteQuiescentNumNuclei;
        satelliteQuiescentFiberDecay;
        scMechs;
        
        fiberMechs;
        
        steadyStateTrigger;
        steadyKillSatelliteCells;
        steadyKillMyoblasts;
        steadyKillMuscleFibers;
        steadyKillMyofibrils;
        steadyKillNuclei;
        
        steadyInduceHypertrophy;
        steadyInduceAtrophy;
        
        hypertrophyGrowthRateMultiplier;
        hypertrophyDecayRateMultiplier;
        hypertrophyMaxRadiusMultiplier;
        hypertrophySplitRadiusMultiplier;
        hypertrophyFiberSplitting;
        
        simFigure;
        recordMovie;
        movieFolder;
        fileStrings;
        sceneNumber;
        maxTicks;
        numberSimulations;
        shouldRender;
        stop;
        tickComputationTime;
    end
    
    methods
        %{
        aSimulationSpace constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aSimulationSpace
        Inputs:
            varargin - describes a set of variables that define the
            starting parameters of the simulation
        Outputs:
            obj - aSimulationSpace instance
        %}
        function obj = aSimulationSpace(varargin)
            %default simulation space
            
            p = inputParser;
            addOptional(p, 'tick_time',1);
            addOptional(p, 'x_bound',10);
            addOptional(p, 'y_bound',10);
            addOptional(p, 'z_bound',10);
            
            addOptional(p, 'num_satellite_cells',1);
            addOptional(p, 'satellite_cell_speed',0.5);
            addOptional(p, 'myoblast_spawn_chance',0.01);
            addOptional(p, 'satellite_cell_die_chance',0.01);
            addOptional(p, 'satellite_cell_radius', 0.5);
            addOptional(p, 'satellite_cell_world_restriction', 1);
            
            addOptional(p, 'num_myoblasts',0);
            addOptional(p, 'myoblast_speed',0.5);
            addOptional(p, 'myoblast_die_chance', 0.01);
            addOptional(p, 'myoblast_radius', 0.5);
            addOptional(p, 'myoblast_world_restriction', 1);
            
            addOptional(p, 'num_nuclei',0);
            
            addOptional(p, 'max_muscle_fibers',0);
            addOptional(p, 'num_muscle_fibers',0);
            addOptional(p, 'fibril_radius', 5);
            addOptional(p, 'fibril_length', 5);
            addOptional(p, 'fibril_grow_rate', 0);
            addOptional(p, 'fibril_decay_rate', 0);
            
            addOptional(p, 'num_myofibrils',0);
            addOptional(p, 'myofibril_max_radius',0);
            addOptional(p, 'myofibril_max_length',0);
            addOptional(p, 'myofibril_max_growth_rate',0);
            addOptional(p, 'myofibril_max_decay_rate',0);
            addOptional(p, 'interfibril_distance', 0.06);
            addOptional(p, 'myofibril_edge_distance', 1.2);
            addOptional(p, 'myofibril_projection_quality', 50);
            
            addOptional(p, 'nucleus_speed',0.05);
            addOptional(p, 'nucleus_die_chance',0.001);
            addOptional(p, 'nucleus_radius',0.1);
            
            %MECHANISMS
            addOptional(p, 'nucleus_random_spread',true);
            addOptional(p, 'nucleus_push_spread', false);
            
            addOptional(p, 'myoblast_random_spread',true);
            addOptional(p, 'myoblast_pull_spread',false);
            addOptional(p, 'myoblast_muscle_pull_spread',false);
            
            addOptional(p, 'myofibril_grow_num_nucleus',false);
            addOptional(p, 'myofibril_grow_dist_nucleus',false);
            addOptional(p, 'myofibril_grow_nuclear_density',false);
            addOptional(p, 'myofibril_decay_size_myofibril',false);
            addOptional(p, 'myofibril_decay_num_myofibril',false);
            addOptional(p, 'myofibril_decay_total_volume',false);
            addOptional(p, 'myofibril_decay_fiber_area',false);
            addOptional(p, 'myofibril_split_chance',0);
            addOptional(p, 'myofibril_split_radius',0);
            addOptional(p, 'myofibril_max_splits',0);
            
            addOptional(p, 'satellite_random_spread', true);
            addOptional(p, 'satellite_muscle_pull_spread', false);
            addOptional(p, 'satellite_quiescent_not',true);
            addOptional(p, 'satellite_quiescent_fused',false);
            addOptional(p, 'satellite_quiescent_num_nuclei',0);
            addOptional(p, 'satellite_quiescent_fiber_decay',false);
            
            %STEADY STATE TRIGGERS
            addOptional(p, 'steady_kill_satellite_cells',0);
            addOptional(p, 'steady_kill_myoblasts', 0);
            addOptional(p, 'steady_kill_muscle_fibers', 0);
            addOptional(p, 'steady_kill_myofibrils', 0);
            addOptional(p, 'steady_kill_nuclei', 0);
            
            addOptional(p, 'steady_induce_hypertrophy', 0);
            addOptional(p, 'steady_induce_atrophy', 0);
            
            addOptional(p, 'hypertrophy_growth_rate_multiplier', 1);
            addOptional(p, 'hypertrophy_decay_rate_multiplier', 1);
            addOptional(p, 'hypertrophy_max_radius_multiplier', 1);
            addOptional(p, 'hypertrophy_split_radius_multiplier', 1);
            addOptional(p, 'hypertrophy_fiber_splitting', 0);
            
            %RENDER/MOVIE
            addOptional(p, 'record_movie',false);
            addOptional(p, 'movie_folder','');
            addOptional(p, 'scene_number',0);
            addOptional(p, 'max_ticks', 1);
            addOptional(p, 'number_simulations', 1);
            addOptional(p, 'should_render', false);
            
            parse(p,varargin{:});
            p = p.Results;
            
            obj.tickTime = p.tick_time;
            obj.currentTick = 0;
            obj.worldX = p.x_bound;
            obj.worldY = p.y_bound;
            obj.worldZ = p.z_bound;
            
            %MECHANISMS
            obj.nucleusRandomSpread = p.nucleus_random_spread;
            obj.nucleusPushSpread = p.nucleus_push_spread;
            obj.nucMechs.nucleusrandomspread = obj.nucleusRandomSpread;
            obj.nucMechs.nucleuspushspread = obj.nucleusPushSpread;

            obj.myoblastRandomSpread = p.myoblast_random_spread;
            obj.myoblastPullSpread = p.myoblast_pull_spread;
            obj.myoblastMusclePullSpread = p.myoblast_muscle_pull_spread;
            obj.myoblastMechs.myoblastrandomspread = obj.myoblastRandomSpread;
            obj.myoblastMechs.myoblastpullspread = obj.myoblastPullSpread;
            obj.myoblastMechs.myoblastmusclepullspread = obj.myoblastMusclePullSpread;

            obj.myofibrilGrowNumNucleus = p.myofibril_grow_num_nucleus;
            obj.myofibrilGrowDistNucleus = p.myofibril_grow_dist_nucleus;
            obj.myofibrilGrowNuclearDensity = p.myofibril_grow_nuclear_density;
            obj.myofibrilDecaySizeMyofibril = p.myofibril_decay_size_myofibril;
            obj.myofibrilDecayNumMyofibril = p.myofibril_decay_num_myofibril;
            obj.myofibrilDecayTotalVolume = p.myofibril_decay_total_volume;
            obj.myofibrilDecayFiberArea = p.myofibril_decay_fiber_area;
            obj.myofibrilMechs.myofibrilgrownumnucleus = obj.myofibrilGrowNumNucleus;
            obj.myofibrilMechs.myofibrilgrowdistnucleus = obj.myofibrilGrowDistNucleus;
            obj.myofibrilMechs.myofibrilgrownucleardensity = obj.myofibrilGrowNuclearDensity;
            obj.myofibrilMechs.myofibrildecaysizemyofibril = obj.myofibrilDecaySizeMyofibril;
            obj.myofibrilMechs.myofibrildecaynummyofibril = obj.myofibrilDecayNumMyofibril;
            obj.myofibrilMechs.myofibrildecaytotalvolume = obj.myofibrilDecayTotalVolume;
            obj.myofibrilMechs.myofibrildecayfiberarea = obj.myofibrilDecayFiberArea;

            obj.satelliteRandomSpread = p.satellite_random_spread;
            obj.satelliteMusclePullSpread = p.satellite_muscle_pull_spread;
            obj.satelliteQuiescentNot = p.satellite_quiescent_not;
            obj.satelliteQuiescentFused = p.satellite_quiescent_fused;
            obj.satelliteQuiescentNumNuclei = p.satellite_quiescent_num_nuclei;
            obj.satelliteQuiescentFiberDecay = p.satellite_quiescent_fiber_decay;
            obj.scMechs.satelliterandomspread = obj.satelliteRandomSpread;
            obj.scMechs.satellitemusclepullspread = obj.satelliteMusclePullSpread;
            obj.scMechs.satellitequiescentnot = obj.satelliteQuiescentNot;
            obj.scMechs.satellitequiescentfused = obj.satelliteQuiescentFused;
            obj.scMechs.satellitequiescentnumnuclei = obj.satelliteQuiescentNumNuclei;
            obj.scMechs.satellitequiescentfiberdecay = obj.satelliteQuiescentFiberDecay;
                
            obj.fiberMechs.placeholder = 1;
            obj.fiberMechs.placeholdertwo = 0;
                            
            
            %OTHER AGENT/LIST VARIABLES
            obj.allSatelliteCells = aSatelliteCellList(0,obj.scMechs);
            obj.numSatelliteCells = p.num_satellite_cells;
            obj.satelliteCellSpeed = p.satellite_cell_speed;
            obj.myoblastSpawnChance = p.myoblast_spawn_chance;
            obj.satelliteCellDieChance = p.satellite_cell_die_chance;
            obj.satelliteCellRadius = p.satellite_cell_radius;
            obj.satelliteCellWorldRestriction = p.satellite_cell_world_restriction;
            
            obj.allMyoblasts = aMyoblastList(0,obj.myoblastMechs);
            obj.numMyoblasts = p.num_myoblasts;
            obj.myoblastSpeed = p.myoblast_speed;
            obj.myoblastDieChance = p.myoblast_die_chance;
            obj.myoblastRadius = p.myoblast_radius;
            obj.myoblastWorldRestriction = p.myoblast_world_restriction;

            obj.allMuscleFibers = aMuscleFiberList2();
            obj.maxMuscleFibers = p.max_muscle_fibers;
            obj.fibrilRadius = p.fibril_radius;
            obj.fibrilLength = p.fibril_length;
            obj.fibrilGrowRate = p.fibril_grow_rate;
            obj.fibrilDecayRate = p.fibril_decay_rate;
            
            obj.numMyofibrils = p.num_myofibrils;
            obj.myofibrilMaxRadius = p.myofibril_max_radius;
            obj.myofibrilMaxLength = p.myofibril_max_length;
            obj.myofibrilMaxGrowthRate = p.myofibril_max_growth_rate;
            obj.myofibrilMaxDecayRate = p.myofibril_max_decay_rate;
            obj.interfibrilDistance = p.interfibril_distance;
            obj.myofibrilEdgeDistance = p.myofibril_edge_distance;
            obj.myofibrilProjectionQuality = p.myofibril_projection_quality;
            
            obj.myofibrilSplitChance = p.myofibril_split_chance;
            obj.myofibrilSplitRadius = p.myofibril_split_radius;
            obj.myofibrilMaxSplits = p.myofibril_max_splits;
            
            obj.nucleusSpeed = p.nucleus_speed;
            obj.nucleusDieChance = p.nucleus_die_chance;
            obj.nucleusRadius = p.nucleus_radius;                        
            
            %STEADY STATE TRIGGERS
            obj.steadyStateTrigger = false;
            obj.steadyKillSatelliteCells = p.steady_kill_satellite_cells;
            obj.steadyKillMyoblasts = p.steady_kill_myoblasts;
            obj.steadyKillMuscleFibers = p.steady_kill_muscle_fibers;
            obj.steadyKillMyofibrils = p.steady_kill_myofibrils;
            obj.steadyKillNuclei = p.steady_kill_nuclei;
            
            obj.steadyInduceHypertrophy = p.steady_induce_hypertrophy;
            obj.steadyInduceAtrophy = p.steady_induce_atrophy;
            
            obj.hypertrophyGrowthRateMultiplier = p.hypertrophy_growth_rate_multiplier;
            obj.hypertrophyDecayRateMultiplier = p.hypertrophy_decay_rate_multiplier;
            obj.hypertrophyMaxRadiusMultiplier = p.hypertrophy_max_radius_multiplier;
            obj.hypertrophySplitRadiusMultiplier = p.hypertrophy_split_radius_multiplier;
            obj.hypertrophyFiberSplitting = p.hypertrophy_fiber_splitting;
            
            if (p.should_render)
                simFigure = figure('Name', 'Simulation World');
            end
            obj.recordMovie = p.record_movie;
            obj.movieFolder = p.movie_folder;
            obj.fileStrings;
            obj.sceneNumber = p.scene_number;
            obj.maxTicks = p.max_ticks;
            obj.numberSimulations = p.number_simulations;
            obj.shouldRender = p.should_render;
            obj.stop = false;
            obj.tickComputationTime = 0;
            
            obj.checkParameters();
            
            %convert �m to matlab units 
            obj.convertMicroToUnits();
            
            obj.generateScene();
        end
        
        %{
        convertMicroToUnits
        ---------------------------------------------------------------------------
        Description:
            A function that converts the user's input of �m to arbitrary
            units that are: 1 unit = 1000�m, 1mm = 1000�m.
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function convertMicroToUnits(obj)
            %Constants �m -> units
            obj.satelliteCellRadius = obj.satelliteCellRadius/1000;
            obj.myoblastRadius = obj.myoblastRadius/1000;
            obj.fibrilRadius = obj.fibrilRadius/1000;
            obj.fibrilLength = obj.fibrilLength/1000;
            obj.myofibrilMaxRadius = obj.myofibrilMaxRadius/1000;
            obj.myofibrilMaxLength = obj.myofibrilMaxLength/1000;
            obj.myofibrilSplitRadius = obj.myofibrilSplitRadius/1000;
            obj.interfibrilDistance = obj.interfibrilDistance/1000;
            obj.myofibrilEdgeDistance = obj.myofibrilEdgeDistance/1000;
            obj.nucleusRadius = obj.nucleusRadius/1000;
            
            %Rates �m/tick -> units/tick
            
        end
        
        %{
        die
        -------------------------------------------------------------------
        Description:
            Ends the simulation by deleting the aSimulationSpace object
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function die(obj)
            delete(obj);
        end
        
        %{
        generateScene
        -------------------------------------------------------------------
        Description:
            Creates and places all starting agents as well as defines the
            world.
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function generateScene(obj)
            %create satellite cells
            for i = 1:obj.numSatelliteCells
                xstart = (-obj.worldX + (obj.worldX+obj.worldX)*rand(1,1))*obj.satelliteCellWorldRestriction;
                ystart = (-obj.worldY + (obj.worldY+obj.worldY)*rand(1,1))*obj.satelliteCellWorldRestriction;
                zstart = (-obj.worldZ + (obj.worldZ+obj.worldZ)*rand(1,1))*obj.satelliteCellWorldRestriction;
                obj.allSatelliteCells.addCell(xstart, ystart, zstart, obj.satelliteCellSpeed, obj.satelliteCellRadius);
            end
            %creates myoblasts
            for i = 1:obj.numMyoblasts
                xstart = (-obj.worldX + (obj.worldX+obj.worldX)*rand(1,1))*obj.myoblastWorldRestriction;
                ystart = (-obj.worldY + (obj.worldY+obj.worldY)*rand(1,1))*obj.myoblastWorldRestriction;
                zstart = (-obj.worldZ + (obj.worldZ+obj.worldZ)*rand(1,1))*obj.myoblastWorldRestriction;
                obj.allMyoblasts.addMyoblast(xstart, ystart, zstart, obj.myoblastSpeed, obj.myoblastRadius);
            end
            fig = obj.simFigure;
            cla;
            hold on;
            axis([(-1*obj.worldX) (obj.worldX) (-1*obj.worldY) (obj.worldY) (-1*obj.worldZ) (obj.worldZ)]);
            ax = gca;
            xlabel('X');
            ylabel('Y');
            zlabel('Z');
            %sets camera angle/position
            view(119.6, -45.199);
            ax.OuterPosition = [0.029234060472058,0.004482582218191,0.975122611753403,0.959249252561902];
            ax.Position = [0.05,0.03,0.800720024108887,0.98178814083795];
            ax.CameraPosition = [306.4189241132149,326.300782985308,-263.884902880924];
            ax.CameraUpVector = [0.807068844513205,-0.43498833739323,0.399280636329879];
            zoom(gca, 1);
            pbaspect(ax, [obj.worldX, obj.worldY, obj.worldZ]);
            set(gcf, 'Position', get(0, 'Screensize'));
            grid on;
            obj.render();
        end
        
        %{
        tick
        -------------------------------------------------------------------
        Description:
            Makes all agents update as well as checks spawns/deaths/steady
            state
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function tick(obj)  
            tic;
            xb(1) = -obj.worldX; xb(2) = obj.worldX;
            yb(1) = -obj.worldY; yb(2) = obj.worldY;            
            obj.checkDeaths();
            obj.checkSpawns();
            obj.allSatelliteCells.update(obj.worldX, obj.worldY, obj.worldZ, obj.allMuscleFibers, obj.satelliteCellWorldRestriction);
            obj.allMyoblasts.update(obj.worldX, obj.worldY, obj.worldZ, obj.allMuscleFibers, obj.myoblastWorldRestriction);
            obj.allMuscleFibers.update(xb, yb, obj.satelliteQuiescentNumNuclei, obj.numMyofibrils*(2^(obj.myofibrilMaxSplits)));
            obj.currentTick = obj.currentTick + 1;
            
            obj.checkSteadyState();
            
            obj.tickComputationTime = toc;
            if (obj.currentTick > obj.maxTicks)
                obj.stop = true;
            end
        end
        
        %TO CHANGE
        %{
        checkSteadyState
        ---------------------------------------------------------------------------
        Description:
            checks whether the system has reached a steady state using the
            number of myofibrils (will use volume in future)
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function checkSteadyState(obj)
            if(~isempty(obj.allMuscleFibers.allFibers)...
                && obj.allMuscleFibers.ratioSteady >= 0.9...
                    && ~obj.steadyStateTrigger)
                obj.steadyStateTrigger = true;
                if(obj.steadyKillSatelliteCells > 0)
                    obj.allSatelliteCells.killTrigger(obj.steadyKillSatelliteCells);
                end
                if(obj.steadyKillMyoblasts > 0)
                    obj.allMyoblasts.killTrigger(obj.steadyKillMyoblasts);
                end
                if(obj.steadyKillMuscleFibers > 0 || obj.steadyKillMyofibrils || obj.steadyKillNuclei)
                    obj.allMuscleFibers.killTrigger(obj.steadyKillMuscleFibers,...
                        obj.steadyKillMyofibrils, obj.steadyKillNuclei);
                end
                if(obj.steadyInduceHypertrophy)
                    obj.induceHypertrophy();
                end
                if(obj.steadyInduceAtrophy)
                    disp('will induce atrophy here');
                end
            end
        end
        
        %{
        checkDeaths
        -------------------------------------------------------------------
        Description:
            Checks all agents that have a possibility to die and kills them
            if certain conditions are met (size, number of nuclei, chance, etc)
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function checkDeaths(obj)
            obj.allSatelliteCells.checkDeath(obj.satelliteCellDieChance);
            obj.allMyoblasts.checkDeath(obj.myoblastDieChance);
            for i = 1:obj.allMuscleFibers.length()
                obj.allMuscleFibers.getFiber(i).myNuclei.checkDeath(obj.nucleusDieChance);
            end
        end
        
        %{
        checkSpawns
        -------------------------------------------------------------------
        Description:
            Checks all agents that have a chance to spawn other agents and
            spawns them if certain conditions are met (proximity, chance,
            etc)
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function checkSpawns(obj)
            %spawn myoblast from satellite cells?
            [shouldSpawnMyo, x, y, z] = obj.allSatelliteCells.checkMyoblastSpawn(obj.myoblastSpawnChance, obj.allMuscleFibers);
            if (shouldSpawnMyo)
                mechs.myoblastrandomspread = obj.myoblastRandomSpread;
                mechs.myoblastpullspread = obj.myoblastPullSpread;
                mechs.myoblastmusclepullspread = obj.myoblastMusclePullSpread;
                for q = 1:length(x)
                    obj.allMyoblasts.addMyoblast(x(q), y(q), z(q), obj.myoblastSpeed, obj.myoblastRadius, mechs);
                end
            end
            
            %spawn muscle fiber from myoblasts or myoblast-muscle fiber fusion?
            nucInfo = [obj.nucleusSpeed, obj.nucleusRadius, obj.nucleusPushSpread];
            fibrilInfo = [obj.fibrilRadius, obj.fibrilLength, obj.fibrilGrowRate,...
                obj.fibrilDecayRate, obj.numMyofibrils, obj.myofibrilMaxGrowthRate,...
                obj.myofibrilMaxDecayRate, obj.myofibrilMaxRadius, obj.myofibrilMaxLength];
            fibrilListInfo = [obj.interfibrilDistance, obj.myofibrilEdgeDistance,...
                obj.myofibrilProjectionQuality, obj.myofibrilMaxSplits];
            obj.allMyoblasts.checkMyoFibFusion(obj.allMuscleFibers, nucInfo);
            if ((obj.maxMuscleFibers >= 0 && obj.allMuscleFibers.length() < obj.maxMuscleFibers)||obj.maxMuscleFibers<0)
                [shouldSpawnFiber, x, y, z] = obj.allMyoblasts.checkMyoMyoFusion();            
                if (shouldSpawnFiber)
                    for i = 1:numel(x)
                        obj.allMuscleFibers.addFiber(x(i),y(i),z(i),...
                            fibrilInfo, fibrilListInfo, nucInfo,...
                            obj.nucMechs, obj.myofibrilMechs);
                    end
                end
            end
            
            %splits myofibrils?
            for i = 1:obj.allMuscleFibers.length()
                obj.allMuscleFibers.getFiber(i).checkMyofibrilSplit(obj.myofibrilSplitChance, obj.myofibrilSplitRadius);
            end
        end
        
        %TO CHANGE
        %{
        induceHypertrophy
        ---------------------------------------------------------------------------
        Description:
            Could activate after a steady state is reached. It can change some
            parameters concerning growth, etc.
        Inputs:
            
        Outputs:
            
        %}
        function induceHypertrophy(obj)
            %Fiber changes
            obj.allMuscleFibers.hypertrophyFiberChanges(...
                obj.hypertrophyFiberSplitting);
            %myofibril changes
            obj.allMuscleFibers.hypertrophyMyofibrilChanges(...
                obj.hypertrophyGrowthRateMultiplier,...
                obj.hypertrophyDecayRateMultiplier,...
                obj.hypertrophyMaxRadiusMultiplier)
            obj.myofibrilSplitRadius = obj.myofibrilSplitRadius * obj.hypertrophySplitRadiusMultiplier;
            %nucleus changes
            
        end
        
        %TO DELETE
        %{
        render
        -------------------------------------------------------------------
        Description:
            Updates the figure to display the current agents in the world
        Inputs:
            obj- aSimulationSpace instance
        Outputs:
            NA
        %}
        function render(obj)
            fig = obj.simFigure;
            cla;
            hold on;
            satCellPos = obj.allSatelliteCells.getAllPositions();
            myoblastPos = obj.allMyoblasts.getAllPositions();
            fiberPos = obj.allMuscleFibers.getAllPositions();
            [x, y, z] = sphere(4);
            [xc,yc,zc] = cylinder;
            for i = 1:obj.allSatelliteCells.length()
                s = surf(x*obj.satelliteCellRadius + satCellPos(i,1),...
                    y*obj.satelliteCellRadius + satCellPos(i,2),...
                    z*obj.satelliteCellRadius + satCellPos(i,3));
                set(s, 'FaceColor',[1 0 0]);
            end
            for i = 1:obj.allMyoblasts.length()
                s = surf(x*obj.myoblastRadius + myoblastPos(i,1),...
                    y*obj.myoblastRadius + myoblastPos(i,2),...
                    z*obj.myoblastRadius + myoblastPos(i,3));
                set(s, 'FaceColor',[0 0 1],'EdgeAlpha', 0);
                alpha(0.2);
            end
            xb(1) = -obj.worldX; xb(2) = obj.worldX;
            yb(1) = -obj.worldY; yb(2) = obj.worldY;
            for i = 1:obj.allMuscleFibers.length()
                %CLASSIC CYLINDERS
%                 s = surf(xc*obj.allMuscleFibers.getFiber(i).radius + fiberPos(i,1),...
%                     yc*obj.allMuscleFibers.getFiber(i).radius + fiberPos(i,2),...
%                     zc*obj.allMuscleFibers.getFiber(i).length + fiberPos(i,3) - obj.allMuscleFibers.getFiber(i).length/2);
%                 set(s, 'FaceColor',[0 1 0]);
%                 alpha(s, 0.3);

%                 USING ALPHASHAPE
%                 xb(1) = -obj.worldX; xb(2) = obj.worldX;
%                 yb(1) = -obj.worldY; yb(2) = obj.worldY;
%                 [topBounds, botBounds] = obj.allMuscleFibers.getFiber(i).myMyofibrils.getBoundary(xb, yb);
%                 muscleBounds = vertcat(topBounds, botBounds);
%                 muscShape = alphaShape(muscleBounds);
%                 plot(muscShape);

%                 USING BOUNDARY                
                muscleBounds = vertcat(obj.allMuscleFibers.getFiber(i).boundaryPoints(:,:,1), obj.allMuscleFibers.getFiber(i).boundaryPoints(:,:,2), obj.allMuscleFibers.getFiber(i).boundaryPoints(:,:,3));
                muscShape = obj.allMuscleFibers.getFiber(i).boundaryIndicies;
                if (~isempty(muscleBounds))
                    trisurf(muscShape,muscleBounds(:,1),muscleBounds(:,2),muscleBounds(:,3),...
                        'Facecolor','green','FaceAlpha',0.3,'EdgeAlpha',0);
                end
%                 shp = alphaShape(muscleBounds(muscShape));
%                 disp(inShape(shp,obj.allMuscleFibers.getFiber(i).myMyofibrils.averagePosition()));
%                 plot(shp);
                
                if (obj.allMuscleFibers.getFiber(i).myMyofibrils.length() > 0)
                    fibrilPos = obj.allMuscleFibers.getFiber(i).myMyofibrils.getAllPositions();
                    for j = 1: obj.allMuscleFibers.getFiber(i).myMyofibrils.length()
                        s2 = surf(xc*obj.allMuscleFibers.getFiber(i).myMyofibrils.getFibril(j).radius + fibrilPos(j,1),...
                        yc*obj.allMuscleFibers.getFiber(i).myMyofibrils.getFibril(j).radius + fibrilPos(j,2),...
                        zc*obj.allMuscleFibers.getFiber(i).myMyofibrils.getFibril(j).length + fibrilPos(j,3) - obj.allMuscleFibers.getFiber(i).myMyofibrils.getFibril(j).length/2);
                    set(s2, 'FaceColor',[1 1 0]);
                    alpha(s2, 0.5);
                    end
                end
%                 [nx,ny,nz] = obj.allMuscleFibers.getFiber(i).myNuclei.averagePosition();                
%                 s4 = surf(x*0.05 + nx, y*0.05 + ny, z*0.05 + nz);
%                 set(s4, 'FaceColor',[1 0 1]);
                if (obj.allMuscleFibers.getFiber(i).myNuclei.length() > 0)
                    nucPos = obj.allMuscleFibers.getFiber(i).myNuclei.getAllPositions();
                    for j = 1: obj.allMuscleFibers.getFiber(i).myNuclei.length()
                        s3 = surf(x*obj.allMuscleFibers.getFiber(i).myNuclei.getNucleus(j).radius + nucPos(j,1),...
                        y*obj.allMuscleFibers.getFiber(i).myNuclei.getNucleus(j).radius + nucPos(j,2),...
                        z*obj.allMuscleFibers.getFiber(i).myNuclei.getNucleus(j).radius + nucPos(j,3));
                    set(s3, 'FaceColor',[1 1 0]);
                    alpha(s3, 1);
                    end
                end
            end
            %plot3(satCellPos(:,1), satCellPos(:,2), satCellPos(:,3), 'or', 'LineStyle', 'none', 'MarkerSize', obj.satelliteCellRadius*2);
            %plot3(myoblastPos(:,1), myoblastPos(:,2), myoblastPos(:,3), 'ob', 'LineStyle', 'none', 'MarkerSize', obj.myoblastRadius*2);
            %plot3(fiberPos(:,1), fiberPos(:,2), fiberPos(:,3), 'og', 'LineStyle', 'none', 'MarkerSize', obj.myoblastRadius*2)
            camlight;
            obj.sceneNumber = obj.sceneNumber + 1;
            %obj.sceneNumber
            ax = gca;
            %camorbit(1, 0);   %makes camera spin
            if (obj.recordMovie)
                obj.saveScene();
            end            
        end
        
        %{
        checkParameters
        ---------------------------------------------------------------------------
        Description:
            Goes through the user's parameter settings and checks if they
            are usable or not.
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function checkParameters(obj)
            if(obj.tickTime <= 0 || mod(obj.tickTime,1) ~= 0)
                error('tickTime parameter must be an integer greater than 0\nYour tickTime is %f\n',obj.tickTime);
            end
            if(obj.worldX <= 0 || obj.worldY <= 0 || obj.worldZ <= 0)
                error('xbound, ybound, and zbound parameters must all be greater than 0\nYour xbound is %f\nYour ybound is %f\nYour zbound is %f\n',obj.worldX, obj.worldY, obj.worldZ);
            end
            if(obj.numSatelliteCells < 0)
                error('numsatellitecells must be greater than or equal to 0\nYour numsatellitecells is %f\n',obj.numSatelliteCells);
            end
            if(obj.satelliteCellSpeed < 0)
                error('satellitecellspeed parameter must be greater than or equal to 0\nYour satellitecellspeed is %f\n',obj.satelliteCellSpeed);
            end
            if(obj.myoblastSpawnChance < 0 || obj.myoblastSpawnChance > 1)
                error('myoblastspawnchance parameter must be between 0 and 1 (inclusive)\nYour myoblastspawnchance is %f\n',obj.myoblastSpawnChance);
            end
            if(obj.satelliteCellDieChance < 0 || obj.satelliteCellDieChance > 1)
                error('satellitecelldiechance parameter must be between 0 and 1 (inclusive)\nYour satellitecelldiechance is %f\n',obj.satelliteCellDieChance);
            end
            if(obj.satelliteCellRadius <= 0)
                error('satellitecellradius parameter must be greater than 0\nYour satellitecellradius is %f',obj.satelliteCellRadius);
            end
            if(obj.satelliteCellWorldRestriction <= 0 || obj.satelliteCellWorldRestriction > 1)
                error('satellitecellworldrestriction parameter must be greater than 0 and less than or equal to 1\nYour satellitecellworldrestriction is %f\n',obj.satelliteCellWorldRestriction);
            end
            
            if(obj.numMyoblasts < 0)
                error('nummyoblasts parameter must be greater than or equal to 0\nYour nummyoblasts is %f\n',obj.numMyoblasts);
            end
            if(obj.myoblastSpeed < 0)
                error('myoblastspeed parameter must be greater than or equal to 0\nYour myoblastspeed is %f\n',obj.myoblastSpeed);
            end
            if(obj.myoblastDieChance < 0 || obj.myoblastDieChance > 1)
                error('myoblastdiechance parameter must be between 0 and 1 (inclusive)\nYour myoblastdiechance is %f\n',obj.myoblastDieChance);
            end
            if(obj.myoblastRadius <= 0)
                error('myoblastradius parameter must be greater than 0\nYour myoblast radius is %f',obj.myoblastRadius);
            end
            if(obj.myoblastWorldRestriction <= 0 || obj.myoblastWorldRestriction > 1)
                error('myoblastworldrestriction parameter must be greater than 0 and less than or equal to 1\nYour myoblastworldrestriction is %f',obj.myoblastWorldRestriction);
            end
            
            %numnuclei unused
            if(mod(obj.maxMuscleFibers,1) ~= 0)
                error('maxmusclefibers parameter must be an integer\nYour maxmusclefibers is %f\n',obj.maxMuscleFibers);
            end
            %nummusclefibers unused
            if(obj.fibrilRadius <= 0)
                error('fibrilradius parameter must be greater than 0\nYour fibrilradius is %f\n',obj.fibrilRadius);
            end
            if(obj.fibrilLength <= 0)
                error('fibrillength parameter must be greater than 0\nYour fibrillength is %f\n',obj.fibrilLength);
            end
            if(obj.fibrilGrowRate < 0)
                error('fibrilgrowrate parameter must be greater than or equal to 0\nYour fibrilgrowrate is %f\n',obj.fibrilGrowRate);
            end
            if(obj.fibrilDecayRate < 0)
                error('fibrildecayrate parameter must be greater than or equal to 0\nYour fibrildecayrate is %f\n',obj.fibrildecayrate);
            end
            
            if(obj.numMyofibrils < 0 || mod(obj.numMyofibrils,1) ~= 0)
                error('nummyofibrils parameter must be an integer greater than or equal to 0\nYour nummyofibrils is %f\n',obj.numMyofibrils);
            end
            if(obj.myofibrilMaxRadius <= 0)
                error('myofibrilmaxradius parameter must be greater than 0\nYour myofibrilmaxradius is %f\n',obj.myofibrilMaxRadius);
            end
            if(obj.myofibrilMaxLength <= 0)
                error('myofibrilmaxlength parameter must be greater than 0\nYour myofibrilmaxlength is %f\n',obj.myofibrilMaxLength);
            end
            if(obj.myofibrilMaxGrowthRate < 0)
                error('myofibrilmaxgrowthrate parameter must be greater than or equal to 0\nYour myofibrilmaxgrowthrate is %f\n',obj.myofibrilMaxGrowthRate);
            end
            if(obj.myofibrilMaxDecayRate < 0)
                error('myofibrilmaxdecayrate parameter must be greater than or equal to 0\nYour myofibrilmaxdecayrate is %f\n',obj.myofibrilMaxDecayRate);
            end
            
            if(obj.nucleusSpeed < 0)
                error('nucleusspeed parameter must be greater than or equal to 0\nYour nucleusspeed is %f\n',obj.nucleusSpeed);
            end
            if(obj.nucleusDieChance < 0 || obj.nucleusDieChance > 1)
                error('nucleusdiechance parameter must be greater than or equal to 0 and less than or equal to 1\nYour nucleusdiechance is %f\n',obj.nucleusDieChance);
            end
            if(obj.nucleusRadius <= 0)
                error('nucleusradius parameter must be greater than 0\nYour nucleusradius is %f\n',obj.nucleusRadius);
            end
        end
        
        %TO DELETE
        %{
        saveScene
        -------------------------------------------------------------------
        Description:
            Exports the current figure display to a png image to be used in
            a movie after a certain number of render calls
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            NA
        %}
        function saveScene(obj)
            fig = gcf;
            filenum = sprintf('%i',obj.sceneNumber);
            filename = [obj.movieFolder, filenum];            
            disp('saving scene');
            figure_export('output_file_string',filename,'output_type','png','dpi',72);
            filename = [filename, '.png'];
            obj.fileStrings{obj.sceneNumber} = filename;
            if(obj.sceneNumber > obj.maxTicks)
                write_image_files_to_movie(obj.fileStrings, obj.movieFolder);
                obj.stop = true;
            end
        end
        
        %{
        saveState
        ---------------------------------------------------------------------------
        Description:
            Saves a snapshot of the simulation's agents at the current tick 
            inside a structure
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            s - a structure containing current simulation data of the
            agents in the world
        %}
        function s = saveState(obj) 
            s.tickComputationTime = obj.tickComputationTime;
            s.satelliteCells = obj.allSatelliteCells.saveState();
            s.satelliteCellList(1) = obj.allSatelliteCells;
            s.myoblasts = obj.allMyoblasts.saveState();
            s.myoblastList(1) = obj.allMyoblasts;
            s.muscleFibers = obj.allMuscleFibers.saveState();
            s.muscleFiberList(1) = obj.allMuscleFibers;
            s.simSpaceVariables = obj.saveSimSpaceVariables();
            s = s;
        end
        
        %{
        saveSimSpaceVariables
        ---------------------------------------------------------------------------
        Description:
            Saves parameters more related to the simulation space
        Inputs:
            obj - aSimulationSpace instance
        Outputs:
            s - a structure containing data about the world
        %}
        function s = saveSimSpaceVariables(obj)
            s.tickTime = obj.tickTime;
            s.worldX = obj.worldX;
            s.worldY = obj.worldY;
            s.worldZ = obj.worldZ;
            s.numSims = obj.numberSimulations;
            s.recordMovie = obj.recordMovie;
            s.movieFolder = obj.movieFolder;
            s.sceneNumber = obj.sceneNumber;
        end
    end
    
end