classdef aMyoblast < matlab.mixin.SetGetExactNames
    %{
    aMyoblast Class
    
    Purpose: 
        Agent based on myoblasts in skeletal muscle. Their purpose is to
        fuse with other myoblasts or muscle fibers and contribute nuclei
        (aNucleus class).
    
    Description:
        Myoblasts are spawned from satellite cells (aSatelliteCell). Once
        spawned, myoblasts will float randomly until they encounter another
        myoblast or a muscle fiber (aMuscleFiber). Once touching another myoblast or
        muscle fiber, myoblasts will fuse to the other object and
        incorporate its own nucleus to the new or existing muscle fiber.
    
    
    %}
    
    properties
        xPos;                           %x position in 3D
        yPos;                           %y position in 3D
        zPos;                           %z position in 3D
        speed;                          %+/- max distance traveled in each dimension each time step
        radius;                         %radius of cell for contact detection
        mechanisms;
        fusedStatus;                    %boolean expressing whether it is fused or not
    end
    
    properties (Constant)
        
    end
    
    methods        
        %{
        aMyoblast constructor
        -------------------------------------------------------------------
        Description:
            Constructor for aMyoblast
        Inputs:
            x,y,z,r - defines a sphere in space
            spd - speed of myoblast in world
        Outputs:
            obj - aMyoblast instance
        %}
        function obj = aMyoblast(x, y, z, spd, r, myoMechs)
            if nargin == 0
                obj.xPos = 0;
                obj.yPos = 0;
                obj.zPos = 0;
                obj.speed = 0.5;
                obj.radius = 1;
                obj.fusedStatus = false;
            elseif nargin == 4
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = 1;
                obj.fusedStatus = false;
            elseif nargin == 5
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = r;
                obj.fusedStatus = false;
            elseif nargin == 6
                obj.xPos = x;
                obj.yPos = y;
                obj.zPos = z;
                obj.speed = spd;
                obj.radius = r;
                obj.mechanisms = myoMechs;
                obj.fusedStatus = false;
            else
                error('aMyoblast : aMyoblast: Wrong number of input arguments');
            end
        end
        
        %{
        update
        -------------------------------------------------------------------
        Description:
            Updates the myoblast
                -Moves myoblast
        Inputs:
            obj - aMyoblast instance
            xb,yb,zb - defines boundaries of the world
        Outputs:
            NA
        %}
        function update(obj, xb, yb, zb, mechs, pullVecs, muscPullVecs, worldRestrict)
            vector = zeros(1,3);
            if(mechs.myoblastrandomspread)
                randvec = obj.getMoveRandom();
                randvec = obj.normalizeVector(randvec);
                vector(1) = vector(1) + randvec(1);
                vector(2) = vector(2) + randvec(2);
                vector(3) = vector(3) + randvec(3);
            end            
            if(mechs.myoblastpullspread && ~isempty(pullVecs) && any(pullVecs))
                pullvec = obj.normalizeVector(pullVecs);
                vector(1) = vector(1) + pullvec(1);
                vector(2) = vector(2) + pullvec(2);
                vector(3) = vector(3) + pullvec(3);
            end
            if(mechs.myoblastmusclepullspread && ~isempty(muscPullVecs) && any(muscPullVecs))
                muscpullvec = obj.normalizeVector(muscPullVecs);
                vector(1) = vector(1) + muscpullvec(1);
                vector(2) = vector(2) + muscpullvec(2);
                vector(3) = vector(3) + muscpullvec(3);
            end
            vector = obj.normalizeVector(vector);
            vector = vector*obj.speed;
            if (worldRestrict ~= 0 && ~any(isnan(worldRestrict)))
                xb = xb*worldRestrict;
                yb = yb*worldRestrict;
                zb = zb*worldRestrict;
            end
            obj.move(xb,yb,zb,vector);
            
            
        end
        
        %{
        die
        -------------------------------------------------------------------
        Description:
            Deletes the myoblast
        Inputs:
            obj - aMyoblast instance
        Outputs:
            NA
        %}
        function die(obj)
            delete(obj);
        end
        
        function [unitVec] = normalizeVector(obj, vector3d)
            magnitude = sqrt(vector3d(1)^2 + vector3d(2)^2 + vector3d(3)^2);
            unitVec = vector3d/magnitude;
        end
        
        function move(obj, xb, yb, zb, vec)
            newx = obj.xPos + vec(1);
            newy = obj.yPos + vec(2);
            newz = obj.zPos + vec(3);
            if(obj.checkContact(newx,newy,newz,xb,yb,zb))                
                obj.xPos = newx;
                obj.yPos = newy;
                obj.zPos = newz;
            end
        end
        
        %{
        getMoveRandom
        -------------------------------------------------------------------
        Description:
            Moves to a new random position based on its speed after it
            verifies the position is valid with checkContact
        Inputs:
            obj - aMyoblast instance
            xb,yb,zb - defines boundaries of the world
        Outputs:
            NA
        %}
        function [randvec] = getMoveRandom(obj)
            randvec(1) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(2) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
            randvec(3) = (-obj.speed + (obj.speed+obj.speed)*rand(1,1));
        end
        
        %{
        getMovePull
        -------------------------------------------------------------------
        Description:
            Moves to a new position closer to other myoblasts based on its speed after it
            verifies the position is valid with checkContact
        Inputs:
            obj - aMyoblast instance
            xb,yb,zb - defines boundaries of the world
            pullVecs - vector of best direction
        Outputs:
            NA
        %}
%         function movePull(obj, xb, yb, zb, pullVecs)
%             xPo = obj.xPos;
%             yPo = obj.yPos;
%             zPo = obj.zPos;
%             sped = obj.speed;
%             newx = 0; newy = 0; newz = 0;
%             vecmag = sqrt(pullVecs(1)^2 + pullVecs(2)^2 + pullVecs(3)^2);
%             vec = (pullVecs/vecmag) * sped;
%             newx = xPo + vec(1);
%             newy = yPo + vec(2);
%             newz = zPo + vec(3);
%             if (obj.checkContact(newx,newy,newz, xb, yb, zb))
%                 obj.xPos = newx;
%                 obj.yPos = newy;
%                 obj.zPos = newz;
%             end
%         end
        
        %{
        getMoveMusclePull
        -------------------------------------------------------------------
        Description:
            Moves to a new position closer to muscle fibers based on its speed after it
            verifies the position is valid with checkContact
        Inputs:
            obj - aMyoblast instance
            xb,yb,zb - defines boundaries of the world
            pullVecs - vector of best direction
        Outputs:
            NA
        %}
%         function moveMusclePull(obj, xb, yb, zb, pullVecs)
%             xPo = obj.xPos;
%             yPo = obj.yPos;
%             zPo = obj.zPos;
%             sped = obj.speed;
%             newx = 0; newy = 0; newz = 0;
%             vecmag = sqrt(pullVecs(1)^2 + pullVecs(2)^2 + pullVecs(3)^2);
%             vec = (pullVecs/vecmag) * sped;
%             newx = xPo + vec(1);
%             newy = yPo + vec(2);
%             newz = zPo + vec(3);
%             if (obj.checkContact(newx,newy,newz, xb, yb, zb))
%                 obj.xPos = newx;
%                 obj.yPos = newy;
%                 obj.zPos = newz;
%             end
%         end
        
        %{
        checkContact
        -------------------------------------------------------------------
        Description:
            Checks if a new position would be valid and returns a boolean
            of 1 if it can move there and 0 if not.
        Inputs:
            obj - aMyoblast instance
            xNew,yNew,zNew - proposed new position of myoblast
            xb,yb,zb - defines boundaries of the world
        Outputs:
            isPositionValid - a boolean saying if proposed position is
            within the world
        %}
        function [isPositionValid] = checkContact(obj, xNew, yNew, zNew, xb, yb, zb)
            if (xNew < xb && xNew > -1*xb && yNew < yb && yNew > -1*yb && zNew < zb && zNew > -1*zb)
                isPositionValid = true;
            else
                isPositionValid = false;
            end
        end
    end
end