classdef aNucleusList < matlab.mixin.SetGetExactNames
    
    
    properties
        allNuclei = aNucleus.empty;     %an array of the nuclei it contains
        mechanisms;
    end
    
    methods
        %{
        aNucleusList constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aNucleusList
        Inputs:
            n - number of initial nuclei in the list
        Outputs:
            obj - aNucleusList instance
        %}
        function obj = aNucleusList(n, mechs)
            if nargin ~= 0
                if (n ~= 0)
                    for (i = 1:n)
                        obj.allNuclei(i) = aNucleus;
                    end
                end
                if (~isempty(mechs))
                    obj.mechanisms = mechs;
                end
%                 disp(obj.mechanisms);
            end
        end
        
        %{
        length
        ---------------------------------------------------------------------------
        Description:
            Returns the number of nuclei contained in the list
        Inputs:
            obj - aNucleusList instance
        Outputs:
            lngth - Number of nuclei in the list
        %}
        function [lngth] = length(obj)
            lngth = length(obj.allNuclei);
        end
        
        %{
        addNucleus
        ---------------------------------------------------------------------------
        Description:
            Adds a nucleus instance to this list
        Inputs:
            obj - aNucleusList instance
            x,y,z,r - defines sphere of nucleus in space
            spd - speed of nucleus
        Outputs:
            NA
        %}
        function addNucleus(obj, x, y, z, spd, r)
            if nargin == 1
                newNuc = aNucleus();
                obj.allNuclei = [obj.allNuclei, newNuc];
            elseif nargin == 5
                newNuc = aNucleus(x,y,z,spd);
                obj.allNuclei = [obj.allNuclei, newNuc];
            elseif nargin == 6
                newNuc = aNucleus(x,y,z,spd,r);
                obj.allNuclei = [obj.allNuclei, newNuc];
            elseif nargin == 7
                newNuc = aNucleus(x,y,z,spd,r);
                obj.allNuclei = [obj.allNuclei, newNuc];                
            else
                error('aNucleusList : addNucleus : Wrong number of input arguments');
            end
        end
        
        %{
        getNucleus
        ---------------------------------------------------------------------------
        Description:
            Returns instance of nucleus in list at particular index
        Inputs:
            obj - aNucleusList instance
            idx - index of nucleus in the list
        Outputs:
            nuc - instance of nucleus
        %}
        function [nuc] = getNucleus(obj, idx)
            nuc = obj.allNuclei(idx);
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates all contained nuclei
                -Calls update on contained nuclei
        Inputs:
            obj - aNucleusList instance
            xb-zb - defines the position of fiber in space
            boundary - defines fiber boundary in space
        Outputs:
            NA
        %}
        function update(obj, bounds, fibrils)
            if (~isempty(obj.allNuclei))
                spreadVecs = obj.getSpreadVectors();
                for (i = 1:length(obj.allNuclei))
                    if (~isempty(obj.allNuclei(i)))                        
                        obj.allNuclei(i).update(bounds, fibrils, spreadVecs(i,:), obj.mechanisms);                       
                    else
                        obj.allNuclei(i) = [];
                    end
                end
                obj.checkFiberBounds(bounds);
            end
        end
        
        function killTrigger(obj, propToKill)
            disp('trigger killing nuclei');
            %rounds down the number to kill
            numToKill = floor(obj.length()*propToKill);
            idxsToKill = randperm(obj.length(), numToKill);
            idxsToKill = sort(idxsToKill);
            if(~isempty(obj.allNuclei))
                for i = length(idxsToKill):-1:1
                    obj.die(idxsToKill(i));
                end
            end
        end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Kills a nucleus at a certain index in the list
        Inputs:
            obj - aNucleusList instance
            idx - index of nucleus in the list to kill
        Outputs:
            NA
        %}
        function die(obj, idx)
            if (~isempty(obj.allNuclei))
                if (idx > 0 && idx <= length(obj.allNuclei))
                    obj.allNuclei(idx).die();
                    obj.allNuclei(idx) = [];
                else
                    disp('Index out of bounds. No nuclei killed.');
                end
            else
                disp('No nuclei left to die');
            end
        end
        
        %{
        checkDeath
        ---------------------------------------------------------------------------
        Description:
            Checks each nucleus and enacts a chance of each one dying
        Inputs:
            obj - aNucleusList instance
            dieChance - Chance that a nucleus will die this update
        Outputs:
            NA
        %}
        function checkDeath(obj, dieChance)
            if (~isempty(obj.allNuclei))
                for (i = obj.length():-1:1)
                    if (rand < dieChance)
                        obj.die(i);
                    end
                end
            end
        end
        
        %{
        clear
        ---------------------------------------------------------------------------
        Description:
            Kills and removes all nuclei from this list
        Inputs:
            obj - aNucleusList instance
        Outputs:
            NA
        %}
        function clear(obj)
            if(~isempty(obj.allNuclei))
                for (i = 1:obj.length())
                    obj.die(1);
                end
            end
        end
        
        %{
        getAllPositions
        ---------------------------------------------------------------------------
        Description:
            Returns the x, y, and z coordinates of every nucleus in the
            matrix allPos
        Inputs:
            obj - aNucleusList instance
        Outputs:
            allPos - Matrix containing positions of all nuclei in list
        %}
        function [allPos] = getAllPositions(obj)
            allPos = zeros(obj.length(),3);
            for (i = 1:(obj.length()))
                allPos(i, 1) = obj.allNuclei(i).xPos();
                allPos(i, 2) = obj.allNuclei(i).yPos();
                allPos(i, 3) = obj.allNuclei(i).zPos();
            end
        end
        
        %{
        averagePosition
        ---------------------------------------------------------------------------
        Description:
            Returns the coordinates of the average position of the
            nuclei in the list
        Inputs:
            obj - aMyofibrilList2 instance
        Outputs:
            avgX,avgY,avgZ - average coordinates for all myofibrils in list
        %}
        function [avgX, avgY, avgZ] = averagePosition(obj)
            [positions] = obj.getAllPositions();
            avgX = 0;
            avgY = 0;
            avgZ = 0;
            if(~isempty(obj.allNuclei))
                avgX = sum(positions(:,1))/obj.length();
                avgY = sum(positions(:,2))/obj.length();
                avgZ = sum(positions(:,3))/obj.length();
            end
        end
        
        function [dist] = averageDist2Centroid(obj)
            [x y z] = obj.averagePosition();
            if(~isempty(obj.allNuclei))
                for i = 1:obj.length()
                    ox = obj.allNuclei(i).xPos;
                    oy = obj.allNuclei(i).yPos;
                    oz = obj.allNuclei(i).zPos;
                    dist(i) = sqrt((ox-x)^2 + (oy-y)^2 + (oz-z)^2);
                end
                dist = mean(dist);
            end
        end
        
        function [dist] = averageSpread(obj)
            if (~isempty(obj.allNuclei))
                for i = 1:obj.length()
                    total = 0;
                    for j = 1:obj.length()
                        if (i~=j)
                            ix = obj.allNuclei(i).xPos; jx = obj.allNuclei(j).xPos;
                            iy = obj.allNuclei(i).yPos; jy = obj.allNuclei(j).yPos;
                            iz = obj.allNuclei(i).zPos; jz = obj.allNuclei(j).zPos;
                            total = total + sqrt((ix-jx)^2 + (iy-jy)^2 + (iz-jz)^2);
                        end
                    end
                    total = total/(obj.length()-1);
                    dist(i) = total;
                end
                dist = mean(dist);
            end
        end
        
        function [spreadVecs] = getSpreadVectors(obj)
            spreadVecs = zeros(obj.length(),3);
            weight = 1;
            for i = 1:(length(obj.allNuclei)-1)
                for j = (i+1):length(obj.allNuclei)
                    if(any(isnan(obj.allNuclei(i).xPos)))
                        disp('bad nuc spread x1');
                    end
                    if(any(isnan(obj.allNuclei(i).yPos)))
                        disp('bad nuc spread y1');
                    end
                    if(any(isnan(obj.allNuclei(i).zPos)))
                        disp('bad nuc spread z1');
                    end
                    if(any(isnan(obj.allNuclei(j).xPos)))
                        disp('bad nuc spread x2');
                    end
                    if(any(isnan(obj.allNuclei(j).yPos)))
                        disp('bad nuc spread y2');
                    end
                    if(any(isnan(obj.allNuclei(j).zPos)))
                        disp('bad nuc spread z2');
                    end
                    xvec = ((obj.allNuclei(i).xPos - obj.allNuclei(j).xPos));
                    yvec = ((obj.allNuclei(i).yPos - obj.allNuclei(j).yPos));
                    zvec = ((obj.allNuclei(i).zPos - obj.allNuclei(j).zPos));
                    if(any(isnan(xvec)))
                        disp('bad nuc spread x');
                    end
                    if(any(isnan(yvec)))
                        disp('bad nuc spread y');
                    end
                    if(any(isnan(zvec)))
                        disp('bad nuc spread z');
                    end
                    if (xvec == Inf)
                        xvec = 0;
                    elseif (xvec == -Inf)
                        xvec = 0;
                    end
                    if (yvec == Inf)
                        yvec = 0;
                    elseif (yvec == -Inf)
                        yvec = 0;
                    end
                    if (zvec == Inf)
                        zvec = 0;
                    elseif (zvec == -Inf)
                        zvec = 0;
                    end
                    mag = sqrt(xvec^2 + yvec^2 + zvec^2);
                    mag = mag^2;
                    vec = [xvec, yvec, zvec];
%                     vec = obj.normalizeVector(vec);
                    xvec = vec(1)/mag; yvec = vec(2)/mag; zvec = vec(3)/mag;  
                    spreadVecs(i,1) = spreadVecs(i,1)+xvec;
                    spreadVecs(i,2) = spreadVecs(i,2)+yvec;
                    spreadVecs(i,3) = spreadVecs(i,3)+zvec;
                    spreadVecs(j,1) = spreadVecs(j,1)-xvec;
                    spreadVecs(j,2) = spreadVecs(j,2)-yvec;
                    spreadVecs(j,3) = spreadVecs(j,3)-zvec;
                end
            end
        end
        
        function [unitVec] = normalizeVector(obj, vector)
            magnitude = sqrt(vector(1)^2 + vector(2)^2 + vector(3)^2);
            unitVec = vector/magnitude;
        end
        
        function checkFiberBounds(obj, bounds)
            shape = vertcat(bounds(:,:,1),bounds(:,:,2),bounds(:,:,3));
            shape(:,3) = [];
            top = bounds(1,3,1);
            bot = bounds(1,3,3);
            shapex = shape(:,1);
            shapey = shape(:,2);
            k = boundary(shapex, shapey);
            bshapex = shapex(k); bshapey = shapey(k);            
            for i = obj.length():-1:1
                x = obj.allNuclei(i).xPos;
                y = obj.allNuclei(i).yPos;
                z = obj.allNuclei(i).zPos;
                if (~inpolygon(x,y,shapex(k),shapey(k)) && z > bot && z < top)
                    dist = zeros(numel(bshapex),1);
                    for j = 1:numel(bshapex)
                        dist(j) = sqrt((bshapex(j)-x)^2 + (bshapey(j)-y)^2);
                    end
                    [~, ind] = min(dist);
                    obj.allNuclei(i).xPos = bshapex(ind);
                    obj.allNuclei(i).yPos = bshapey(ind);
                end
            end
        end
        
        %{
        checkFibrilBounds
        ---------------------------------------------------------------------------
        Description:
            Checks nuclei to make sure that none are inside myofibrils, and
            pushes them outside if they are
        Inputs:
            obj - aNucleusList instance
            fibrilList - a list of all myofibrils
        Outputs:
            NA
        %}
        function [pushOccurred] = checkFibrilBounds(obj, fibrilList)
            pushOccurred = false;
            if(~isempty(obj.allNuclei) && ~isempty(fibrilList.allFibrils))
                for i = 1:obj.length()
                    for j = 1:fibrilList.length()
                        nucx = obj.allNuclei(i).xPos;
                        nucy = obj.allNuclei(i).yPos;
                        nucz = obj.allNuclei(i).zPos;
                        nucr = obj.allNuclei(i).radius;
                        fibx = fibrilList.allFibrils(j).xPos;
                        fiby = fibrilList.allFibrils(j).yPos;
                        fibz = fibrilList.allFibrils(j).zPos;
                        fibl = fibrilList.allFibrils(j).length;
                        fibr = fibrilList.allFibrils(j).radius;
                        if (sqrt((nucx-fibx)^2 + (nucy-fiby)^2) < (fibr + nucr)...
                                && nucz < fibz+(fibl/2) && nucz > fibz-(fibl/2))
                            pushOccurred = true;
                            obj.allNuclei(i).fibrilPush(fibx, fiby, fibz, fibr, fibl);
                        end
                    end
                end
            end
        end
        
        function s = saveState(obj)
            if (~isempty(obj.allNuclei))
                s.number = obj.length();           
                s.speed = obj.allNuclei(1).speed;
                s.radius = obj.allNuclei(1).radius;
                s.allPos = obj.getAllPositions();
                [x,y,z] = obj.averagePosition();
                s.avgPos = [x,y,z];
                s.avgDist2Cent = obj.averageDist2Centroid();
                s.avgNucSpread = obj.averageSpread();
            else
                s = struct([]);
            end
        end
        
        
        
    end
end