classdef aSatelliteCellList < matlab.mixin.SetGetExactNames
    %{
    aSatelliteCellList Class
    
    Purpose: 
        To maintain a list of all satellite cells within the model
    
    Description:
        This will keep an array of satellite cells that can be called upon:
            Reference the property values of specific objects using array
            indexing
                objArray(ix).PropName
            Reference all values of the same property in obj array
                objArray.PropName
    
    TODO:
    %}
    
    properties
        allSatCells = aSatelliteCell.empty;     %an array of the satellite cells it contains
        mechanisms;
    end
    
    methods
        %{
        aSatelliteCellList constructor
        ---------------------------------------------------------------------------
        Description:
            Constructor for aSatelliteCellList
        Inputs:
            n - number of initial satellite cells in the list
        Outputs:
            obj - aSatelliteCellList instance
        %}
        function obj = aSatelliteCellList(n, mechs)
            if nargin ~= 0
                if (n ~= 0)
                    for (i = 1:n)
                        obj.allSatCells(i) = aSatelliteCell;
                    end
                end
                if (~isempty(mechs))
                    obj.mechanisms = mechs;
                end
            end
        end
        
        %{
        length
        ---------------------------------------------------------------------------
        Description:
            Returns the number of satellite cells in the list
        Inputs:
            obj - aSatelliteCellList instance
        Outputs:
            lngth - Number of satellite cells in the list
        %}
        function [lngth] = length(obj)
            lngth = length(obj.allSatCells);
        end
        
        %{
        addCell
        ---------------------------------------------------------------------------
        Description:
            Adds another satellite cell to the list
        Inputs:
            obj - aSatelliteCellList instance
            x,y,z,r - defines a spherical satellite cell in space
            spd - speed of the new satellite cell
        Outputs:
            NA
        %}
        function addCell(obj, x, y, z, spd, r)
            if nargin == 1
                newCell = aSatelliteCell();
                obj.allSatCells = [obj.allSatCells, newCell];
            elseif nargin == 5
                newCell = aSatelliteCell(x,y,z,spd);
                obj.allSatCells = [obj.allSatCells, newCell];
            elseif nargin == 6
                newCell = aSatelliteCell(x,y,z,spd,r);
                obj.allSatCells = [obj.allSatCells, newCell];
            else
                error('aSatelliteCellList : addCell: Wrong number of input arguments');
            end
        end
        
        %{
        getCell
        ---------------------------------------------------------------------------
        Description:
            Returns and instance of a satellite cell at a particular index
            of the list
        Inputs:
            obj - aSatelliteCellList instance
            idx - index of particular satellite cell in list
        Outputs:
            sat - instance of aSatelliteCell
        %}
        function [sat] = getCell(obj, idx)
            sat = obj.allSatCells(idx);
        end
        
        %{
        update
        ---------------------------------------------------------------------------
        Description:
            Updates all satellite cells in the list
        Inputs:
            obj - aSatelliteCellList instance
            xb,yb,zb - defines boundaries of world
            fiberList - list of all muscle fibers
        Outputs:
            NA
        %}
        function update(obj, xb, yb, zb, fiberList, worldRestrict)
            if (~isempty(obj.allSatCells))
                obj.checkFibBounds(fiberList);
                pullMVecs = obj.getMusclePullVectors(fiberList);
                for (i = 1:length(obj.allSatCells))
                    if (~isempty(obj.allSatCells(i)))
                        obj.allSatCells(i).update(xb, yb, zb, obj.mechanisms, pullMVecs(i,:), worldRestrict);
                    else
                        obj.allSatCells(i) = [];
                    end
                end
            end
        end
        
        function killTrigger(obj, propToKill)
            disp('trigger killing satellite cells');
            %rounds down the number to kill
            numToKill = floor(obj.length()*propToKill);
            idxsToKill = randperm(obj.length(), numToKill);
            idxsToKill = sort(idxsToKill);
            if(~isempty(obj.allSatCells))
                for i = length(idxsToKill):-1:1
                    obj.die(idxsToKill(i));
                end
            end
        end
        
        %{
        die
        ---------------------------------------------------------------------------
        Description:
            Kills and removes a satellite cell at a certain index in list
        Inputs:
            obj - aSatelliteCellList instance
            idx - index of satellite cell to kill
        Outputs:
            NA
        %}
        function die(obj, idx)
            if (~isempty(obj.allSatCells))
                if (idx > 0 && idx <= length(obj.allSatCells))
                    fprintf('Satellite cell at idx %i is dying\n', idx);
                    obj.allSatCells(idx).die();
                    obj.allSatCells(idx) = [];
                else
                    disp('Index out of bounds. No satellite cells killed.');
                end
            else
                disp('No satellite cells left to die');
            end
        end
        
        %{
        checkDeath
        ---------------------------------------------------------------------------
        Description:
            Checks all satellite cell and enacts the chance for each of
            them to die
        Inputs:
            obj - aSatelliteCellList instance
            dieChance - Chance for each satellite cell to die
        Outputs:
            NA
        %}
        function checkDeath(obj, dieChance)
            if (~isempty(obj.allSatCells))
                for (i = obj.length():-1:1)
                    if (rand < dieChance)
                        obj.die(i);
                    end
                end
            end
        end
        
        %{
        checkMyoblastSpawn
        ---------------------------------------------------------------------------
        Description:
            Checks each satellite cell and has a possibility to tell the
            world to spawn a myoblast at the satellite cell
        Inputs:
            obj - aSatelliteCellList instance
            spawnChance - Chance for any individual satellite cell to spawn
            a myoblast
        Outputs:
            shouldSpawn - Boolean telling the world whether to make a
            myoblast
            x,y,z - Position of where an new myoblast would be spawned
        %}
        function [shouldSpawn, x, y, z] = checkMyoblastSpawn(obj, spawnChance, fiberList)
            shouldSpawn = false;
            x = [];
            y = [];
            z = [];
            numNewMyoblasts = 0;
            if (~isempty(obj.allSatCells))
                for (i = obj.length():-1:1)
                    if(obj.mechanisms.satellitequiescentnot)
                        if (rand < spawnChance)
                            shouldSpawn = true;
                            numNewMyoblasts = numNewMyoblasts + 1;
                            x(numNewMyoblasts) = obj.allSatCells(i).xPos;
                            y(numNewMyoblasts) = obj.allSatCells(i).yPos;
                            z(numNewMyoblasts) = obj.allSatCells(i).zPos;
                        end
                    elseif(obj.mechanisms.satellitequiescentfused)
                        if(obj.allSatCells(i).fusedStatus && obj.allSatCells(i).connectedFiberIdx <= fiberList.length())
                            if(obj.mechanisms.satellitequiescentnumnuclei > 0) %means that spawn chance dependent on #nuclei                          
                                chancePerNuc = spawnChance / obj.mechanisms.satellitequiescentnumnuclei;
                                newSpawnChance = spawnChance - (chancePerNuc * ...
                                    fiberList.allFibers(obj.allSatCells(i).connectedFiberIdx).myNuclei.length());
                                if(newSpawnChance < 0)
                                    newSpawnChance = 0;
                                end
                                if (rand < newSpawnChance)
                                    shouldSpawn = true;
                                    numNewMyoblasts = numNewMyoblasts + 1;
                                    x(numNewMyoblasts) = obj.allSatCells(i).xPos;
                                    y(numNewMyoblasts) = obj.allSatCells(i).yPos;
                                    z(numNewMyoblasts) = obj.allSatCells(i).zPos;
                                end
                            end
                        else
                            obj.allSatCells(i).fusedStatus = false;
                            obj.allSatCells(i).connectedFiberIdx = [];
                            if (rand < spawnChance)
                                shouldSpawn = true;
                                numNewMyoblasts = numNewMyoblasts + 1;
                                x(numNewMyoblasts) = obj.allSatCells(i).xPos;
                                y(numNewMyoblasts) = obj.allSatCells(i).yPos;
                                z(numNewMyoblasts) = obj.allSatCells(i).zPos;
                            end
                        end
                    end
                end
            end
        end
        
        %{
        clear
        ---------------------------------------------------------------------------
        Description:
            Kills and removes all satellite cells from the list
        Inputs:
            obj - aSatelliteCellList instance
        Outputs:
            NA
        %}
        function clear(obj)
            if(~isempty(obj.allSatCells))
                for (i = 1:obj.length())
                    obj.die(1);
                end
            end
        end
        
        %{
        getAllPositions
        ---------------------------------------------------------------------------
        Description:
            Returns the x, y, and z coordinates of every satellite cell in
            the matrix allPos
        Inputs:
            obj - aSatelliteCellList instance
        Outputs:
            allPos - Matrix of positions of all satellite cells in the list
        %}
        function [allPos] = getAllPositions(obj)
            allPos = zeros(obj.length(),3);
            for (i = 1:(obj.length()))
                allPos(i, 1) = obj.allSatCells(i).xPos();
                allPos(i, 2) = obj.allSatCells(i).yPos();
                allPos(i, 3) = obj.allSatCells(i).zPos();
            end
        end
        
        %{
        checkFibBounds
        ---------------------------------------------------------------------------
        Description:
            Checks all satellite cells and determines whether any of
            them need to be pushed to the outside of a muscle fiber
        Inputs:
            obj - aSatelliteCellList instance
            fiberList - list of all muscle fibers
        Outputs:
            NA
        %}
        function checkFibBounds(obj, fiberList)
            if(~isempty(obj.allSatCells) && ~isempty(fiberList.allFibers))
                for i = 1:obj.length()
                    if (obj.allSatCells(i).fusedStatus)
                        bshapex = []; bshapey = []; bshapez = [];
                        ka = [];
                        for j = 1:fiberList.length()
                            if (~isempty(fiberList.allFibers(j).boundaryPoints))
                                bounds = fiberList.allFibers(j).boundaryPoints;
                                shape = vertcat(bounds(:,:,1),bounds(:,:,2),bounds(:,:,3));                                
                                shapex = shape(:,1);
                                shapey = shape(:,2);
                                shapez = shape(:,3);
                                k = boundary(shapex, shapey);
                                bshapex = vertcat(bshapex,shapex(k)); 
                                bshapey = vertcat(bshapey,shapey(k));
                                bshapez = vertcat(bshapez,shapez(k));
                                ka = vertcat(ka, k);
%                                 dist = zeros(numel(bshapex),1);                                
                            end
                        end
                        for q = 1:numel(bshapex)
                            dist(q) = sqrt((bshapex(q)-obj.allSatCells(i).xPos)^2 + (bshapey(q)-obj.allSatCells(i).yPos)^2 +...
                                (bshapez(q)-obj.allSatCells(i).zPos)^2);
                        end
                        [~, ind] = min(dist);
                        obj.allSatCells(i).xPos = bshapex(ind);
                        obj.allSatCells(i).yPos = bshapey(ind);
                        obj.allSatCells(i).connectedFiberIdx = j;
                    else
                        for j = 1:fiberList.length()
                            if (~isempty(fiberList.allFibers(j).boundaryPoints))
                                cellx = obj.allSatCells(i).xPos;
                                celly = obj.allSatCells(i).yPos;
                                cellz = obj.allSatCells(i).zPos;
                                bounds = fiberList.allFibers(j).boundaryPoints;
                                shape = vertcat(bounds(:,:,1),bounds(:,:,3));
                                shape(:,3) = [];
                                top = bounds(1,3,1);
                                bot = bounds(1,3,3);
                                shapex = shape(:,1);
                                shapey = shape(:,2);
                                k = boundary(shapex, shapey);
                                if (inpolygon(cellx,celly,shapex(k),shapey(k)) && cellz > bot && cellz < top)
                                    obj.allSatCells(i).fusedStatus = true;
                                    obj.allSatCells(i).connectedFiberIdx = j;
                                    obj.allSatCells(i).fibPush(bounds);
                                end
                            end
                        end
                    end
                end
            end
        end
        
        function [pullVecs] = getMusclePullVectors(obj, fiberList)
            pullVecs = zeros(obj.length(),3);
            weight = 1;
            for i = 1:(length(obj.allSatCells))
                for j = 1:fiberList.length()
                    xvec = ((obj.allSatCells(i).xPos - fiberList.getFiber(j).xPos));
                    yvec = ((obj.allSatCells(i).yPos - fiberList.getFiber(j).yPos));
                    zvec = ((obj.allSatCells(i).zPos - fiberList.getFiber(j).zPos));
                    if (xvec == Inf)
                        xvec = 0;
                    elseif (xvec == -Inf)
                        xvec = 0;
                    end
                    if (yvec == Inf)
                        yvec = 0;
                    elseif (yvec == -Inf)
                        yvec = 0;
                    end
                    if (zvec == Inf)
                        zvec = 0;
                    elseif (zvec == -Inf)
                        zvec = 0;
                    end          
                    mag = sqrt(xvec^2 + yvec^2 + zvec^2);
                    mag = mag^2;
                    xvec = xvec/mag; yvec = yvec/mag; zvec = zvec/mag;  
                    pullVecs(i,1) = pullVecs(i,1)-xvec;
                    pullVecs(i,2) = pullVecs(i,2)-yvec;
                    pullVecs(i,3) = pullVecs(i,3)-zvec;
                end
            end
        end
        
        function s = saveState(obj)
            if (~isempty(obj.allSatCells))
                s.number = obj.length();           
                s.speed = obj.allSatCells(1).speed;
                s.radius = obj.allSatCells(1).radius;
                s.numberFused = 0;
                s.allPos = obj.getAllPositions();
                for i = 1:obj.length()
                    if (obj.allSatCells(i).fusedStatus)
                        s.numberFused = s.numberFused + 1;
                    end
                end
            else
                s = struct([]);
            end
        end
        
        
    end
    
    
end