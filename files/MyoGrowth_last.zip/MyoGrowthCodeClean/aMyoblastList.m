classdef aMyoblastList < matlab.mixin.SetGetExactNames
        %{
    aMyoblastList Class
    
    Purpose: 
        To maintain a list of all myoblasts within the model
    
    Description:
        This will keep an array of myoblasts that can be called upon:
            Reference the property values of specific objects using array
            indexing
                objArray(ix).PropName
            Reference all values of the same property in obj array
                objArray.PropName
    
    TODO:
    %}
    
    properties
        allMyoblasts = aMyoblast.empty;     %an array of the satellite cells it contains
        mechanisms;
    end
    
    methods
        %{
        aMyoblastList constructor
        -------------------------------------------------------------------
        Description:
            Constructor for aMyoblastList
        Inputs:
            n - number of inital myoblasts in the list
        Outputs:
            obj - aMyoblastList instance
        %}
        function obj = aMyoblastList(n, mechs)
            if nargin ~= 0
                if (n ~= 0)
                    for (i = 1:n)
                        obj.allMyoblasts(i) = aMyoblast;
                    end
                end
                if (~isempty(mechs))
                    obj.mechanisms = mechs;
                end
            end
        end
        
        %{
        length
        -------------------------------------------------------------------
        Description:
            Returns the number of myoblasts in the list
        Inputs:
            obj - aMyoblastList instance
        Outputs:
            lngth - the number of myoblasts in the list
        %}
        function [lngth] = length(obj)
            lngth = length(obj.allMyoblasts);
        end
        
        %{
        addMyoblast
        -------------------------------------------------------------------
        Description:
            Adds another myoblast to the myoblast list
        Inputs:
            obj - aMyoblastList instance
            x,y,z,r - defines a sphere in space
            spd - speed of the new myoblast in the list
        Outputs:
            NA
        %}
        function addMyoblast(obj, x, y, z, spd, r, myoblastMechanisms)
            if nargin == 1
                newCell = aMyoblast();
                obj.allMyoblasts = [obj.allMyoblasts, newCell];
            elseif nargin == 5
                newCell = aMyoblast(x,y,z,spd);
                obj.allMyoblasts = [obj.allMyoblasts, newCell];
            elseif nargin == 6
                newCell = aMyoblast(x,y,z,spd,r);
                obj.allMyoblasts = [obj.allMyoblasts, newCell];
            elseif nargin == 7                
                newCell = aMyoblast(x,y,z,spd,r,myoblastMechanisms);
                obj.allMyoblasts = [obj.allMyoblasts, newCell];
            else
                error('aMyoblastList : addMyoblast: Wrong number of input arguments');
            end
        end
        
        %{
        getMyoblast
        -------------------------------------------------------------------
        Description:
            Returns an instance of a myoblast in this list
        Inputs:
            obj - aMyoblastList instance
            idx - index of particular myoblast in this list
        Outputs:
            myo - aMyoblast instance
        %}
        function [myo] = getMyoblast(obj, idx)
            myo = obj.allMyoblasts(idx);
        end
        
        %{
        update
        -------------------------------------------------------------------
        Description:
            Updates all of the contained myoblasts
        Inputs:
            obj - aMyoblastList
            xb,yb,zb - defines boundaries of the world
        Outpus:
            NA
        %}
        function update(obj, xb, yb, zb, fiberList, worldRestrict)
            if (~isempty(obj.allMyoblasts))
                pullVecs = obj.getPullVectors();
                pullMVecs = obj.getMusclePullVectors(fiberList);
                for (i = 1:length(obj.allMyoblasts))
                    if (~isempty(obj.allMyoblasts(i)))
                        obj.allMyoblasts(i).update(xb, yb, zb, obj.mechanisms,...
                            pullVecs(i,:), pullMVecs(i,:), worldRestrict);
                    else
                        obj.allMyoblasts(i) = [];
                    end
                end
            end
        end
        
        function killTrigger(obj, propToKill)
            disp('trigger killing myoblasts');
            %rounds down the number to kill
            numToKill = floor(obj.length()*propToKill);
            idxsToKill = randperm(obj.length(), numToKill);
            idxsToKill = sort(idxsToKill);
            if(~isempty(obj.allMyoblasts))
                for i = length(idxsToKill):-1:1
                    obj.die(idxsToKill(i));
                end
            end
        end
        
        %{
        die
        -------------------------------------------------------------------
        Description:
            Kills a myoblast at a particular index
        Inputs:
            obj - aMyoblastList instance
            idx - index of myoblast to delete in the list
        Outputs:
            NA
        %}
        function die(obj, idx)
            if (~isempty(obj.allMyoblasts))
                if (idx > 0 && idx <= length(obj.allMyoblasts))
%                     fprintf('Myoblast at idx %i is dying\n', idx);
                    obj.allMyoblasts(idx).die();
                    obj.allMyoblasts(idx) = [];
                else
                    disp('Index out of bounds. No myoblasts killed.');
                end
            else
                disp('No myoblasts left to die');
            end
        end
        
        %{
        checkDeath
        -------------------------------------------------------------------
        Description:
            Enacts the chance of myoblasts dying
        Inputs:
            obj - aMyoblastList instance
            dieChance - a number dictating the chance of a myoblast dying
        Outputs:
            NA
        %}
        function checkDeath(obj, dieChance)
            if (~isempty(obj.allMyoblasts))
                for (i = obj.length():-1:1)
                    if (rand < dieChance)
                        obj.die(i);
                    end
                end
            end
        end
        
        %{
        checkMyoMyoFusion
        -------------------------------------------------------------------
        Description:
            Checks the proximity of all myoblasts and determines whether
            they are close enough to fuse
        Inputs:
            obj - aMyoblastList instance
        Outputs:
            shouldSpawnFiber - a boolean telling the world whether a new
            muscle fiber should spawn
            x,y,z - the location that the fusion occurred in the world
        %}
        function [shouldSpawnFiber,x,y,z] = checkMyoMyoFusion(obj)
            killIndecies = [];
            x=0; y=0; z=0;
            shouldSpawnFiber = false;
            %checks separation of all myoblasts from each other
            for i = 1:(length(obj.allMyoblasts)-1)
                for j = (i+1):length(obj.allMyoblasts)
                    separation = sqrt((obj.allMyoblasts(i).xPos - obj.allMyoblasts(j).xPos)^2 ...
                                +(obj.allMyoblasts(i).yPos - obj.allMyoblasts(j).yPos)^2 ...
                                +(obj.allMyoblasts(i).zPos - obj.allMyoblasts(j).zPos)^2);
                    %saves myoblast indecies for later
                    if (~isempty(killIndecies))
                        if (separation <= (obj.allMyoblasts(i).radius*2) && ~any(killIndecies(:)==i) && ~any(killIndecies(:)==j))
                            killIndecies = [killIndecies, i, j];
                            x(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).xPos, obj.allMyoblasts(j).xPos]);
                            y(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).yPos, obj.allMyoblasts(j).yPos]);
                            z(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).zPos, obj.allMyoblasts(j).zPos]);
                        end
                    else
                        if (separation <= (obj.allMyoblasts(i).radius*2))
                            killIndecies = [killIndecies, i, j];
                            x(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).xPos, obj.allMyoblasts(j).xPos]);
                            y(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).yPos, obj.allMyoblasts(j).yPos]);
                            z(numel(killIndecies)/2) = mean([obj.allMyoblasts(i).zPos, obj.allMyoblasts(j).zPos]);
                        end
                    end
                end
            end
            killIndecies = unique(killIndecies);
            %spawns a muscle fiber based on fusing myoblast locations
            if (~isempty(killIndecies))
                shouldSpawnFiber = true;
%                 allPos = obj.getAllPositions();
%                 x = mean(allPos(killIndecies, 1));
%                 y = mean(allPos(killIndecies, 2));
%                 z = mean(allPos(killIndecies, 3));
            end
            %kill fused myoblasts
            for i = length(killIndecies):-1:1
                obj.die(killIndecies(i));
            end
        end
        
        %{
        checkMyoFibFusion
        ---------------------------------------------------------------------------
        Description:
            Checksthe proximity of all myoblasts and fibers and determines
            whether the myoblasts are close enough to fuse with the fibers
        Inputs:
            obj - aMyoblastList instance
            fiberList - aMuscleFiberList2 instance
            nucRad - the radius of new nuclei to pass to muscle fiber
        Outputs:
            NA
        %}
        function checkMyoFibFusion(obj, fiberList, nucInfo)
            if(~isempty(obj.allMyoblasts) && ~isempty(fiberList.allFibers))
                killIndecies = [];
                for i = 1:obj.length()
                    for j = 1:fiberList.length()
                        if (~isempty(fiberList.allFibers(j).boundaryPoints))
                            cellx = obj.allMyoblasts(i).xPos;
                            celly = obj.allMyoblasts(i).yPos;
                            cellz = obj.allMyoblasts(i).zPos;
                            bounds = fiberList.allFibers(j).boundaryPoints;
                            shape = vertcat(bounds(:,:,1),bounds(:,:,2),bounds(:,:,3));
                            shape(:,3) = [];
                            top = bounds(1,3,1);
                            bot = bounds(1,3,3);
                            shapex = shape(:,1);
                            shapey = shape(:,2);
                            k = boundary(shapex, shapey);
                            if (inpolygon(cellx,celly,shapex(k),shapey(k)) && cellz > bot && cellz < top)
                                killIndecies = [killIndecies, i];
                                %If myoblast is touching fiber, make
                                %another nucleus at that spot
                                fiberList.allFibers(j).addNucleus(cellx, celly, cellz, nucInfo(1), nucInfo(2));
                            end
                        end
                    end
                end
                %kill fused myoblasts
                for i = length(killIndecies):-1:1
                    obj.die(killIndecies(i));
                end
            end
        end
             
        %{
        getAllPositions
        ---------------------------------------------------------------------------
        Description:
            Returns the x, y, and z coordinates of every myoblast in the
            matrix allPos
        Inputs:
            obj - aMyoblastList
        Outputs:
            allPos - Matrix containing all x,y,z positions of all myoblasts
            in the list
        %}
        function [allPos] = getAllPositions(obj)
            allPos = zeros(obj.length(),3);
            for (i = 1:(obj.length()))
                allPos(i, 1) = obj.allMyoblasts(i).xPos();
                allPos(i, 2) = obj.allMyoblasts(i).yPos();
                allPos(i, 3) = obj.allMyoblasts(i).zPos();
            end
        end
        
        %{
        getPullVectors
        ---------------------------------------------------------------------------
        Description:
            Returns a set of vectors for each myoblast describing the
            direction to other myoblasts, weighted towards the distance
            from other myoblasts (closer ones contribute more to the vecs)
        Inputs:
            obj - aMyoblastList
        Outputs:
            pullVecs - Matrix containing all vectors for directions towards
            an average direction
        %}
        function [pullVecs] = getPullVectors(obj)
            pullVecs = zeros(obj.length(),3);
            weight = 1;
            for i = 1:(length(obj.allMyoblasts)-1)
                for j = (i+1):length(obj.allMyoblasts)
                    xvec = ((obj.allMyoblasts(i).xPos - obj.allMyoblasts(j).xPos));
                    yvec = ((obj.allMyoblasts(i).yPos - obj.allMyoblasts(j).yPos));
                    zvec = ((obj.allMyoblasts(i).zPos - obj.allMyoblasts(j).zPos));
                    if (xvec == Inf)
                        xvec = 0;
                    elseif (xvec == -Inf)
                        xvec = 0;
                    end
                    if (yvec == Inf)
                        yvec = 0;
                    elseif (yvec == -Inf)
                        yvec = 0;
                    end
                    if (zvec == Inf)
                        zvec = 0;
                    elseif (zvec == -Inf)
                        zvec = 0;
                    end
                    mag = sqrt(xvec^2 + yvec^2 + zvec^2);
                    mag = mag^2;
                    xvec = xvec/mag; yvec = yvec/mag; zvec = zvec/mag;                    
                    pullVecs(i,1) = pullVecs(i,1)-xvec;
                    pullVecs(i,2) = pullVecs(i,2)-yvec;
                    pullVecs(i,3) = pullVecs(i,3)-zvec;
                    pullVecs(j,1) = pullVecs(j,1)+xvec;
                    pullVecs(j,2) = pullVecs(j,2)+yvec;
                    pullVecs(j,3) = pullVecs(j,3)+zvec;
                end
            end
        end
        
        %{
        getMusclePullVectors
        ---------------------------------------------------------------------------
        Description:
            Returns a set of vectors for each myoblast describing the
            direction to other muscle fibers, weighted towards the distance
            from other fibers (closer ones contribute more to the vecs)
        Inputs:
            obj - aMyoblastList
        Outputs:
            pullVecs - Matrix containing all vectors for directions towards
            an average direction
        %}
        function [pullVecs] = getMusclePullVectors(obj, fiberList)
            pullVecs = zeros(obj.length(),3);
            weight = 1;
            for i = 1:(length(obj.allMyoblasts))
                for j = 1:fiberList.length()
                    xvec = ((obj.allMyoblasts(i).xPos - fiberList.getFiber(j).xPos));
                    yvec = ((obj.allMyoblasts(i).yPos - fiberList.getFiber(j).yPos));
                    zvec = ((obj.allMyoblasts(i).zPos - fiberList.getFiber(j).zPos));
                    if (xvec == Inf)
                        xvec = 0;
                    elseif (xvec == -Inf)
                        xvec = -0;
                    end
                    if (yvec == Inf)
                        yvec = 0;
                    elseif (yvec == -Inf)
                        yvec = -0;
                    end
                    if (zvec == Inf)
                        zvec = 0;
                    elseif (zvec == -Inf)
                        zvec = -0;
                    end          
                    mag = sqrt(xvec^2 + yvec^2 + zvec^2);
                    mag = mag^2;
                    xvec = xvec/mag; yvec = yvec/mag; zvec = zvec/mag;  
                    pullVecs(i,1) = pullVecs(i,1)-xvec;
                    pullVecs(i,2) = pullVecs(i,2)-yvec;
                    pullVecs(i,3) = pullVecs(i,3)-zvec;
                end
            end
        end
        
        function s = saveState(obj)
            if (~isempty(obj.allMyoblasts))
                s.number = obj.length();           
                s.speed = obj.allMyoblasts(1).speed;
                s.radius = obj.allMyoblasts(1).radius;
                s.allPos = obj.getAllPositions();
            else
                s = struct([]);
            end
        end
        
        
    end
    
end