Muscle Regeneration Agent Based Model

Description: Simulate interactions between myofibrils, muscle fibers, myoblasts, and muscle fiber nuclei to propose models for muscle fiber genesis, growth, and atrophy.

Compatability: MATLAB R2018a/R2018b

Instructions:
There are two different "main" files included.
The first is "RunSimulation.m" which uses a configuration file to run a simulation and output a video and simulation file.
The second is "RunAnalysis.m" which uses the output simulation file from "RunSimulation.m" to create a basic plot of simulation measurements over time.
-Running a simulation:
	-Edit the "testxml.xml" file to your specifications (or make a new .xml configuration file)
	-Open the "RunSimulation.m" script located in the folder
	-Modify variables located in "RunSimulation.m" to change which .xml file to use as input and where to store simulation output.
	-Run "RunSimulation.m"
-Running an analysis:
	-Edit the "RunSimulation.m" file to point to the appropriate simulation file to use as input.
	-Run "RunAnalysis.m"

Authors/Contributors:
Kenneth Campbell	(University of Kentucky Department of Physiology)
John McCarthy		(University of Kentucky Department of Physiology)
Chase Vickery

This software uses some modules from the MATLAB File Exchange:
export_fig:
	Yair Altman (2021). export_fig (https://github.com/altmany/export_fig/releases/tag/v3.16), GitHub. Retrieved September 10, 2021.
parse_pv_pairs:
	John D'Errico (2021). parse_pv_pairs (https://www.mathworks.com/matlabcentral/fileexchange/9082-parse_pv_pairs), MATLAB Central File Exchange. Retrieved September 10, 2021.
xml2struct:
	Wouter Falkena (2021). xml2struct (https://www.mathworks.com/matlabcentral/fileexchange/28518-xml2struct), MATLAB Central File Exchange. Retrieved September 10, 2021.