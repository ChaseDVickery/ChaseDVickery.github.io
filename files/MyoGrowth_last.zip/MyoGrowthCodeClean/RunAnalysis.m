clear;

% set m to the path to the saved simulation file output or set
% useFileDirectory to browse for the simulation file
m = load('D:\temp\MyoGrowth_last\simulation.mat');
useFileDirectory = 0;

toplot = 1;


% Other analysis not supported
    plotAvg = 0;
        plotSave = 0;
% set plotSavePath to the path where the analysis image should be saved
plotSavePath = 'D:\temp\MyoGrowth_last\output_figs\';

% rendering not supported here. Export to movie through the simulation
% itself
torender = 0;
    simRend = 1;
    pushToContinue = 1;
    writeMovie = 0;
% set renderStartTick to the point at which rendering should start
renderStartTick =  1;%floor(totalTicks/2);
    
    
    
    



if (useFileDirectory)
    [file,path] = uigetfile;
    filename = [path,file];
    try
        m = load(filename);
    catch
        error('Invalid file to load');
    end
end

totalTicks = length(m.guiSetup.savedSim);

tic;

    
time = 1:totalTicks;

if (toplot)
    lw = 3;
    nmfC = [0 1 0];
    avgnC = [1 1 0];
    avgnsC = [1 0 1];
    avgmC = [0.5 0.5 0];
    avgfvC = [0 0 0];
    nscC = [1 0 0];
    nscfC = [0.5 0 0];
    nmC = [0 0 1];
    tctC = [0 1 1];
    if (~plotAvg)
        YLim = [];
        for j = 1:m.guiSetup.simulation.numberSimulations
            figName = sprintf('Sim Run %i',j);
            figure('Name',figName);
            hold on;
            grid on;
        %     subplots = initialise_publication_quality_figure();
            for i = time
                if (~isempty(m.guiSetup.savedSim{j,i}.muscleFibers))
                    numberMuscFibs(i) = m.guiSetup.savedSim{j,i}.muscleFibers.number;
                    avgNuclei(i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgNucNumber;
                    avgNucSpread(i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgNucSpread;
                    avgMyofibrils(i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgMyoNumber;
                    avgFiberVol(i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgFiberVolume;
                else
                    numberMuscFibs(i) = 0;
                    avgNuclei(i) = 0;
                    avgNucSpread(i) = 0;
                    avgMyofibrils(i) = 0;
                    avgFiberVol(i) = 0;
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.satelliteCells))
                    numberSatCells(i) = m.guiSetup.savedSim{j,i}.satelliteCells.number;
                    numberSatCellsFused(i) = m.guiSetup.savedSim{j,i}.satelliteCells.numberFused;            
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.myoblasts))
                    numberMyoblasts(i) = m.guiSetup.savedSim{j,i}.myoblasts.number;            
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.tickComputationTime))
                    tickComputationTime(i) = m.guiSetup.savedSim{j,i}.tickComputationTime;
                end
            end
            if (~isempty(m.guiSetup.savedSim{j,i}.muscleFibers))
                plot(time, numberMuscFibs, 'Color', nmfC, 'DisplayName', '# Muscle Fibers', 'LineWidth', lw);
                plot(time, avgNuclei, 'Color', avgnC, 'DisplayName', 'Nuclei/Fiber', 'LineWidth', lw);
                plot(time, avgNucSpread, 'Color', avgnsC, 'DisplayName', 'Avg Nucleus Spread/Fiber', 'LineWidth', lw);
                plot(time, avgMyofibrils, 'Color', avgmC, 'DisplayName', 'Myofibrils/Fiber', 'LineWidth', lw);
                plot(time, avgFiberVol, 'Color', avgfvC, 'DisplayName', 'Avg Fiber Volume', 'LineWidth', lw);
            end
            if (~isempty(m.guiSetup.savedSim{j,i}.satelliteCells))
                plot(time, numberSatCells, 'Color', nscC, 'DisplayName', '# Sat Cells', 'LineWidth', lw);
                plot(time, numberSatCellsFused, 'Color', nscfC, 'DisplayName', '# Fused Sat Cells', 'LineWidth', lw);
            end
            if (~isempty(m.guiSetup.savedSim{j,i}.myoblasts))
                plot(time, numberMyoblasts, 'Color', nmC, 'DisplayName', '# Myoblasts', 'LineWidth', lw);
            end
            if (~isempty(m.guiSetup.savedSim{j,i}.tickComputationTime))
                plot(time, tickComputationTime, 'Color', tctC, 'DisplayName', 'Computation Time', 'LineWidth', lw);
            end
            legend('Location','northwest');
            xlim([0 totalTicks]);   
%             xlim([900 1000]);
            hold off;
            currY = ylim(gca);
            currY = currY(2);
            YLim = [YLim currY];
        end
        YLim = max(YLim);
%         YLim = 256;
        for k = 1:m.guiSetup.simulation.numberSimulations
            figure(k);
            ylim([0 YLim]);
        end
    else
        figName = sprintf('Avg Values_%i_Simulations',m.guiSetup.simulation.numberSimulations);
        figure('Name',figName,'NumberTitle','off');
        hold on;
        grid on;
        fiberNotEmpty = false;
        satCellsNotEmpty = false;
        myoblastsNotEmpty = false;
        tickCompTimeNotEmpty = false;
        for j = 1:m.guiSetup.simulation.numberSimulations
            for i = time
                if (~isempty(m.guiSetup.savedSim{j,i}.muscleFibers))
                    fiberNotEmpty = true;
                    numberMuscFibs(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers.number;
                    avgNuclei(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgNucNumber;
                    avgNucSpread(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgNucSpread;
                    avgMyofibrils(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgMyoNumber;                    
                    avgFiberVol(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers.avgFiberVolume;
                    maxFibrils(j,i) = 0;
                    for q = 1:m.guiSetup.savedSim{j,i}.muscleFibers(1).number
                        if(maxFibrils(j,i) < m.guiSetup.savedSim{j,i}.muscleFibers(q).myofibrils.number)
                            maxFibrils(j,i) = m.guiSetup.savedSim{j,i}.muscleFibers(q).myofibrils.number;
                        end
                    end
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.satelliteCells))
                    satCellsNotEmpty = true;
                    numberSatCells(j,i) = m.guiSetup.savedSim{j,i}.satelliteCells.number;
                    numberSatCellsFused(j,i) = m.guiSetup.savedSim{j,i}.satelliteCells.numberFused;            
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.myoblasts))
                    myoblastsNotEmpty = true;
                    numberMyoblasts(j,i) = m.guiSetup.savedSim{j,i}.myoblasts.number;  
                elseif (isempty(m.guiSetup.savedSim{j,i}.myoblasts) && myoblastsNotEmpty)
                    numberMyoblasts(j,i) = 0;
                end
                if (~isempty(m.guiSetup.savedSim{j,i}.tickComputationTime))
                    tickCompTimeNotEmpty = true;
                    tickComputationTime(j,i) = m.guiSetup.savedSim{j,i}.tickComputationTime;
                end
            end
        end
        if (fiberNotEmpty)
            numberMuscFibs = mean(numberMuscFibs);
            avgNuclei = mean(avgNuclei);
            avgNucSpread = mean(avgNucSpread);
            avgMyofibrils = mean(avgMyofibrils);
            avgFiberVol = mean(avgFiberVol);
            maxFibrils = max(maxFibrils);
        end
        if (satCellsNotEmpty)
            numberSatCells = mean(numberSatCells);
            numberSatCellsFused = mean(numberSatCellsFused);
        end
        if (myoblastsNotEmpty)
            numberMyoblasts = mean(numberMyoblasts);
        end
        if (tickCompTimeNotEmpty)
            tickComputationTime = mean(tickComputationTime);
        end
        
        if (fiberNotEmpty)
            plot(time, numberMuscFibs, 'Color', nmfC, 'DisplayName', '# Muscle Fibers', 'LineWidth', lw);
            plot(time, avgNuclei, 'Color', avgnC, 'DisplayName', 'Nuclei/Fiber', 'LineWidth', lw);
            plot(time, avgNucSpread, 'Color', avgnsC, 'DisplayName', 'Avg Nucleus Spread/Fiber', 'LineWidth', lw);
            plot(time, avgMyofibrils, 'Color', avgmC, 'DisplayName', 'Myofibrils/Fiber', 'LineWidth', lw);
            plot(time, maxFibrils, 'Color', [1 0.4 1], 'DisplayName', 'Fiber w/Most Fibrils', 'LineWidth', lw);
            plot(time, avgFiberVol, 'Color', avgfvC, 'DisplayName', 'Avg Fiber Volume', 'LineWidth', lw);
        end
        if (satCellsNotEmpty)
            plot(time, numberSatCells, 'Color', nscC, 'DisplayName', '# Sat Cells', 'LineWidth', lw);
            plot(time, numberSatCellsFused, 'Color', nscfC, 'DisplayName', '# Fused Sat Cells', 'LineWidth', lw);
        end
        if (myoblastsNotEmpty)
            plot(time, numberMyoblasts, 'Color', nmC, 'DisplayName', '# Myoblasts', 'LineWidth', lw);
        end
        if (tickCompTimeNotEmpty)
            plot(time, tickComputationTime, 'Color', tctC, 'DisplayName', 'Computation Time', 'LineWidth', lw);
        end
        
        legend('Location','northwest');
%         xlim([0 totalTicks]);    
%         xlim([900 1000]);
%         ylim([0 256]);
        hold off;
        
%         figure;
%         plot(time,avgNucSpread);
        
        plotSaveFile = [plotSavePath figName];
        if (plotSave)
            print(plotSaveFile)
            saveas(gcf,plotSaveFile,'png');
        end
    end
end

if (torender)
    fprintf('sim: %i \n',simRend);
    obj.sceneNumber = 1;
    strings = [];
    startScene = renderStartTick;    
    fig = figure;    
    cla;
    hold on;
    xb(1) = -m.guiSetup.savedSim{startScene}.simSpaceVariables.worldX; 
    xb(2) = m.guiSetup.savedSim{startScene}.simSpaceVariables.worldX;
    yb(1) = -m.guiSetup.savedSim{startScene}.simSpaceVariables.worldY; 
    yb(2) = m.guiSetup.savedSim{startScene}.simSpaceVariables.worldY;
    zb(1) = -m.guiSetup.savedSim{startScene}.simSpaceVariables.worldZ; 
    zb(2) = m.guiSetup.savedSim{startScene}.simSpaceVariables.worldZ;
    axis([(xb(1)) (xb(2)) (yb(1)) (yb(2)) (zb(1)) (zb(2))]);
    %ZOOM
%     zoom(1.5);
    
    %END ZOOM
    ax = gca;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    %sets camera angle/position
    % GENERAL************************************************************
    view(119.6, -45.199);
    ax.OuterPosition = [0.029234060472058,0.004482582218191,0.975122611753403,0.959249252561902];
    ax.Position = [0.05,0.03,0.800720024108887,0.98178814083795];
    ax.CameraPosition = [306.4189241132149,326.300782985308,-263.884902880924];
    ax.CameraUpVector = [0.807068844513205,-0.43498833739323,0.399280636329879];
    zoom(gca, 1);
    
    %SPECIFIC
    %{
    view(119.6, -45.199);
    ax.OuterPosition = [0.029234060472058,0.004482582218191,0.975122611753403,0.959249252561902];
    ax.Position = [0.05,0.03,0.800720024108887,0.98178814083795];
    ax.CameraPosition = [306.4189241132149,326.300782985308,-263.884902880924];
    ax.CameraUpVector = [0.807068844513205,-0.43498833739323,0.399280636329879];
    zoom(gca, 1);
    %}
    
    pbaspect(ax, [xb(2), yb(2), zb(2)]);
    set(gcf, 'Position', get(0, 'Screensize'));
    grid on;
    set(ax, 'GridColor',[0 0 0]);
    for q = startScene:totalTicks
        
        fibrils = m.guiSetup.savedSim{1,q}.muscleFibers.myofibrils;
        nucs = m.guiSetup.savedSim{1,q}.muscleFibers.nuclei;

        summs = sumOneOverMyofibrilFromNucleusDistancesSquared(fibrils, nucs);
        fprintf('highest sum: %f.2 at index %i\n',max(summs),find(summs==max(summs)));
        [sorted,si] = sort(summs);
        highest10sumsidx = 0;
        if(length(summs) > 9)
            highest10sumsidx = si(length(summs)-9:length(summs));
        end
%         fibrils.radius(highest10sumsidx(:))
%         summs(highest10sumsidx(:))
        
        cla;                        
        [x, y, z] = sphere(4);
        [xc,yc,zc] = cylinder;
        if (~isempty(m.guiSetup.savedSim{simRend,q}.satelliteCells))
            satCellPos = m.guiSetup.savedSim{simRend,q}.satelliteCells.allPos;
            for i = 1:m.guiSetup.savedSim{simRend,q}.satelliteCells.number
                s = surf(x*m.guiSetup.savedSim{simRend,q}.satelliteCells.radius + satCellPos(i,1),...
                    y*m.guiSetup.savedSim{simRend,q}.satelliteCells.radius + satCellPos(i,2),...
                    z*m.guiSetup.savedSim{simRend,q}.satelliteCells.radius + satCellPos(i,3));
                set(s, 'FaceColor',[1 0 0]);
            end
        end
        if (~isempty(m.guiSetup.savedSim{simRend,q}.myoblasts))
            myoblastPos = m.guiSetup.savedSim{simRend,q}.myoblasts.allPos;
            for i = 1:m.guiSetup.savedSim{simRend,q}.myoblasts.number
                s = surf(x*m.guiSetup.savedSim{simRend,q}.myoblasts.radius + myoblastPos(i,1),...
                    y*m.guiSetup.savedSim{simRend,q}.myoblasts.radius + myoblastPos(i,2),...
                    z*m.guiSetup.savedSim{simRend,q}.myoblasts.radius + myoblastPos(i,3));
                set(s, 'FaceColor',[0 0 1],'EdgeAlpha',0.5);
            end
        end        
        if(~isempty(m.guiSetup.savedSim{simRend,q}.muscleFibers))
            fiberPos = m.guiSetup.savedSim{simRend,q}.muscleFibers.allPos;
            for i = 1:m.guiSetup.savedSim{simRend,q}.muscleFibers(1).number
                %CLASSIC CYLINDERS
                %                 s = surf(xc*m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).radius + fiberPos(i,1),...
                %                     yc*m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).radius + fiberPos(i,2),...
                %                     zc*m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).length + fiberPos(i,3) - m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).length/2);
                %                 set(s, 'FaceColor',[0 1 0]);
                %                 alpha(s, 0.3);

                %                 USING ALPHASHAPE
                %                 xb(1) = -obj.worldX; xb(2) = obj.worldX;
                %                 yb(1) = -obj.worldY; yb(2) = obj.worldY;
                %                 [topBounds, botBounds] = m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).myMyofibrils.getBoundary(xb, yb);
                %                 muscleBounds = vertcat(topBounds, botBounds);
                %                 muscShape = alphaShape(muscleBounds);
                %                 plot(muscShape);

                %                 USING BOUNDARY
                muscleBounds = vertcat(m.guiSetup.savedSim{simRend,q}.muscleFibers(i).bounds(:,:,1), m.guiSetup.savedSim{simRend,q}.muscleFibers(i).bounds(:,:,2), m.guiSetup.savedSim{simRend,q}.muscleFibers(i).bounds(:,:,3));
                muscShape = m.guiSetup.savedSim{simRend,q}.muscleFibers(i).boundInds;
                if (~isempty(muscleBounds))
                    trisurf(muscShape,muscleBounds(:,1),muscleBounds(:,2),muscleBounds(:,3),...
                        'Facecolor','green','FaceAlpha',0.2,'EdgeAlpha',0);
                end
                %                 shp = alphaShape(muscleBounds(muscShape));
                %                 disp(inShape(shp,m.guiSetup.savedSim{q}.muscleFiberList.getFiber(i).myMyofibrils.averagePosition()));
                %                 plot(shp);

                if (m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.number > 0)
                    fibrilPos = m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.allPos;
                    for j = 1: m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.number
%                         if(j==106||j==124)
                            s2 = surf(xc*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.radius(j) + fibrilPos(j,1),...
                                yc*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.radius(j) + fibrilPos(j,2),...
                                zc*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.length(j) + fibrilPos(j,3) - m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.length(j)/2);
                            set(s2, 'FaceColor',[1 1 0], 'EdgeColor',[0 0 0], 'EdgeAlpha', 0.03);
%                             if(any(j==highest10sumsidx))
%                                 f = find(j==highest10sumsidx);
%                                 set(s2, 'EdgeColor', [0.1*f 0 0]);
%                             end
%                             if(j==106)
%                                 set(s2, 'EdgeColor', [0 0 1]);
%                             end
%                             alpha(s2, 1);
%                         end
                    end
                end
%                 nucpos = m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.avgPos(:);
%                 s4 = surf(x*0.0005 + nucpos(1), y*0.0005 + nucpos(2), z*0.0005 + nucpos(3));
%                 set(s4, 'FaceColor',[1 0 1]);
                if (m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.number > 0)
                    nucPos = m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.allPos;
                    for j = 1: m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.number
                        s3 = surf(x*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.radius + nucPos(j,1),...
                            y*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.radius + nucPos(j,2),...
                            z*m.guiSetup.savedSim{simRend,q}.muscleFibers(i).nuclei.radius + nucPos(j,3));
                        set(s3, 'FaceColor',[1 1 0], 'EdgeAlpha', 1);
                        alpha(s3, 1);
                    end
                end
            end
            %plot3(satCellPos(:,1), satCellPos(:,2), satCellPos(:,3), 'or', 'LineStyle', 'none', 'MarkerSize', m.guiSetup.savedSim{simRend,q}.satelliteCells.radius*2);
            %plot3(myoblastPos(:,1), myoblastPos(:,2), myoblastPos(:,3), 'ob', 'LineStyle', 'none', 'MarkerSize', m.guiSetup.savedSim{simRend,q}.myoblasts.radius*2);
            %plot3(fiberPos(:,1), fiberPos(:,2), fiberPos(:,3), 'og', 'LineStyle', 'none', 'MarkerSize', m.guiSetup.savedSim{simRend,q}.myoblasts.radius*2)                      
        end
        camlight;  
        if (writeMovie)                
            obj.movieFolder = 'C:\Lab\Chase\Satellite_Cell_Modeling\movietestthrowaway\';
%             obj.movieFolder = 'D:\Documents\Lab_work\Muscle_Modeling\Output\moviethrowaway\';
            strings = saveScene(obj,strings,totalTicks);
            obj.sceneNumber = obj.sceneNumber + 1;
        else
            pause(0.15);
        end
        if(pushToContinue)
            fprintf('\ttick: %i\n',q);
            fprintf('\t\tnum myofibrils: %i\n',m.guiSetup.savedSim{simRend,q}.muscleFibers(i).myofibrils.number);
            pause;
        end
    end
    
    toc;
end
    
    function strings = saveScene(obj,strings,maxscenes)
        fig = gcf;
        filenum = sprintf('%i',obj.sceneNumber);
        filename = [obj.movieFolder, filenum];
        disp('saving scene');
        figure_export('output_file_string',filename,'output_type','png','dpi',72);
        filename = [filename, '.png'];
        strings{obj.sceneNumber} = filename;
        if(obj.sceneNumber > maxscenes-1)
            write_image_files_to_movie(strings, obj.movieFolder);
            obj.stop = true;
        end
    end
    
    function [allDist] = allMyofibrilFromNucleusDistances(fibrils,nucs)
%             allDist = [];
                %  each column contains dist from 1 myofibril to all nuclei
                allDist = zeros(nucs.number,fibrils.number);
                for i = 1:fibrils.number
                    for j = 1:nucs.number
                        ix = fibrils.allPos(i,1); jx = nucs.allPos(j,1);
                        iy = fibrils.allPos(i,2); jy = nucs.allPos(j,2);
                        dist = sqrt((ix-jx)^2 + (iy-jy)^2);
                        allDist(j,i) = dist;
                    end
                end
        end
        
        %{
        sumOneOverMyofibrilFromNucleusDistancesSquared
        ---------------------------------------------------------------------------
        Description:
            Takes all the nucleus to myofibril distances and sums up the
            nucleus distances for each myofibril in the form of
            1/(distance)^2
        Inputs:
            obj - aMyofibrilList2 instance
            nucs - aNucleusList instance
        Outputs:
            sums - an array containing a number for each myofibril
            describing the sum(1/(distance to nuclei)^2)
        %}
        function [sums] = sumOneOverMyofibrilFromNucleusDistancesSquared(fibrils,nucs)
            allDist = allMyofibrilFromNucleusDistances(fibrils,nucs);
            % i: 1 to # fibrils            j: 1 to # nuclei
            sums = zeros(size(allDist,2),1);
            for i = 1:size(allDist,2)
                for j = 1:size(allDist,1)
                    %NOW in MICROMETERS
                    if(allDist(j,i)~=0)
                        if(allDist(j,i) >= fibrils.radius(i))
                            sums(i) = sums(i) + (1/((allDist(j,i)*1000)^2));
                        else
%                             disp(i);
                            sums(i) = sums(i) + (1/((fibrils.radius(i)*1000)^2));
                        end
                    end
                end
            end
        end