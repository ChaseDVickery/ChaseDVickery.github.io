    rng('default');
    
    % Change 'xmlfile' to point to the xml configuration file for your
    % simulation
    xmlfile = 'D:\temp\MyoGrowth_last\testxml.xml';
    % This points to the place where you would like to store the output
    % simulation.mat file
    saved_simulation = 'D:\temp\MyoGrowth_last\simulation.mat'

    
    tic;
    xmlInput = getXMLData(xmlfile);
    guiSetup = simSetup(xmlInput);
    save(saved_simulation, 'guiSetup');
    toc;
% end

%{
getXMLData
---------------------------------------------------------------------------
Description:
    Uses the xml2struct function from the MATLAB file exchange to read from
    the given xml file and put corresponding parameters into a structure
Inputs:
    xmlfile - filename of xml file
Outputs:
    p - a structure containing parameters for the simulation
%}
function p = getXMLData(xmlfile)
    xmls = xml2struct(xmlfile);
    numparams = (length(fieldnames(xmls.testxml)));
    s = xmls.testxml;
    p.ticktime = str2double(s.ticktime.Text);
    p.xbound = str2double(s.xbound.Text);
    p.ybound = str2double(s.ybound.Text);
    p.zbound = str2double(s.zbound.Text);
    p.numsatellitecells = str2double(s.numsatellitecells.Text);
    p.satellitecellspeed = str2double(s.satellitecellspeed.Text);
    p.myoblastspawnchance = str2double(s.myoblastspawnchance.Text);
    p.satellitecelldiechance = str2double(s.satellitecelldiechance.Text);
    p.satellitecellradius = str2double(s.satellitecellradius.Text);
    p.satellitecellworldrestriction = str2double(s.satellitecellworldrestriction.Text);
    p.nummyoblasts = str2double(s.nummyoblasts.Text);
    p.myoblastspeed = str2double(s.myoblastspeed.Text);
    p.myoblastdiechance = str2double(s.myoblastdiechance.Text);
    p.myoblastradius = str2double(s.myoblastradius.Text);
    p.myoblastworldrestriction = str2double(s.myoblastworldrestriction.Text);
    p.numnuclei = str2double(s.numnuclei.Text);
    p.maxmusclefibers = str2double(s.maxmusclefibers.Text);
    p.nummusclefibers = str2double(s.nummusclefibers.Text);
    p.fibrilradius = str2double(s.fibrilradius.Text);
    p.fibrillength = str2double(s.fibrillength.Text);
    p.fibrilgrowrate = str2double(s.fibrilgrowrate.Text);
    p.fibrildecayrate = str2double(s.fibrildecayrate.Text);
    p.nummyofibrils = str2double(s.nummyofibrils.Text);
    p.myofibrilmaxradius = str2double(s.myofibrilmaxradius.Text);
    p.myofibrilmaxlength = str2double(s.myofibrilmaxlength.Text);
    p.myofibrilmaxgrowthrate = str2double(s.myofibrilmaxgrowthrate.Text);
    p.myofibrilmaxdecayrate = str2double(s.myofibrilmaxdecayrate.Text);
    p.interfibrildistance = str2double(s.interfibrildistance.Text);
    p.myofibriledgedistance = str2double(s.myofibriledgedistance.Text);
    p.myofibrilprojectionquality = str2double(s.myofibrilprojectionquality.Text);
    p.nucleusspeed = str2double(s.nucleusspeed.Text);
    p.nucleusdiechance = str2double(s.nucleusdiechance.Text);
    p.nucleusradius = str2double(s.nucleusradius.Text);
    
    p.nucleusrandomspread = str2double(s.nucleusrandomspread.Text);
    p.nucleuspushspread = str2double(s.nucleuspushspread.Text);
    p.myoblastrandomspread = str2double(s.myoblastrandomspread.Text);
    p.myoblastpullspread = str2double(s.myoblastpullspread.Text);
    p.myoblastmusclepullspread = str2double(s.myoblastmusclepullspread.Text);
    p.myofibrilgrownumnucleus = str2double(s.myofibrilgrownumnucleus.Text);
    p.myofibrilgrowdistnucleus = str2double(s.myofibrilgrowdistnucleus.Text);
    p.myofibrilgrownucleardensity = str2double(s.myofibrilgrownucleardensity.Text);
    p.myofibrildecaysizemyofibril = str2double(s.myofibrildecaysizemyofibril.Text);
    p.myofibrildecaynummyofibril = str2double(s.myofibrildecaynummyofibril.Text);
    p.myofibrildecaytotalvolume = str2double(s.myofibrildecaytotalvolume.Text);
    p.myofibrildecayfiberarea = str2double(s.myofibrildecayfiberarea.Text);
    
    p.myofibrilsplitchance = str2double(s.myofibrilsplitchance.Text);
    p.myofibrilsplitradius = str2double(s.myofibrilsplitradius.Text);
    p.myofibrilmaxsplits = str2double(s.myofibrilmaxsplits.Text);
    
    p.satelliterandomspread = str2double(s.satelliterandomspread.Text);
    p.satellitemusclepullspread = str2double(s.satellitemusclepullspread.Text);
    p.satellitequiescentnot = str2double(s.satellitequiescentnot.Text);
    p.satellitequiescentfused = str2double(s.satellitequiescentfused.Text);
    p.satellitequiescentnumnuclei = str2double(s.satellitequiescentnumnuclei.Text);
    p.satellitequiescentfiberdecay = str2double(s.satellitequiescentfiberdecay.Text);
    
    p.steadykillsatellitecells = str2double(s.steadykillsatellitecells.Text);
    p.steadykillmyoblasts = str2double(s.steadykillmyoblasts.Text);
    p.steadykillmusclefibers = str2double(s.steadykillmusclefibers.Text);
    p.steadykillmyofibrils = str2double(s.steadykillmyofibrils.Text);
    p.steadykillnuclei = str2double(s.steadykillnuclei.Text);
    
    p.steadyinducehypertrophy = str2double(s.steadyinducehypertrophy.Text);
    p.steadyinduceatrophy = str2double(s.steadyinduceatrophy.Text);
    
    p.hypertrophygrowthratemultiplier = str2double(s.hypertrophygrowthratemultiplier.Text);
    p.hypertrophydecayratemultiplier = str2double(s.hypertrophydecayratemultiplier.Text);
    p.hypertrophymaxradiusmultiplier = str2double(s.hypertrophymaxradiusmultiplier.Text);
    p.hypertrophysplitradiusmultiplier = str2double(s.hypertrophysplitradiusmultiplier.Text);
    p.hypertrophyfibersplitting = str2double(s.hypertrophyfibersplitting.Text);
        
    p.recordmovie = str2double(s.recordmovie.Text);
    p.scenenumber = str2double(s.scenenumber.Text);
    p.shouldrender = str2double(s.shouldrender.Text);
    p.maxticks = str2double(s.maxticks.Text);
    p.numbersims = str2double(s.numbersims.Text);
    p.moviefolder = s.moviefolder.Text;
end


%{
Data organization:

guiSetup
    .savedSim{i}
        .satelliteCells
            .number - number of cells in the simulation
            .speed - speed of all satellite cells
            .radius - radius of all satellite cells
            .numberFused - number of currently fused satellite cells
        .myoblasts
            .number - number of cells in the simulation
            .speed - speed of all myoblasts
            .radius - radius of all myoblasts
        .muscleFibers(i)
            .number - number of muscle fibers
            .avgNucNumber - average number of nuclei per fiber in world
            .myofibrils
                .number - number of myofibrils in fiber
                .length - average length of myofibrils in fiber
                .radius(i) - radius of one myofibril in fiber
            .nuclei
                .number - number of nuclei in fiber
                .speed - speed of all nuclei
                .radius - radius of all nuclei
%}



%{
main
Project: MyoGrowth
Author:
Version:
Last Update: June 25, 2018
Description:
    MyoGrowth is an agent based model designed to provide insight on the
    formation of skeletal muscle fibers based on the fusion of myoblasts
    and the prescense of satellite cells located outside of the fibers.

Function header template:
        %{
        
        ---------------------------------------------------------------------------
        Description:
            
        Inputs:
            
        Outputs:
            
        %}


%} 